// 效率工具箱 - 核心逻辑
const STORAGE_KEY = 'toolbox_items_v3';
const BG_COLOR_KEY = 'toolbox_bg_color';
const LAYOUT_KEY = 'toolbox_layout';

// 应用状态
let items = [];
let currentFilter = { tab: 'all', search: '' };
let selectedType = '';
let currentLayout = 'list'; // 'list' 或 'masonry'

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    loadItems();
    loadSettings();
    renderFeed();
});

// 加载设置
function loadSettings() {
    // 背景颜色
    const savedBg = localStorage.getItem(BG_COLOR_KEY);
    if (savedBg) {
        document.body.style.setProperty('--bg-color', savedBg);
    }
    // 布局
    const savedLayout = localStorage.getItem(LAYOUT_KEY);
    if (savedLayout) {
        currentLayout = savedLayout;
        updateLayoutIcon();
    }
}

// 加载数据
function loadItems() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            items = JSON.parse(stored);
        }
    } catch (e) {
        items = [];
    }
}

// 保存数据
function saveItems() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

// ========== 背景颜色切换 ==========
function toggleBgColor() {
    document.getElementById('bgColorModal').classList.remove('hidden');
}

function closeBgColorModal() {
    document.getElementById('bgColorModal').classList.add('hidden');
}

function setBgColor(color) {
    document.body.style.setProperty('--bg-color', color);
    localStorage.setItem(BG_COLOR_KEY, color);
    closeBgColorModal();
    showToast('背景颜色已更改');
}

// ========== 布局切换 ==========
function toggleLayout() {
    currentLayout = currentLayout === 'list' ? 'masonry' : 'list';
    localStorage.setItem(LAYOUT_KEY, currentLayout);
    updateLayoutIcon();
    renderFeed();
    showToast(currentLayout === 'list' ? '已切换为卡片流' : '已切换为瀑布流');
}

function updateLayoutIcon() {
    const icon = document.getElementById('layoutIcon');
    if (currentLayout === 'masonry') {
        // 瀑布流图标（网格）
        icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>`;
    } else {
        // 卡片流图标（列表）
        icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>`;
    }
}

// ========== 标签筛选 ==========
function filterByTab(tab) {
    currentFilter.tab = tab;
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        if (btn.dataset.tab === tab) {
            btn.classList.add('tab-active');
            btn.classList.remove('bg-gray-100', 'text-gray-600');
        } else {
            btn.classList.remove('tab-active');
            btn.classList.add('bg-gray-100', 'text-gray-600');
        }
    });
    
    renderFeed();
}

// ========== 搜索 ==========
function handleSearch() {
    currentFilter.search = document.getElementById('searchInput').value.trim();
    renderFeed();
}

// ========== 渲染 ==========
function renderFeed() {
    const container = document.getElementById('feedContainer');
    const emptyState = document.getElementById('emptyState');

    // 筛选
    let filteredItems = items.filter(item => {
        if (currentFilter.tab !== 'all') {
            const tabMap = {
                'efficiency': '效率',
                'tool': '工具', 
                'collect': '收藏',
                'custom': '自定义'
            };
            if (item.type !== tabMap[currentFilter.tab]) return false;
        }
        if (currentFilter.search) {
            const search = currentFilter.search.toLowerCase();
            return (item.title && item.title.toLowerCase().includes(search)) ||
                   item.content.toLowerCase().includes(search);
        }
        return true;
    });

    if (filteredItems.length === 0) {
        container.innerHTML = '';
        emptyState.classList.remove('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    
    // 设置布局
    if (currentLayout === 'masonry') {
        container.className = 'masonry-grid';
    } else {
        container.className = 'grid grid-cols-1 gap-3';
    }
    
    container.innerHTML = filteredItems.map(item => createCardHTML(item)).join('');
}

// 创建卡片 HTML
function createCardHTML(item) {
    const typeColors = {
        '效率': 'bg-blue-100 text-blue-600',
        '工具': 'bg-purple-100 text-purple-600',
        '收藏': 'bg-amber-100 text-amber-600',
        '自定义': 'bg-gray-100 text-gray-600'
    };
    const typeColor = typeColors[item.type] || 'bg-gray-100 text-gray-600';
    
    const timeStr = formatTime(item.createdAt);
    
    if (currentLayout === 'masonry') {
        // 瀑布流卡片（双列）
        return `
            <div class="masonry-item bg-white rounded-2xl p-4 card-shadow card-enter">
                <div class="flex items-start gap-3 mb-2">
                    <div class="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center flex-shrink-0">
                        <span class="text-xl">${getIconForType(item.type)}</span>
                    </div>
                    <div class="flex-1 min-w-0">
                        <h4 class="font-semibold text-gray-900 text-[15px] mb-1 line-clamp-2">${escapeHtml(item.title || '新记录')}</h4>
                        <p class="text-[13px] text-gray-500 line-clamp-3">${escapeHtml(item.content)}</p>
                    </div>
                </div>
                <div class="flex items-center gap-2 mt-3">
                    <span class="text-xs px-2.5 py-1 rounded-full ${typeColor}">${item.type}</span>
                    <span class="text-xs text-gray-400 flex items-center gap-1">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        ${timeStr}
                    </span>
                </div>
            </div>
        `;
    } else {
        // 卡片流（单列列表）
        return `
            <div class="idea-card bg-white rounded-2xl p-4 card-shadow card-enter">
                <div class="flex items-start gap-3">
                    <div class="w-12 h-12 rounded-2xl bg-brand/10 flex items-center justify-center flex-shrink-0">
                        <span class="text-2xl">${getIconForType(item.type)}</span>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-start justify-between gap-2">
                            <h4 class="font-semibold text-gray-900 text-[16px] mb-1">${escapeHtml(item.title || '新记录')}</h4>
                            <button onclick="deleteItem('${item.id}', event)" class="text-gray-300 hover:text-red-400 p-1">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                        <p class="text-[14px] text-gray-500 mb-3 line-clamp-2">${escapeHtml(item.content)}</p>
                        <div class="flex items-center gap-3">
                            <span class="text-xs px-3 py-1.5 rounded-full ${typeColor}">${item.type}</span>
                            <span class="text-xs text-gray-400 flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                                ${timeStr}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

function getIconForType(type) {
    const icons = {
        '效率': '⚡',
        '工具': '🛠️',
        '收藏': '⭐',
        '自定义': '🔧'
    };
    return icons[type] || '📦';
}

function formatTime(isoString) {
    const date = new Date(isoString);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${month}-${day} ${hours}:${minutes}`;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== 添加/删除 ==========
function openInputModal() {
    document.getElementById('inputModal').classList.remove('hidden');
    document.getElementById('titleInput').focus();
}

function closeInputModal() {
    document.getElementById('inputModal').classList.add('hidden');
    document.getElementById('titleInput').value = '';
    document.getElementById('contentInput').value = '';
    selectedType = '';
    updateTypeButtons();
}

function selectType(type) {
    selectedType = selectedType === type ? '' : type;
    updateTypeButtons();
}

function updateTypeButtons() {
    document.querySelectorAll('.type-tag').forEach(btn => {
        if (btn.dataset.type === selectedType) {
            btn.style.background = '#4F6EF7';
            btn.style.color = '#fff';
        } else {
            btn.style.background = '#F5F5F0';
            btn.style.color = '#1A1A1A';
        }
    });
}

function addItem() {
    const title = document.getElementById('titleInput').value.trim();
    const content = document.getElementById('contentInput').value.trim();
    
    if (!title && !content) {
        showToast('请输入内容');
        return;
    }

    const newItem = {
        id: 'item_' + Date.now(),
        title: title || '新记录',
        content: content || '',
        type: selectedType || '效率',
        createdAt: new Date().toISOString()
    };

    items.unshift(newItem);
    saveItems();
    renderFeed();
    closeInputModal();
    showToast('已添加到 Gator');
}

function deleteItem(id, event) {
    if (event) event.stopPropagation();
    if (confirm('确定删除这个工具？')) {
        items = items.filter(item => item.id !== id);
        saveItems();
        renderFeed();
        showToast('已删除');
    }
}

// ========== 其他功能 ==========
function closeWelcome() {
    document.getElementById('welcomeCard').style.display = 'none';
}

function addDemoData() {
    const demoItems = [
        {
            id: 'demo_1',
            title: '🎙️ 语音输入捕获',
            content: '明天下午3点提醒我关注京东618的抢购活动。Gator会自动提取提醒标题和时间，生成任务卡片。',
            type: '效率',
            createdAt: new Date(Date.now() - 3600000).toISOString()
        },
        {
            id: 'demo_2',
            title: '🔗 链接内容预览',
            content: '微信看到的好文章、微博的热门微博、B站的视频...输入链接即可快速预览，AI自动总结要点。',
            type: '收藏',
            createdAt: new Date(Date.now() - 7200000).toISOString()
        },
        {
            id: 'demo_3',
            title: '📄 文件智能管理',
            content: '图片（≤10MB）、视频（≤100MB）统一管理，OCR文字识别，视频语音转文字摘要。',
            type: '工具',
            createdAt: new Date(Date.now() - 14400000).toISOString()
        },
        {
            id: 'demo_4',
            title: '📊 一键生成日报',
            content: '将今日收集的信息，按类型自动分组，生成精美的Markdown日报，一键复制分享。',
            type: '效率',
            createdAt: new Date(Date.now() - 86400000).toISOString()
        },
        {
            id: 'demo_5',
            title: '🏷️ 智能标签分类',
            content: '待办/知识/灵感/备忘，AI自动识别内容类型，打上精准标签，省去手动分类的麻烦。',
            type: '自定义',
            createdAt: new Date(Date.now() - 172800000).toISOString()
        }
    ];
    
    items = [...demoItems, ...items];
    saveItems();
    renderFeed();
    closeWelcome();
    showToast('示例数据已添加，快来体验吧');
}

function showMoreMenu() {
    showToast('更多功能开发中');
}

function showFilter() {
    showToast('筛选功能开发中');
}

function showSettings() {
    showToast('设置功能开发中');
}

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.remove('opacity-0');
    toast.classList.add('opacity-100');
    
    setTimeout(() => {
        toast.classList.remove('opacity-100');
        toast.classList.add('opacity-0');
    }, 2000);
}

// 键盘快捷键
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeInputModal();
        closeBgColorModal();
    }
});
