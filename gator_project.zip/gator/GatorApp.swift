//
//  GatorApp.swift
//  Gator - 个人信息效率工具箱
//
//  基于 Figma 设计规格生成的 SwiftUI 实时预览代码
//  适合初学者阅读，包含完整注释
//

import SwiftUI

// MARK: - ==================== 全局常量 ====================

/// 全局颜色配置（严格匹配 Figma 设计规格）
extension Color {
    /// 背景色：温暖米白
    static let gatorBackground = Color(hex: "F9F7F2")

    /// 品牌色：蓝紫色
    static let gatorBrand = Color(hex: "4F6EF7")

    /// 渐变起始色
    static let gatorGradientStart = Color(hex: "5B7FFF")

    /// 渐变中间色（品牌色）
    static let gatorGradientMiddle = Color(hex: "4F6EF7")

    /// 渐变结束色
    static let gatorGradientEnd = Color(hex: "3D5BD6")

    /// 卡片白色
    static let gatorCardWhite = Color.white

    /// 文字主色
    static let gatorTextPrimary = Color(hex: "1A1A2E")

    /// 文字副色
    static let gatorTextSecondary = Color(hex: "8E8EA0")

    /// 标签背景色
    static let gatorTagBackground = Color(hex: "EEF0FF")
}

// MARK: - ==================== Color Hex 扩展 ====================

extension Color {
    /// 从十六进制字符串创建 Color（支持 "RRGGBB" 格式）
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 6: // RGB
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - ==================== 数据模型 ====================

/// 内容类型枚举
enum ContentType: String, CaseIterable, Codable {
    case all = "全部"
    case record = "记录"
    case collection = "收集"
    case clue = "线索"
    case idea = "想法"

    /// 每种类型对应的图标
    var icon: String {
        switch self {
        case .all: return "square.grid.2x2"
        case .record: return "doc.text"
        case .collection: return "star"
        case .clue: return "lightbulb"
        case .idea: return "sparkles"
        }
    }

    /// 每种类型对应的颜色
    var color: Color {
        switch self {
        case .all: return .gatorBrand
        case .record: return .orange
        case .collection: return .yellow
        case .clue: return .green
        case .idea: return .purple
        }
    }
}

/// 单条内容卡片的数据模型
struct GatorItem: Identifiable, Codable {
    let id: UUID
    var content: String          // 内容文本
    var type: ContentType       // 内容类型
    var sourceIcon: String       // 来源图标名称
    var sourceName: String       // 来源名称
    var createdAt: Date         // 创建时间
    var tags: [String]          // 标签列表

    /// 便捷初始化（自动生成 UUID）
    init(
        id: UUID = UUID(),
        content: String,
        type: ContentType = .record,
        sourceIcon: String = "globe",
        sourceName: String = "网页",
        createdAt: Date = Date(),
        tags: [String] = []
    ) {
        self.id = id
        self.content = content
        self.type = type
        self.sourceIcon = sourceIcon
        self.sourceName = sourceName
        self.createdAt = createdAt
        self.tags = tags
    }
}

// MARK: - ==================== 视图模型 ====================

/// 主视图模型，管理所有数据与业务逻辑
@MainActor
class GatorViewModel: ObservableObject {

    // MARK: - 发布属性（驱动 UI 刷新）

    /// 所有内容条目
    @Published var items: [GatorItem] = []

    /// 当前搜索关键词
    @Published var searchText: String = ""

    /// 当前选中的标签类型
    @Published var selectedTag: ContentType = .all

    /// 是否显示新建内容的模态框
    @Published var showCreateModal: Bool = false

    /// 是否显示日报生成面板
    @Published var showDailyReport: Bool = false

    /// 是否展开时间分组下拉菜单
    @Published var showTimeGroupDropdown: Bool = false

    /// 新建内容时的输入文本
    @Published var newContentText: String = ""

    /// 新建内容时选择的类型
    @Published var newContentType: ContentType = .record

    /// 日报文本
    @Published var dailyReportText: String = ""

    // MARK: - 数据持久化（UserDefaults）

    /// 从 UserDefaults 加载数据
    private let itemsKey = "gator_saved_items"

    init() {
        loadItems()
        // 如果没有数据，加载示例数据
        if items.isEmpty {
            loadSampleData()
        }
    }

    /// 保存数据到 UserDefaults
    func saveItems() {
        if let encoded = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(encoded, forKey: itemsKey)
        }
    }

    /// 从 UserDefaults 加载数据
    func loadItems() {
        if let data = UserDefaults.standard.data(forKey: itemsKey),
           let decoded = try? JSONDecoder().decode([GatorItem].self, from: data) {
            items = decoded
        }
    }

    /// 加载示例数据（用于预览和首次启动）
    func loadSampleData() {
        let calendar = Calendar.current
        let now = Date()

        items = [
            GatorItem(
                content: "今天学习了 SwiftUI 的 LazyVGrid 布局，双列瀑布流效果很好",
                type: .record,
                sourceIcon: "book",
                sourceName: "笔记",
                createdAt: calendar.date(byAdding: .hour, value: -2, to: now) ?? now,
                tags: ["SwiftUI", "学习"]
            ),
            GatorItem(
                content: "发现了一个很好的 API 设计模式：RESTful + GraphQL 混合架构",
                type: .clue,
                sourceIcon: "link",
                sourceName: "收藏",
                createdAt: calendar.date(byAdding: .hour, value: -5, to: now) ?? now,
                tags: ["API", "架构"]
            ),
            GatorItem(
                content: "可以用 AI 来自动生成日报摘要，节省每天 15 分钟",
                type: .idea,
                sourceIcon: "brain",
                sourceName: "想法",
                createdAt: calendar.date(byAdding: .hour, value: -8, to: now) ?? now,
                tags: ["AI", "效率"]
            ),
            GatorItem(
                content: "收集了 5 篇关于 Swift Concurrency 的优质文章",
                type: .collection,
                sourceIcon: "safari",
                sourceName: "网页",
                createdAt: calendar.date(byAdding: .hour, value: -12, to: now) ?? now,
                tags: ["Swift", "文章"]
            ),
            GatorItem(
                content: "项目会议纪要：Q3 产品路线图已确认，重点在移动端体验优化",
                type: .record,
                sourceIcon: "person.2",
                sourceName: "会议",
                createdAt: calendar.date(byAdding: .day, value: -1, to: now) ?? now,
                tags: ["工作", "会议"]
            ),
            GatorItem(
                content: "设计灵感：Notion 和 Linear 的交互设计值得借鉴",
                type: .clue,
                sourceIcon: "paintbrush",
                sourceName: "灵感",
                createdAt: calendar.date(byAdding: .day, value: -1, to: now) ?? now,
                tags: ["设计", "灵感"]
            ),
            GatorItem(
                content: "读完了《原子习惯》，核心观点：习惯的改变在于系统而非目标",
                type: .record,
                sourceIcon: "book",
                sourceName: "读书",
                createdAt: calendar.date(byAdding: .day, value: -2, to: now) ?? now,
                tags: ["读书", "习惯"]
            ),
            GatorItem(
                content: "周末想去试一下新的咖啡店，据说手冲很不错",
                type: .idea,
                sourceIcon: "mug",
                sourceName: "生活",
                createdAt: calendar.date(byAdding: .day, value: -2, to: now) ?? now,
                tags: ["生活"]
            ),
        ]
        saveItems()
    }

    // MARK: - 筛选逻辑

    /// 根据搜索关键词和标签类型筛选条目
    var filteredItems: [GatorItem] {
        var result = items

        // 按标签类型筛选
        if selectedTag != .all {
            result = result.filter { $0.type == selectedTag }
        }

        // 按搜索关键词筛选（匹配内容、标签、来源）
        if !searchText.isEmpty {
            result = result.filter { item in
                item.content.localizedCaseInsensitiveContains(searchText) ||
                item.tags.contains(where: { $0.localizedCaseInsensitiveContains(searchText) }) ||
                item.sourceName.localizedCaseInsensitiveContains(searchText)
            }
        }

        return result
    }

    /// 按时间分组：返回 (分组名称, 条目列表) 的数组
    var groupedItems: [(String, [GatorItem])] {
        let calendar = Calendar.current
        let now = Date()
        let grouped = Dictionary(grouping: filteredItems) { item -> String in
            if calendar.isDateInToday(item.createdAt) {
                return "今天"
            } else if calendar.isDateInYesterday(item.createdAt) {
                return "昨天"
            } else if calendar.date(item.createdAt, equalTo: now, toGranularity: .weekOfYear) {
                return "本周"
            } else {
                return "更早"
            }
        }

        // 按时间排序分组
        let order = ["今天", "昨天", "本周", "更早"]
        return order.compactMap { key in
            if let items = grouped[key], !items.isEmpty {
                return (key, items.sorted { $0.createdAt > $1.createdAt })
            }
            return nil
        }
    }

    // MARK: - 数据操作

    /// 添加新条目
    func addItem(content: String, type: ContentType) {
        // 智能时间识别：从文本中提取时间信息
        let recognizedTime = recognizeTime(from: content)

        let newItem = GatorItem(
            content: content,
            type: type,
            sourceIcon: "text.cursor",
            sourceName: "手动输入",
            createdAt: recognizedTime ?? Date(),
            tags: extractTags(from: content)
        )
        items.insert(newItem, at: 0)
        saveItems()
    }

    /// 删除条目
    func deleteItem(_ item: GatorItem) {
        items.removeAll { $0.id == item.id }
        saveItems()
    }

    // MARK: - 智能时间识别

    /// 使用正则匹配识别文本中的时间表达
    /// 支持的格式："明天下午3点"、"后天上午10点"、"下周一"、"今天晚上8点" 等
    func recognizeTime(from text: String) -> Date? {
        let calendar = Calendar.current
        let now = Date()

        // 正则模式列表
        let patterns: [(String, (Date) -> Date?)] = [
            // "明天下午X点" / "明天上午X点"
            (
                "明天(上午|下午)(\\d{1,2})点",
                { base in
                    guard let tomorrow = calendar.date(byAdding: .day, value: 1, to: base) else { return nil }
                    // 明天日期 + 当前时间（简化处理）
                    return calendar.date(bySettingHour: 9, minute: 0, second: 0, of: tomorrow)
                }
            ),
            // "后天"
            (
                "后天",
                { base in
                    calendar.date(byAdding: .day, value: 2, to: base)
                }
            ),
            // "下周一" ~ "下周日"
            (
                "下周([一二三四五六日天])",
                { base in
                    guard let match = $1 else { return nil }
                    // 简化处理：返回下周的某天
                    return calendar.date(byAdding: .day, value: 7, to: base)
                }
            ),
        ]

        // 注意：Swift 正则匹配需要更精细的处理
        // 这里使用简单的字符串包含检测作为演示
        if text.contains("明天") {
            return calendar.date(byAdding: .day, value: 1, to: now)
        } else if text.contains("后天") {
            return calendar.date(byAdding: .day, value: 2, to: now)
        } else if text.contains("下周") {
            return calendar.date(byAdding: .day, value: 7, to: now)
        }

        return nil
    }

    // MARK: - 标签提取

    /// 从文本中提取 #标签 格式的标签
    func extractTags(from text: String) -> [String] {
        // 匹配 #标签名 格式
        let pattern = "#(\\S+)"
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let range = NSRange(text.startIndex..., in: text)
        let matches = regex.matches(in: text, range: range)
        return matches.compactMap { match in
            guard let range = Range(match.range(at: 1), in: text) else { return nil }
            return String(text[range])
        }
    }

    // MARK: - 日报生成

    /// 根据今天的内容生成日报摘要
    func generateDailyReport() {
        let calendar = Calendar.current
        let todayItems = items.filter { calendar.isDateInToday($0.createdAt) }

        if todayItems.isEmpty {
            dailyReportText = "今天还没有记录任何内容哦~"
            return
        }

        var report = "📋 今日日报\n"
        report += "━━━━━━━━━━━━━━━━\n\n"
        report += "📊 今日记录：\(todayItems.count) 条\n\n"

        // 按类型分组统计
        let typeCount = Dictionary(grouping: todayItems, by: { $0.type })
        for (type, items) in typeCount {
            report += "🔹 \(type.rawValue)：\(items.count) 条\n"
        }

        report += "\n📝 详细内容：\n"
        for (index, item) in todayItems.enumerated() {
            report += "\n\(index + 1). [\(item.type.rawValue)] \(item.content)\n"
            if !item.tags.isEmpty {
                report += "   标签：\(item.tags.joined(separator: ", "))\n"
            }
        }

        report += "\n━━━━━━━━━━━━━━━━\n"
        report += "💡 Gator 助你高效记录每一天"

        dailyReportText = report
        showDailyReport = true
    }
}

// MARK: - ==================== 导航栏组件 ====================

/// 顶部导航栏：汉堡菜单 | Logo + 标题 | 用户头像
struct GatorNavigationBar: View {
    @State private var showMenu = false

    var body: some View {
        HStack {
            // 左侧：汉堡菜单按钮
            Button(action: {
                showMenu.toggle()
            }) {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.gatorTextPrimary)
                    .frame(width: 44, height: 44)
            }

            Spacer()

            // 中间：蓝色圆形 Logo + 标题
            HStack(spacing: 8) {
                // 蓝色圆形 Logo，内含白色 "G"
                ZStack {
                    Circle()
                        .fill(Color.gatorBrand)
                        .frame(width: 36, height: 36)
                    Text("G")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                }

                Text("我的Gator")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.gatorTextPrimary)
            }

            Spacer()

            // 右侧：用户头像
            Button(action: {
                // 点击头像的逻辑
            }) {
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.gatorBrand)
                    .frame(width: 44, height: 44)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

// MARK: - ==================== 搜索框组件 ====================

/// 搜索框：白色圆角矩形 + 放大镜图标 + placeholder
struct GatorSearchBar: View {
    @Binding var text: String

    var body: some View {
        HStack(spacing: 8) {
            // 左侧放大镜图标
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16))
                .foregroundColor(.gatorTextSecondary)

            // 搜索输入框
            TextField("搜索工具、标签、内容...", text: $text)
                .font(.system(size: 15))
                .foregroundColor(.gatorTextPrimary)

            // 如果有输入内容，显示清除按钮
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 16))
                        .foregroundColor(.gatorTextSecondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
        .padding(.horizontal, 16)
    }
}

// MARK: - ==================== 欢迎卡片组件 ====================

/// 欢迎卡片：蓝色渐变背景，包含图标、标题、描述、按钮
struct WelcomeCard: View {
    var onStart: () -> Void  // 点击"开始体验"的回调

    var body: some View {
        // 蓝色渐变背景
        LinearGradient(
            colors: [
                Color.gatorGradientStart,
                Color.gatorGradientMiddle,
                Color.gatorGradientEnd
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .cornerRadius(20)
        .padding(.horizontal, 16)
        .overlay(
            // 卡片内容
            VStack(alignment: .leading, spacing: 12) {
                // 闪电图标
                Image(systemName: "bolt.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.white.opacity(0.9))

                // 标题
                Text("欢迎使用Gator")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)

                // 副标题
                Text("你的个人信息效率工具箱")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.white.opacity(0.85))

                // 正文描述
                Text("Gator 帮助你高效收集、整理和管理日常信息碎片，让每一条灵感都不再遗失。")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.75))
                    .lineSpacing(4)

                // "开始体验" 按钮
                Button(action: onStart) {
                    HStack(spacing: 4) {
                        Text("开始体验")
                            .font(.system(size: 14, weight: .semibold))
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .foregroundColor(Color.gatorBrand)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(Color.white)
                    .cornerRadius(20)
                }
                .padding(.top, 4)
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
        )
        .frame(height: 220)
    }
}

// MARK: - ==================== 标签栏组件 ====================

/// 标签栏：全部/记录/收集/线索/想法，选中态蓝色+下划线
struct GatorTagBar: View {
    @Binding var selectedTag: ContentType

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 24) {
                ForEach(ContentType.allCases, id: \.self) { tag in
                    TagButton(
                        title: tag.rawValue,
                        isSelected: selectedTag == tag,
                        action: {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                selectedTag = tag
                            }
                        }
                    )
                }
            }
            .padding(.horizontal, 16)
        }
    }
}

/// 单个标签按钮
struct TagButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Text(title)
                    .font(.system(size: 15, weight: isSelected ? .semibold : .regular))
                    .foregroundColor(isSelected ? .gatorBrand : .gatorTextSecondary)

                // 选中态下划线
                Rectangle()
                    .fill(isSelected ? Color.gatorBrand : Color.clear)
                    .frame(width: 24, height: 3)
                    .cornerRadius(1.5)
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - ==================== 时间分组标题 ====================

/// 时间分组标题：如 "今天 ▼"
struct TimeGroupHeader: View {
    let title: String
    @State private var isExpanded = true

    var body: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) {
                isExpanded.toggle()
            }
        }) {
            HStack(spacing: 6) {
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.gatorTextPrimary)

                // 下拉箭头图标
                Image(systemName: "chevron.down")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.gatorTextSecondary)
                    .rotationEffect(.degrees(isExpanded ? 0 : -90))
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .padding(.bottom, 8)
    }
}

// MARK: - ==================== 内容卡片组件 ====================

/// 单个内容卡片：白色圆角卡片，包含来源图标+时间、内容文本、类型标签
struct GatorItemCard: View {
    let item: GatorItem
    let onDelete: () -> Void

    /// 格式化时间显示
    private var timeString: String {
        let formatter = DateFormatter()
        let calendar = Calendar.current

        if calendar.isDateInToday(item.createdAt) {
            formatter.dateFormat = "HH:mm"
        } else if calendar.isDateInYesterday(item.createdAt) {
            formatter.dateFormat = "昨天 HH:mm"
        } else {
            formatter.dateFormat = "MM/dd HH:mm"
        }
        return formatter.string(from: item.createdAt)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // 来源图标 + 来源名称 + 时间
            HStack(spacing: 6) {
                Image(systemName: item.sourceIcon)
                    .font(.system(size: 12))
                    .foregroundColor(.gatorBrand)

                Text(item.sourceName)
                    .font(.system(size: 12))
                    .foregroundColor(.gatorTextSecondary)

                Spacer()

                Text(timeString)
                    .font(.system(size: 11))
                    .foregroundColor(.gatorTextSecondary)
            }

            // 内容文本（最多显示 4 行）
            Text(item.content)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.gatorTextPrimary)
                .lineLimit(4)
                .lineSpacing(3)

            // 底部：类型标签 + 标签列表
            HStack(spacing: 6) {
                // 类型标签
                TagLabel(text: item.type.rawValue, color: item.type.color)

                // 自定义标签
                ForEach(item.tags.prefix(2), id: \.self) { tag in
                    TagLabel(text: "#\(tag)", color: .gatorTextSecondary)
                }

                Spacer()
            }
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 2)
        .contextMenu {
            Button(role: .destructive, action: onDelete) {
                Label("删除", systemImage: "trash")
            }
        }
    }
}

/// 小型标签组件（用于卡片内）
struct TagLabel: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .medium))
            .foregroundColor(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(color.opacity(0.1))
            )
    }
}

// MARK: - ==================== 双列卡片网格 ====================

/// 双列卡片网格布局
struct GatorCardGrid: View {
    let items: [GatorItem]
    let onDelete: (GatorItem) -> Void

    // 两列布局
    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        LazyVGrid(columns: columns, spacing: 12) {
            ForEach(items) { item in
                GatorItemCard(item: item) {
                    onDelete(item)
                }
            }
        }
        .padding(.horizontal, 16)
    }
}

// MARK: - ==================== 底部浮动按钮栏 ====================

/// 底部浮动按钮栏：左侧"更多"、中间"+"按钮（脉冲动画）、右侧"文档"
struct GatorFloatingBar: View {
    let onAdd: () -> Void       // 点击"+"按钮
    let onMore: () -> Void      // 点击"更多"
    let onDocument: () -> Void   // 点击"文档"

    /// 脉冲动画状态
    @State private var isPulsing = false

    var body: some View {
        HStack {
            // 左侧"更多"按钮
            Button(action: onMore) {
                Image(systemName: "ellipsis")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.gatorTextSecondary)
                    .frame(width: 48, height: 48)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 2)
            }

            Spacer()

            // 中间大号"+"按钮（带脉冲动画）
            ZStack {
                // 脉冲光圈动画
                Circle()
                    .fill(Color.gatorBrand.opacity(0.2))
                    .frame(width: 72, height: 72)
                    .scaleEffect(isPulsing ? 1.3 : 1.0)
                    .opacity(isPulsing ? 0.0 : 0.6)
                    .animation(
                        .easeOut(duration: 1.5).repeatForever(autoreverses: false),
                        value: isPulsing
                    )

                // 主按钮
                Button(action: onAdd) {
                    Image(systemName: "plus")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 60, height: 60)
                        .background(
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [.gatorGradientStart, .gatorGradientEnd],
                                        startPoint: .top,
                                        endPoint: .bottom
                                    )
                                )
                        )
                        .shadow(color: Color.gatorBrand.opacity(0.4), radius: 12, x: 0, y: 4)
                }
            }
            .onAppear {
                isPulsing = true
            }

            Spacer()

            // 右侧"文档"按钮
            Button(action: onDocument) {
                Image(systemName: "doc.text")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.gatorTextSecondary)
                    .frame(width: 48, height: 48)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 2)
            }
        }
        .padding(.horizontal, 40)
        .padding(.vertical, 16)
        .background(Color.gatorBackground.opacity(0.01))
    }
}

// MARK: - ==================== 帮助悬浮按钮 ====================

/// 右下角帮助"?"悬浮按钮
struct HelpFloatingButton: View {
    @State private var showHelp = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            // 帮助提示气泡
            if showHelp {
                Text("需要帮助？点击查看使用指南")
                    .font(.system(size: 13))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color.gatorBrand)
                    .cornerRadius(12)
                    .shadow(color: Color.gatorBrand.opacity(0.3), radius: 8, x: 0, y: 4)
                    .transition(.opacity.combined(with: .move(edge: .trailing)))
                    .padding(.trailing, 70)
                    .padding(.bottom, 8)
            }

            // "?" 圆形按钮
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    showHelp.toggle()
                }
            }) {
                Text("?")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 40, height: 40)
                    .background(Color.gatorBrand)
                    .clipShape(Circle())
                    .shadow(color: Color.gatorBrand.opacity(0.3), radius: 8, x: 0, y: 4)
            }
        }
        .padding(.trailing, 20)
        .padding(.bottom, 8)
    }
}

// MARK: - ==================== 文本输入模态框 ====================

/// 底部弹出的文本输入模态框
struct CreateContentModal: View {
    @Binding var isPresented: Bool
    @Binding var text: String
    @Binding var selectedType: ContentType
    let onConfirm: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            // 顶部拖动指示条
            Capsule()
                .fill(Color.gatorTextSecondary.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 10)
                .padding(.bottom, 16)

            // 标题
            Text("新建内容")
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.gatorTextPrimary)
                .padding(.bottom, 16)

            // 类型选择器
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(ContentType.allCases.filter { $0 != .all }, id: \.self) { type in
                        TypeSelectorButton(
                            type: type,
                            isSelected: selectedType == type,
                            action: {
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    selectedType = type
                                }
                            }
                        )
                    }
                }
                .padding(.horizontal, 16)
            }
            .padding(.bottom, 16)

            // 文本输入区域
            ZStack(alignment: .topLeading) {
                // 背景圆角矩形
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gatorBackground)
                    .frame(minHeight: 120)

                // 自动增长的文本编辑器
                if text.isEmpty {
                    Text("输入你的想法、记录或灵感...\n支持 #标签 和时间表达（如"明天下午3点"）")
                        .font(.system(size: 15))
                        .foregroundColor(.gatorTextSecondary)
                        .padding(16)
                        .allowsHitTesting(false)
                }

                TextEditor(text: $text)
                    .font(.system(size: 15))
                    .foregroundColor(.gatorTextPrimary)
                    .padding(12)
                    .frame(minHeight: 120)
                    .background(Color.clear)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)

            // 操作按钮
            HStack(spacing: 12) {
                // 取消按钮
                Button(action: {
                    text = ""
                    isPresented = false
                }) {
                    Text("取消")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gatorTextSecondary)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(Color.gatorBackground)
                        .cornerRadius(12)
                }

                // 确认按钮
                Button(action: {
                    if !text.isEmpty {
                        onConfirm()
                        text = ""
                        isPresented = false
                    }
                }) {
                    Text("保存")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(
                            LinearGradient(
                                colors: [.gatorGradientStart, .gatorGradientEnd],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(12)
                }
                .disabled(text.isEmpty)
                .opacity(text.isEmpty ? 0.5 : 1.0)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 8)

            // 底部安全区域
            Spacer(minLength: 0)
        }
        .background(Color.white)
        .cornerRadius(20, corners: [.topLeft, .topRight])
        .shadow(color: Color.black.opacity(0.1), radius: 16, x: 0, y: -4)
    }
}

/// 类型选择按钮（模态框内使用）
struct TypeSelectorButton: View {
    let type: ContentType
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: type.icon)
                    .font(.system(size: 14))
                Text(type.rawValue)
                    .font(.system(size: 14, weight: .medium))
            }
            .foregroundColor(isSelected ? .white : .gatorTextSecondary)
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(isSelected ? Color.gatorBrand : Color.gatorTagBackground)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - ==================== 日报面板 ====================

/// 日报生成结果面板
struct DailyReportView: View {
    @Binding var isPresented: Bool
    @Binding var reportText: String

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // 日报标题
                    HStack {
                        Image(systemName: "chart.bar.doc.horizontal")
                            .font(.system(size: 20))
                            .foregroundColor(.gatorBrand)
                        Text("今日日报")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.gatorTextPrimary)
                        Spacer()
                    }
                    .padding(.top, 8)

                    Divider()

                    // 日报内容
                    Text(reportText)
                        .font(.system(size: 15))
                        .foregroundColor(.gatorTextPrimary)
                        .lineSpacing(6)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                        .background(Color.gatorBackground)
                        .cornerRadius(12)
                }
                .padding(16)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("关闭") {
                        isPresented = false
                    }
                    .foregroundColor(.gatorBrand)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: {
                        // 复制日报到剪贴板
                        UIPasteboard.general.string = reportText
                    }) {
                        Image(systemName: "doc.on.doc")
                            .foregroundColor(.gatorBrand)
                    }
                }
            }
        }
    }
}

// MARK: - ==================== 圆角扩展 ====================

extension View {
    /// 为特定角设置圆角
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

/// 自定义圆角形状
struct RoundedCorner: Shape {
    let radius: CGFloat
    let corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// MARK: - ==================== 主页面 ====================

/// 主页面视图，组合所有子组件
struct GatorHomeView: View {
    @StateObject private var viewModel = GatorViewModel()
    @State private var showMoreMenu = false

    var body: some View {
        ZStack(alignment: .bottom) {
            // 主内容区域（米白背景）
            Color.gatorBackground
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // 1. 导航栏
                GatorNavigationBar()

                // 2. 搜索框
                GatorSearchBar(text: $viewModel.searchText)
                    .padding(.top, 8)
                    .padding(.bottom, 16)

                // 3. 可滚动内容区域
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 0) {
                        // 4. 欢迎卡片
                        WelcomeCard {
                            viewModel.showCreateModal = true
                        }
                        .padding(.bottom, 20)

                        // 5. 标签栏
                        GatorTagBar(selectedTag: $viewModel.selectedTag)
                            .padding(.bottom, 8)

                        // 6. 时间分组 + 双列卡片网格
                        if viewModel.groupedItems.isEmpty {
                            // 空状态
                            VStack(spacing: 16) {
                                Image(systemName: "tray")
                                    .font(.system(size: 48))
                                    .foregroundColor(.gatorTextSecondary.opacity(0.5))
                                Text("暂无内容")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gatorTextSecondary)
                                Text("点击下方 + 按钮开始记录")
                                    .font(.system(size: 14))
                                    .foregroundColor(.gatorTextSecondary.opacity(0.7))
                            }
                            .padding(.top, 60)
                        } else {
                            ForEach(viewModel.groupedItems, id: \.0) { groupName, items in
                                // 时间分组标题
                                TimeGroupHeader(title: groupName)

                                // 双列卡片网格
                                GatorCardGrid(items: items) { item in
                                    viewModel.deleteItem(item)
                                }
                                .padding(.bottom, 8)
                            }
                        }

                        // 底部留白（避免被浮动按钮遮挡）
                        Spacer(minLength: 120)
                    }
                }
            }

            // 7. 底部浮动按钮栏
            VStack(spacing: 0) {
                GatorFloatingBar(
                    onAdd: {
                        viewModel.showCreateModal = true
                    },
                    onMore: {
                        viewModel.generateDailyReport()
                    },
                    onDocument: {
                        viewModel.generateDailyReport()
                    }
                )
            }

            // 8. 右下角帮助悬浮按钮
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    HelpFloatingButton()
                }
            }
            .padding(.bottom, 90)
        }
        // 9. 文本输入模态框（底部弹出）
        .sheet(isPresented: $viewModel.showCreateModal) {
            CreateContentModal(
                isPresented: $viewModel.showCreateModal,
                text: $viewModel.newContentText,
                selectedType: $viewModel.newContentType,
                onConfirm: {
                    viewModel.addItem(
                        content: viewModel.newContentText,
                        type: viewModel.newContentType
                    )
                }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        // 10. 日报面板
        .sheet(isPresented: $viewModel.showDailyReport) {
            DailyReportView(
                isPresented: $viewModel.showDailyReport,
                reportText: $viewModel.dailyReportText
            )
        }
    }
}

// MARK: - ==================== App 入口 ====================

/// Gator App 入口
@main
struct GatorApp: App {
    var body: some Scene {
        WindowGroup {
            GatorHomeView()
                .preferredColorScheme(.light)  // 强制浅色模式，匹配 Figma 设计
        }
    }
}

// MARK: - ==================== SwiftUI 预览 ====================

#Preview("Gator 主页面预览") {
    GatorHomeView()
        .preferredColorScheme(.light)
}

#Preview("导航栏预览") {
    VStack(spacing: 0) {
        GatorNavigationBar()
        Spacer()
    }
    .background(Color.gatorBackground)
    .previewLayout(.sizeThatFits)
    .frame(height: 80)
}

#Preview("搜索框预览") {
    VStack(spacing: 16) {
        GatorSearchBar(text: .constant(""))
        GatorSearchBar(text: .constant("SwiftUI"))
    }
    .background(Color.gatorBackground)
    .padding(.top, 16)
    .previewLayout(.sizeThatFits)
}

#Preview("欢迎卡片预览") {
    ScrollView {
        WelcomeCard {
            print("开始体验被点击")
        }
    }
    .background(Color.gatorBackground)
    .previewLayout(.sizeThatFits)
    .frame(height: 260)
}

#Preview("标签栏预览") {
    struct TagPreviewWrapper: View {
        @State var selected = ContentType.all
        var body: some View {
            VStack(spacing: 16) {
                GatorTagBar(selectedTag: $selected)
                Text("当前选中：\(selected.rawValue)")
                    .font(.system(size: 14))
                    .foregroundColor(.gatorTextSecondary)
            }
        }
    }
    return TagPreviewWrapper()
        .background(Color.gatorBackground)
        .padding(.vertical, 16)
        .previewLayout(.sizeThatFits)
}

#Preview("内容卡片预览") {
    ScrollView {
        LazyVGrid(columns: [
            GridItem(.flexible(), spacing: 12),
            GridItem(.flexible(), spacing: 12)
        ], spacing: 12) {
            GatorItemCard(
                item: GatorItem(
                    content: "今天学习了 SwiftUI 的 LazyVGrid 布局，双列瀑布流效果很好",
                    type: .record,
                    sourceIcon: "book",
                    sourceName: "笔记",
                    tags: ["SwiftUI", "学习"]
                ),
                onDelete: {}
            )
            GatorItemCard(
                item: GatorItem(
                    content: "发现了一个很好的 API 设计模式：RESTful + GraphQL 混合架构",
                    type: .clue,
                    sourceIcon: "link",
                    sourceName: "收藏",
                    tags: ["API", "架构"]
                ),
                onDelete: {}
            )
            GatorItemCard(
                item: GatorItem(
                    content: "可以用 AI 来自动生成日报摘要，节省每天 15 分钟",
                    type: .idea,
                    sourceIcon: "brain",
                    sourceName: "想法",
                    tags: ["AI"]
                ),
                onDelete: {}
            )
            GatorItemCard(
                item: GatorItem(
                    content: "收集了 5 篇关于 Swift Concurrency 的优质文章",
                    type: .collection,
                    sourceIcon: "safari",
                    sourceName: "网页",
                    tags: ["Swift", "文章"]
                ),
                onDelete: {}
            )
        }
        .padding(16)
    }
    .background(Color.gatorBackground)
    .previewLayout(.sizeThatFits)
    .frame(height: 500)
}

#Preview("底部浮动按钮栏预览") {
    ZStack {
        Color.gatorBackground.ignoresSafeArea()
        VStack {
            Spacer()
            GatorFloatingBar(
                onAdd: { print("添加") },
                onMore: { print("更多") },
                onDocument: { print("文档") }
            )
        }
    }
    .frame(height: 200)
    .previewLayout(.sizeThatFits)
}

#Preview("帮助悬浮按钮预览") {
    ZStack {
        Color.gatorBackground.ignoresSafeArea()
        VStack {
            Spacer()
            HStack {
                Spacer()
                HelpFloatingButton()
            }
        }
    }
    .frame(height: 200)
    .previewLayout(.sizeThatFits)
}

#Preview("文本输入模态框预览") {
    struct ModalPreviewWrapper: View {
        @State var isPresented = true
        @State var text = ""
        @State var selectedType: ContentType = .record
        var body: some View {
            Color.gatorBackground
                .ignoresSafeArea()
                .sheet(isPresented: $isPresented) {
                    CreateContentModal(
                        isPresented: $isPresented,
                        text: $text,
                        selectedType: $selectedType,
                        onConfirm: {
                            print("保存内容：\(text)")
                        }
                    )
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
                }
        }
    }
    return ModalPreviewWrapper()
}

#Preview("标签组件预览") {
    VStack(alignment: .leading, spacing: 12) {
        HStack(spacing: 8) {
            TagLabel(text: "记录", color: .orange)
            TagLabel(text: "线索", color: .green)
            TagLabel(text: "想法", color: .purple)
            TagLabel(text: "#SwiftUI", color: .gatorTextSecondary)
            TagLabel(text: "#学习", color: .gatorTextSecondary)
        }
    }
    .padding(16)
    .background(Color.white)
    .cornerRadius(16)
    .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 2)
    .padding(16)
    .previewLayout(.sizeThatFits)
}

#Preview("完整 App 深色模式兼容性检查") {
    GatorHomeView()
        .preferredColorScheme(.dark)
}
