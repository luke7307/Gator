// Gator - 信息效率工具箱
const STORAGE_KEY = 'gator_items_v4';
const BG_COLOR_KEY = 'gator_bg_color';
const LAYOUT_KEY = 'gator_layout';
const NOTEBOOKS_KEY = 'gator_notebooks';
const CURRENT_NOTEBOOK_KEY = 'gator_current_notebook';
const THEME_KEY = 'gator_theme';
const TAGS_KEY = 'gator_tags';
const EMOJI_RECENT_KEY = 'gator_emoji_recent';

// 主题色配置
const THEMES = {
    blue: {
        primary: '#3B82F6', primaryDark: '#2563EB', primaryLight: '#DBEAFE',
        primaryFaint: '#EFF6FF', bg: '#EFF6FF',
        gradient: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)',
        complementary: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)'
    },
    purple: {
        primary: '#8B5CF6', primaryDark: '#7C3AED', primaryLight: '#EDE9FE',
        primaryFaint: '#F5F3FF', bg: '#F5F3FF',
        gradient: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
        complementary: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)'
    },
    green: {
        primary: '#10B981', primaryDark: '#059669', primaryLight: '#D1FAE5',
        primaryFaint: '#ECFDF5', bg: '#ECFDF5',
        gradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
        complementary: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)'
    },
    orange: {
        primary: '#F59E0B', primaryDark: '#D97706', primaryLight: '#FEF3C7',
        primaryFaint: '#FFFBEB', bg: '#FFFBEB',
        gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)',
        complementary: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)'
    },
    pink: {
        primary: '#EC4899', primaryDark: '#DB2777', primaryLight: '#FCE7F3',
        primaryFaint: '#FDF2F8', bg: '#FDF2F8',
        gradient: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)',
        complementary: 'linear-gradient(135deg, #14B8A6 0%, #0D9488 100%)'
    },
    red: {
        primary: '#EF4444', primaryDark: '#DC2626', primaryLight: '#FEE2E2',
        primaryFaint: '#FEF2F2', bg: '#FEF2F2',
        gradient: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)',
        complementary: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)'
    },
    teal: {
        primary: '#14B8A6', primaryDark: '#0D9488', primaryLight: '#CCFBF1',
        primaryFaint: '#F0FDFA', bg: '#F0FDFA',
        gradient: 'linear-gradient(135deg, #14B8A6 0%, #0D9488 100%)',
        complementary: 'linear-gradient(135deg, #F43F5E 0%, #E11D48 100%)'
    },
    dark: {
        primary: '#374151', primaryDark: '#1F2937', primaryLight: '#E5E7EB',
        primaryFaint: '#F3F4F6', bg: '#F3F4F6',
        gradient: 'linear-gradient(135deg, #374151 0%, #1F2937 100%)',
        complementary: 'linear-gradient(135deg, #14B8A6 0%, #0D9488 100%)'
    }
};

// 默认标签配置
const DEFAULT_TAGS = [
    { id: 'all', name: '全部', emoji: '', editable: false, deletable: false },
    { id: 'efficiency', name: '效率', emoji: '⚡', editable: true, deletable: true },
    { id: 'tool', name: '工具', emoji: '🛠️', editable: true, deletable: true },
    { id: 'collect', name: '收藏', emoji: '⭐', editable: true, deletable: true },
    { id: 'custom', name: '自定义', emoji: '🔧', editable: true, deletable: true }
];

// 效率/办公/工具类 emoji（放在最前面）
const EFFICIENCY_EMOJIS = [
    '💡','⚡','🔥','✨','⭐','🎯','📌','📎','✏️','📝','📋','📁','📂','🗂️','📊','📈','📉',
    '🗓️','📅','⏰','⏱️','🔑','🔒','🔓','⚙️','🛠️','🔧','🔨','🧲','📐','📏','✂️','🏷️','🔍','🔎',
    '💻','📱','📲','🖥️','⌨️','🖨️','🖱️','💾','💿','📀','📷','📸','📹','🎥','📞','☎️','📟','📠',
    '📺','📻','🎙️','🎚️','🎛️','🧭','📡','🔋','🔌','🔦','🏮','🧯','💸','💵','💴','💶','💷','💰',
    '💳','💎','⚖️','🪜','🧰','🪛','🧨','🪓','🔪','🗡️','⚔️','🛡️','🔮','📿','🧿','💈','⚗️','🔭',
    '🔬','🧬','🦠','🧫','🧪','🌡️','🧹','🧺','🧻','🚽','🚰','🚿','🛁','🛀','🧼','🪥','🪒','🧽',
    '🪣','🧴','🛎️','🗝️','🚪','🪑','🛋️','🛏️','🛌','🧸','🪆','🖼️','🪞','🪟','🛍️','🛒','🎁','🎈',
    '🎏','🎀','🪄','🪅','🎊','🎉','✉️','📩','📨','📧','💌','📥','📤','📦','📜','📃','📄','📑',
    '🧾','🔖','🧷','🔗','🖇️','🪝','🪡','🧵','🧶','🪢','🪪','🪫','🪬'
];

// 内置 Emoji 图标库（去重，效率类在前，笑脸类在后）
const EMOJI_LIBRARY = (() => {
    const allEmojis = [
        // 效率/办公/工具类（放在最前面）
        ...EFFICIENCY_EMOJIS,
        // 笑脸类
        '😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','😉','😊','😇','🥰','😍','🤩',
        '😘','😗','😚','😙','🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🫡',
        '🤐','🤨','😐','😑','😶','🫥','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴',
        '😷','🤒','🤕','🤢','🤮','🥵','🥶','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐',
        '😕','🫤','😟','🙁','😮','😯','😲','😳','🥺','🥹','😦','😧','😨','😰','😥','😢',
        '😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀',
        '💩','🤡','👹','👺','👻','👽','👾','🤖','😺','😸','😹','😻','😼','😽','🙀','😿',
        '😾','❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗',
        '💖','💘','💝','💟','☮️','✝️','☪️','🕉','☸️','✡️','🔯','🕎','☯️','☦️','🛐','⛎',
        '♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓','🆔','⚛️','🉑','☢️',
        '☣️','📴','📳','🈶','🈚','🈸','🈺','🈷️','✴️','🆚','💮','🉐','㊙️','㊗️','🈴','🈵',
        '🈹','🈲','🅰️','🅱️','🆎','🆑','🅾️','🆘','❌','⭕','🛑','⛔','📛','🚫','💯','💢',
        '♨️','🚷','🚯','🚳','🚱','🔞','📵','🚭','❗','❕','❓','❔','‼️','⁉️','🔅','🔆',
        '〽️','⚠️','🚸','🔱','⚜️','🔰','♻️','✅','🈯','💹','❇️','✳️','❎','🌐','💠','Ⓜ️',
        '🌀','💤','🏧','🚾','♿','🅿️','🈳','🈂️','🛂','🛃','🛄','🛅','🚹','🚺','🚼','⚧️',
        '🚻','🚮','🎦','📶','🈁','🔣','ℹ️','🔤','🔡','🔠','🆖','🆗','🆙','🆒','🆕','🆓',
        '0️⃣','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟','🔢','#️⃣','*️⃣','⏏️','▶️',
        '⏸️','⏯️','⏹️','⏺️','⏭️','⏮️','⏩','⏪','⏫','⏬','◀️','🔼','🔽','➡️','⬅️','⬆️',
        '⬇️','↗️','↘️','↙️','↖️','↕️','↔️','↪️','↩️','⤴️','⤵️','🔀','🔁','🔂','🔄','🔃',
        '🎵','🎶','➕','➖','➗','✖️','🟰','♾️','💲','💱','™️','©️','®️','👁️‍🗨️','🔚','🔙',
        '🔛','🔝','🔜','〰️','➰','➿','✔️','☑️','🔘','🔴','🟠','🟡','🟢','🔵','🟣','⚫',
        '⚪','🟤','🔺','🔻','🔸','🔹','🔶','🔷','🔳','🔲','▪️','▫️','◾','◽','◼️','◻️',
        '🟥','🟧','🟨','🟩','🟦','🟪','⬛','⬜','🟫','🔈','🔇','🔉','🔊','🔔','🔕','📣',
        '📢','💬','💭','🗯️','♠️','♣️','♥️','♦️','🃏','🎴','🀄','🕐','🕑','🕒','🕓','🕔',
        '🕕','🕖','🕗','🕘','🕙','🕚','🕛','🕜','🕝','🕞','🕟','🕠','🕡','🕢','🕣','🕤',
        '🕥','🕦','🕧','🕯️','🪔','🛢️','🪙','⛏️','🪚','🔩','🪤','🧱','⛓️','🔫','💣',
        '🚬','⚰️','🪦','⚱️','🏺','🕳️','🩹','🩺','🩻','💊','💉','🩸','🪠',
        '🗑️','📇','🗃️','🗳️','🗄️','🗞️','📰','📓','📔','📒','📕','📗','📘','📙','📚','📖',
        '📍','🖊️','🖋️','✒️','🖌️','🖍️','🔏','🔐','🪧','📪','📫','📬','📭','📮','📯',
        '🧮','⌛','⏳','🕰️','📼','📽️','🎞️','🖲️','🕹️','🗜️',
        '🌟','💫','🌈','☀️','🌤️','⛅','🌥️','☁️','🌦️','🌧️','⛈️','🌩️',
        '🌨️','❄️','☃️','⛄','🌬️','🌪️','🌫️','🌊','💧','💦','☔','🫧','🪷','🪹',
        '🪺','🌿','🍀','🌱','🌲','🌳','🌴','🌵','🌾','☘️','🍁','🍂','🍃','🍄','🪴',
        '🌰','🫒','🫐','🍇','🍈','🍉','🍊','🍋','🍌','🍍','🥭','🍎','🍏','🍐','🍑','🍒',
        '🍓','🥝','🍅','🥥','🥑','🍆','🥔','🥕','🌽','🌶️','🫑','🥒','🥬','🥦','🧄','🧅',
        '🥜','🫘','🍞','🥐','🥖','🫓','🥨','🥯','🥞','🧇','🧀','🍖','🍗','🥩','🥓','🍔',
        '🍟','🍕','🌭','🥪','🌮','🌯','🫔','🥙','🧆','🥚','🍳','🥘','🍲','🫕','🥣','🥗','🍿',
        '🧈','🥫','🍱','🍘','🍙','🍚','🍛','🍜','🍝','🍠','🍢','🍣','🍤','🍥','🥮','🍡',
        '🥟','🥠','🥡','🦀','🦞','🦐','🦑','🦪','🍦','🍧','🍨','🍩','🍪','🎂','🍰','🧁',
        '🥧','🍫','🍬','🍭','🍮','🍯','🍼','🥛','☕','🫖','🍵','🧃','🥤','🧋','🍶','🍺',
        '🍻','🥂','🍷','🥃','🍸','🍹','🧉','🍾','🧊','🥄','🍴','🍽️','🥢','🧂',
        '🏆','🥇','🥈','🥉','🏅','🎖️','🏵️','🎗️','🎫','🎟️','🎪','🤹',
        '🎭','🩰','🎨','🎬','🎤','🎧','🎼','🎹','🥁','🪘','🎷','🎺','🎸','🪕','🎻','🎲',
        '♟️','🎯','🎳','🎮','🧩','🪭','🪮','🪯','🪰','🪱','🪲','🪳','🪵','🪶','🪸',
        '🪻','🪼','🪽','🪾','🪿','🫀','🫁','🫂','🫃','🫄','🫅','🫆','🫇','🫈','🫉','🫊',
        '🫋','🫌','🫍','🫎','🫏','🫐','🫑','🫒','🫓','🫔','🫕','🫖','🫗','🫘','🫙','🫚',
        '🫛','🫠','🫡','🫢','🫣','🫤','🫥','🫶','🫷','🫸','🫹','🫺','🩷','🩵','🩶',
        '🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐻‍❄️',
        '🐨','🐯','🦁','🐮','🐷','🐽','🐸','🐵','🙈','🙉','🙊','🐒','🐔','🐧','🐦','🐤',
        '🐣','🐥','🦆','🦅','🦉','🦇','🐺','🐗','🐴','🦄','🐝','🐛','🦋','🐌','🐞',
        '🐜','🦟','🦗','🕷️','🦂','🐢','🐍','🦎','🦖','🦕','🐙','🦑','🦐',
        '🦞','🦀','🐡','🐠','🐟','🐬','🐳','🐋','🦈','🐊','🐅','🐆','🦓','🦍','🦧','🦣',
        '🐘','🦛','🦏','🐪','🐫','🦒','🦘','🦬','🐃','🐂','🐄','🐎','🐖','🐏','🐑','🦙',
        '🐐','🦌','🐕','🐩','🦮','🐕‍🦺','🐈','🐈‍⬛','🪶','🐓','🦃','🦤','🦚','🦜','🦢','🦩',
        '🕊️','🐇','🦝','🦨','🦡','🦫','🦦','🦥','🐁','🐀','🐿️','🦔','🐾','🐉','🐲','🎍','🎋',
        '💐','🌷','🌹','🥀','🌺','🌸','🌼','🌻','🌞','🌝','🌛','🌜','🌚','🌕','🌖','🌗',
        '🌘','🌑','🌒','🌓','🌔','🌙','🌎','🌍','🌏','🪐','☄️',
        '💥','🌪️','☂️','🪩','🪨','🪥','🪤','🪥',
        '⚽','🏀','🏈','⚾','🥎','🎾','🏐','🏉','🥏','🎱','🪀','🏓','🏸','🏒','🏑','🥍',
        '🏏','🪃','🥅','⛳','🪁','🏹','🎣','🤿','🥊','🥋','🎽','🛹','🛼','🛷','⛸️','🥌',
        '🎿','⛷️','🏂','🪂','🏋️','🤼','🤸','🤺','⛹️','🤾','🏌️','🏇','🧘','🏄','🏊','🤽',
        '🚣','🧗','🚴','🚵',
        '🚐','🚗','🚕','🚙','🚌','🚎','🏎️','🚓','🚑','🚒','🚚','🚛','🚜','🛴','🚲',
        '🛵','🏍️','🛺','🚨','🚔','🚍','🚘','🚖','🚡','🚠','🚟','🚃','🚋','🚞','🚝','🚄',
        '🚅','🚈','🚂','🚆','🚇','🚊','🚉','✈️','🛫','🛬','🛩️','💺','🛰️','🚀','🛸','🚁',
        '🛶','⛵','🚤','🛥️','🛳️','⛴️','🚢','⚓','⛽','🚧','🚦','🚥','🚏','🗺️','🗿',
        '🗽','🗼','🏰','🏯','🏟️','🎡','🎢','🎠','⛲','⛱️','🏖️','🏝️','🏜️','🌋','⛰️','🏔️',
        '🗻','🏕️','⛺','🏠','🏡','🏘️','🏚️','🏗️','🏭','🏢','🏬','🏣','🏤','🏥','🏦','🏨',
        '🏪','🏫','🏩','💒','🏛️','⛪','🕌','🕍','🛕','🕋','⛩️','🛤️','🛣️','🗾','🎑','🏞️',
        '🌅','🌄','🌠','🎇','🎆','🏙️','🌃','🌌','🌉','🌁','⌚',
        '🪈','🪇','🪊','🪋','🪌','🪍','🪎','🪏','🪐',
        '🏳️','🏴','🏴‍☠️','🏁','🚩','🏳️‍🌈',
        '🇺🇳','🇦🇫','🇦🇽','🇦🇱','🇩🇿','🇦🇸','🇦🇩','🇦🇴','🇦🇮','🇦🇶','🇦🇬','🇦🇷',
        '🇦🇲','🇦🇼','🇦🇺','🇦🇹','🇦🇿','🇧🇸','🇧🇭','🇧🇩','🇧🇧','🇧🇾','🇧🇪','🇧🇿','🇧🇯','🇧🇲','🇧🇹','🇧🇴',
        '🇧🇦','🇧🇼','🇧🇷','🇮🇴','🇻🇬','🇧🇳','🇧🇬','🇧🇫','🇧🇮','🇰🇭','🇨🇲','🇨🇦','🇮🇨','🇨🇻','🇧🇶','🇰🇾',
        '🇨🇫','🇹🇩','🇨🇱','🇨🇳','🇨🇽','🇨🇨','🇨🇴','🇰🇲','🇨🇬','🇨🇩','🇨🇰','🇨🇷','🇨🇮','🇭🇷','🇨🇺','🇨🇼',
        '🇨🇾','🇨🇿','🇩🇰','🇩🇯','🇩🇲','🇩🇴','🇪🇨','🇪🇬','🇸🇻','🇬🇶','🇪🇷','🇪🇪','🇪🇹','🇪🇺','🇫🇰','🇫🇴',
        '🇫🇯','🇫🇮','🇫🇷','🇬🇫','🇵🇫','🇹🇫','🇬🇦','🇬🇲','🇬🇪','🇩🇪','🇬🇭','🇬🇨','🇬🇷','🇬🇱','🇬🇩','🇬🇵','🇬🇺',
        '🇬🇹','🇬🇬','🇬🇳','🇬🇼','🇬🇾','🇭🇹','🇭🇳','🇭🇰','🇭🇺','🇮🇸','🇮🇳','🇮🇩','🇮🇷','🇮🇶','🇮🇪','🇮🇲',
        '🇮🇱','🇮🇹','🇯🇲','🇯🇵','🇯🇪','🇯🇴','🇰🇿','🇰🇪','🇰🇮','🇽🇰','🇰🇼','🇰🇬','🇱🇦','🇱🇻','🇱🇧','🇱🇸',
        '🇱🇷','🇱🇾','🇱🇮','🇱🇹','🇱🇺','🇲🇴','🇲🇬','🇲🇼','🇲🇾','🇲🇻','🇲🇱','🇲🇹','🇲🇭','🇲🇶','🇲🇷','🇲🇺',
        '🇾🇹','🇲🇽','🇫🇲','🇲🇩','🇲🇨','🇲🇳','🇲🇪','🇲🇸','🇲🇦','🇲🇿','🇲🇲','🇳🇦','🇳🇷','🇳🇵','🇳🇱','🇳🇨',
        '🇳🇿','🇳🇮','🇳🇪','🇳🇬','🇳🇺','🇳🇫','🇰🇵','🇲🇰','🇲🇵','🇳🇴','🇴🇲','🇵🇰','🇵🇼','🇵🇸','🇵🇦','🇵🇬',
        '🇵🇾','🇵🇪','🇵🇭','🇵🇳','🇵🇱','🇵🇹','🇵🇷','🇶🇦','🇷🇪','🇷🇴','🇷🇺','🇷🇼','🇼🇸','🇸🇲','🇸🇹','🇸🇦',
        '🇸🇳','🇷🇸','🇸🇨','🇸🇱','🇸🇬','🇸🇽','🇸🇰','🇸🇮','🇬🇸','🇸🇧','🇸🇴','🇿🇦','🇰🇷','🇸🇸','🇪🇸','🇱🇰',
        '🇧🇱','🇸🇭','🇰🇳','🇱🇨','🇵🇲','🇻🇨','🇸🇩','🇸🇷','🇸🇿','🇸🇪','🇨🇭','🇸🇾','🇹🇼','🇹🇯','🇹🇿','🇹🇭',
        '🇹🇱','🇹🇬','🇹🇰','🇹🇴','🇹🇹','🇹🇳','🇹🇷','🇹🇲','🇹🇨','🇹🇻','🇻🇮','🇺🇬','🇺🇦','🇦🇪','🇬🇧',
        '🇺🇸','🇺🇾','🇺🇿','🇻🇺','🇻🇦','🇻🇪','🇻🇳','🇼🇫','🇪🇭','🇾🇪','🇿🇲','🇿🇼'
    ];
    // 去重
    const seen = new Set();
    const unique = [];
    for (const e of allEmojis) {
        if (!seen.has(e)) { seen.add(e); unique.push(e); }
    }
    return unique;
})();

// 最近使用 emoji 常量
const EMOJI_RECENT = [];

let items = [];
let currentFilter = { tab: 'all', search: '' };
let selectedType = '效率';
let currentLayout = 'list';
let notebooks = [];
let currentNotebookId = 'default';
let deleteTargetId = null;
let renameTargetId = null;
let currentTheme = 'blue';

// 待办 checkbox 点击处理：完成状态随主题色变化
function handleTaskCheck(checkbox) {
    const theme = THEMES[currentTheme] || THEMES.blue;
    const color = theme.primary;
    const div = checkbox.closest('div');
    if (checkbox.checked) {
        div.style.textDecoration = 'line-through';
        div.style.textDecorationColor = color;
        div.style.opacity = '0.5';
        checkbox.style.accentColor = color;
    } else {
        div.style.textDecoration = 'none';
        div.style.opacity = '1';
        checkbox.style.accentColor = '';
    }
}
let detailTargetId = null;
let detailSelectedType = '';
let tags = [];
let timeSortMode = 0; // 0=不排序, 1=新→旧, 2=旧→新
let emojiPickerTarget = null;
let currentEmoji = '💡';
let detailEmoji = '💡';
let newTagEmoji = '🏷️';
let tagScrollTimer = null;
let emojiRecent = []; // 最近使用的 emoji
let inlineTagEmoji = '🏷️'; // 内联新增分类的 emoji

let editTagEmoji = '🏷️';
let editTagId = null;
let showTagCount = false; // 是否在分类标签后显示数量
let imagePreviewMode = false; // 是否启用带图预览模式（图片卡片）
let detailOriginalTitle = '';
let detailOriginalContent = '';
let detailOriginalEmoji = '';
// 滚动位置记忆：{ itemId: { previewScroll: number, editorScroll: number, timestamp: number } }
const scrollPositionCache = {};

// ===== 初始化 =====
document.addEventListener('DOMContentLoaded', () => {
    loadEmojiRecent();
    loadTags();
    // 确保"未分类"tag存在（系统预设，不可编辑/删除/排序）
    if (!tags.find(t => t.name === '未分类')) {
        tags.push({ id: 'tag_uncategorized_default', name: '未分类', emoji: '📋', editable: false, deletable: false, system: true });
        saveTags();
    } else {
        // 修复已有未分类tag的属性为系统预设
        const uc = tags.find(t => t.name === '未分类');
        if (uc) { uc.editable = false; uc.deletable = false; uc.system = true; saveTags(); }
    }
    loadNotebooks();
    loadItems();
    loadSettings();
    // 恢复自定义颜色
    const customColor = localStorage.getItem('gator_custom_color');
    if (customColor && currentTheme === 'custom') {
        applyCustomColor(customColor, false);
    }
    applyTheme(currentTheme, false);
    renderFeed();
    renderTabBar();
    updateNotebookNameDisplay();
    initBannerScroll();
    initBannerHoverPause();
    initMarkdownEditor();
    // 恢复自动轮换
    if (localStorage.getItem('gator_auto_theme') === 'true') {
        startAutoThemeTimer();
    }
    // 窗口大小变化时重新布局瀑布流
    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (currentLayout === 'masonry') {
                layoutMasonry(document.getElementById('feedContainer'));
            }
        }, 150);
    });
});

// ===== 最近使用 emoji =====
function loadEmojiRecent() {
    try {
        const stored = localStorage.getItem(EMOJI_RECENT_KEY);
        if (stored) emojiRecent = JSON.parse(stored);
        else emojiRecent = [];
    } catch (e) { emojiRecent = []; }
}
function saveEmojiRecent() {
    localStorage.setItem(EMOJI_RECENT_KEY, JSON.stringify(emojiRecent));
}

function loadTags() {
    try {
        const stored = localStorage.getItem(TAGS_KEY);
        if (stored) tags = JSON.parse(stored);
        else { tags = JSON.parse(JSON.stringify(DEFAULT_TAGS)); saveTags(); }
    } catch (e) { tags = JSON.parse(JSON.stringify(DEFAULT_TAGS)); }
}
function saveTags() { localStorage.setItem(TAGS_KEY, JSON.stringify(tags)); }

function loadSettings() {
    const savedBg = localStorage.getItem(BG_COLOR_KEY);
    if (savedBg) document.body.style.setProperty('--app-bg', savedBg);
    const savedLayout = localStorage.getItem(LAYOUT_KEY);
    if (savedLayout) { currentLayout = savedLayout; updateLayoutIcon(); }
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme && THEMES[savedTheme]) currentTheme = savedTheme;
    const savedSort = localStorage.getItem('gator_time_sort');
    if (savedSort) timeSortMode = parseInt(savedSort) || 0;
    const savedTagCount = localStorage.getItem('gator_show_tag_count');
    if (savedTagCount) showTagCount = savedTagCount === 'true';
    const savedImagePreview = localStorage.getItem('gator_image_preview_mode');
    if (savedImagePreview) imagePreviewMode = savedImagePreview === 'true';
}

// ===== 主题色管理 =====
function applyTheme(themeName, save = true) {
    const theme = THEMES[themeName] || THEMES.blue;
    currentTheme = themeName;
    document.documentElement.style.setProperty('--theme-primary', theme.primary);
    document.documentElement.style.setProperty('--brand-dark', theme.primary);
    document.documentElement.style.setProperty('--brand-deeper', theme.primaryDark);
    document.documentElement.style.setProperty('--brand-light', theme.primaryLight);
    document.documentElement.style.setProperty('--brand-faint', theme.primaryFaint);
    document.documentElement.style.setProperty('--app-bg', theme.bg);
    document.body.style.background = theme.bg;
    // 更新吸顶区域背景
    const stickyHeader = document.querySelector('.sticky.top-0');
    if (stickyHeader) stickyHeader.style.background = theme.bg;
    const wc = document.querySelector('.welcome-gradient');
    if (wc) wc.style.background = theme.gradient;
    const b2 = document.getElementById('banner2Card');
    if (b2) b2.style.background = theme.complementary;
    document.querySelectorAll('.fab-pulse').forEach(b => b.style.background = theme.primary);
    document.documentElement.style.setProperty('--fab-glow', theme.primary + '66');
    document.querySelectorAll('.text-brand-dark').forEach(el => el.style.color = theme.primary);
    document.querySelectorAll('.bg-brand-dark').forEach(el => el.style.backgroundColor = theme.primary);
    document.querySelectorAll('.bg-brand-light').forEach(el => el.style.backgroundColor = theme.primaryLight);
    document.querySelectorAll('.text-brand-deeper').forEach(el => el.style.color = theme.primaryDark);
    document.querySelectorAll('.bg-brand-faint').forEach(el => el.style.backgroundColor = theme.primaryFaint);
    renderTabBar();
    updateTimeSortBtn();
    updateTypeButtons();
    updateDetailTypeButtons();
    updateTimeSortBtn();
    if (save) localStorage.setItem(THEME_KEY, themeName);
}

// ===== 自定义颜色 =====
// 中国传统色色板（20色 + 1自定义入口 = 21格，5列）
const CUSTOM_PALETTE = [
    { hex: '#FF4E20', name: '丹' },
    { hex: '#CB3A56', name: '茜' },
    { hex: '#DB5A6B', name: '海棠' },
    { hex: '#F47983', name: '桃红' },
    { hex: '#B36D61', name: '檀' },
    { hex: '#FBBF24', name: '缃叶' },
    { hex: '#D97706', name: '琥珀' },
    { hex: '#C9DD22', name: '柳黄' },
    { hex: '#96CE54', name: '豆青' },
    { hex: '#00E079', name: '青翠' },
    { hex: '#70F3FF', name: '蔚蓝' },
    { hex: '#177CB0', name: '靛青' },
    { hex: '#065279', name: '靛蓝' },
    { hex: '#4B5CC4', name: '宝蓝' },
    { hex: '#801DAE', name: '青莲' },
    { hex: '#B0A4E3', name: '雪青' },
    { hex: '#56004F', name: '紫棠' },
    { hex: '#4C221B', name: '紫檀' },
    { hex: '#F2ECDE', name: '缟' },
    { hex: 'custom', name: '自选' },
];

let selectedCustomColor = '#3B82F6';

function openCustomColorPanel() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    selectedCustomColor = theme.primary;
    // 生成色板网格（5列）
    const grid = document.getElementById('customColorGrid');
    grid.innerHTML = CUSTOM_PALETTE.map(c => {
        if (c.hex === 'custom') {
            return `<button onclick="openNativeColorPicker()" class="custom-color-swatch w-full aspect-square rounded-xl flex items-center justify-center btn-press transition-all duration-150" data-color="custom" style="background: conic-gradient(from 0deg, #f87171, #fbbf24, #34d399, #60a5fa, #a78bfa, #f472b6, #f87171);">
                <div class="w-[60%] h-[60%] rounded-lg bg-white flex items-center justify-center">
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                </div>
            </button>`;
        }
        return `<button onclick="selectCustomColor('${c.hex}', '${c.name}')" class="custom-color-swatch w-full aspect-square rounded-xl transition-all duration-150 btn-press" style="background:${c.hex};" data-color="${c.hex}" data-name="${c.name}"></button>`;
    }).join('');
    // 半屏面板缩小隐藏
    const halfPanel = document.getElementById('bgColorPanel');
    halfPanel.style.transform = 'translateY(100%)';
    halfPanel.style.opacity = '0';
    // 自定义面板从底部弹出
    const panel = document.getElementById('customColorPanel');
    panel.style.display = '';
    panel.style.height = 'auto';
    panel.style.opacity = '1';
    panel.style.overflow = 'visible';
    panel.style.visibility = '';
    // 初始化标题和按钮
    updateCustomColorDisplay('丹', theme.primary);
    highlightCustomSwatch();
}

function openNativeColorPicker() {
    const input = document.createElement('input');
    input.type = 'color';
    input.value = selectedCustomColor;
    input.style.position = 'absolute';
    input.style.opacity = '0';
    input.style.width = '0';
    input.style.height = '0';
    document.body.appendChild(input);
    input.addEventListener('input', (e) => {
        selectedCustomColor = e.target.value;
        updateCustomColorDisplay('自选', selectedCustomColor);
        highlightCustomSwatch();
    });
    input.addEventListener('change', () => {
        document.body.removeChild(input);
    });
    input.click();
}

function selectCustomColor(hex, name) {
    selectedCustomColor = hex;
    updateCustomColorDisplay(name || '自选', hex);
    highlightCustomSwatch();
}

function updateCustomColorDisplay(name, hex) {
    const nameEl = document.getElementById('customColorName');
    const btn = document.getElementById('customColorConfirmBtn');
    if (nameEl) {
        nameEl.textContent = name;
        nameEl.style.color = hex;
    }
    if (btn) btn.style.background = hex;
}

function highlightCustomSwatch() {
    document.querySelectorAll('.custom-color-swatch').forEach(s => {
        if (s.dataset.color === selectedCustomColor) {
            s.style.outline = '2.5px solid #1F2937';
            s.style.outlineOffset = '-1px';
            s.style.transform = 'scale(1.15)';
        } else {
            s.style.outline = '';
            s.style.outlineOffset = '';
            s.style.transform = '';
        }
    });
}

function closeCustomColorPanel() {
    const panel = document.getElementById('customColorPanel');
    const halfPanel = document.getElementById('bgColorPanel');
    // 隐藏自定义面板
    panel.style.display = 'none';
    panel.style.height = '0';
    panel.style.overflow = 'hidden';
    panel.style.opacity = '0';
    // 恢复半屏面板（带动画）
    halfPanel.style.transition = 'transform 0.3s cubic-bezier(0.32, 0.72, 0, 1), opacity 0.3s ease';
    halfPanel.style.transform = 'translateY(0)';
    halfPanel.style.opacity = '1';
    setTimeout(() => {
        halfPanel.style.transition = '';
    }, 300);
}

function previewCustomColor(hex) {
    document.getElementById('customColorConfirmBtn').style.background = hex;
}

function confirmCustomColor() {
    // 如果自动轮换开着，关闭它
    const wasAutoTheme = localStorage.getItem('gator_auto_theme') === 'true';
    if (wasAutoTheme) {
        localStorage.removeItem('gator_auto_theme');
        localStorage.removeItem('gator_auto_theme_start');
        if (autoThemeTimer) { clearInterval(autoThemeTimer); autoThemeTimer = null; }
    }
    applyCustomColor(selectedCustomColor, false);
    closeCustomColorPanel();
    closeBgColorModal();
    showFabCheckmark();
    if (wasAutoTheme) {
        showToast('自定义颜色已应用，自动轮换已关闭');
    } else {
        showToast('自定义颜色已应用');
    }
}

function applyCustomColor(hex, close = true) {
    const r = parseInt(hex.slice(1,3), 16);
    const g = parseInt(hex.slice(3,5), 16);
    const b = parseInt(hex.slice(5,7), 16);

    // 计算感知亮度（0-255）
    const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
    const isLight = luminance > 180;

    // 如果颜色太浅，加深主色确保白色文字可读
    let adjustedR = r, adjustedG = g, adjustedB = b;
    if (isLight) {
        const factor = 0.65;
        adjustedR = Math.round(r * factor);
        adjustedG = Math.round(g * factor);
        adjustedB = Math.round(b * factor);
    }

    const darken = (v) => Math.max(0, Math.round(v * 0.75));
    const lighten = (v) => Math.min(255, Math.round(v + (255 - v) * 0.85));
    const fainten = (v) => Math.min(255, Math.round(v + (255 - v) * 0.94));

    const primary = isLight ? `#${adjustedR.toString(16).padStart(2,'0')}${adjustedG.toString(16).padStart(2,'0')}${adjustedB.toString(16).padStart(2,'0')}` : hex;
    const primaryDark = `#${darken(adjustedR).toString(16).padStart(2,'0')}${darken(adjustedG).toString(16).padStart(2,'0')}${darken(adjustedB).toString(16).padStart(2,'0')}`;
    const primaryLight = `#${lighten(r).toString(16).padStart(2,'0')}${lighten(g).toString(16).padStart(2,'0')}${lighten(b).toString(16).padStart(2,'0')}`;
    const primaryFaint = `#${fainten(r).toString(16).padStart(2,'0')}${fainten(g).toString(16).padStart(2,'0')}${fainten(b).toString(16).padStart(2,'0')}`;

    const compR = 255 - r, compG = 255 - g, compB = 255 - b;
    const compDark = (v) => Math.max(0, Math.round(v * 0.85));
    const complementary = `linear-gradient(135deg, rgb(${compR},${compG},${compB}) 0%, rgb(${compDark(compR)},${compDark(compG)},${compDark(compB)}) 100%)`;

    THEMES.custom = {
        primary, primaryDark, primaryLight, primaryFaint,
        bg: primaryFaint,
        gradient: `linear-gradient(135deg, ${primary} 0%, ${primaryDark} 100%)`,
        complementary,
        isLight
    };

    applyTheme('custom');
    localStorage.setItem('gator_theme', 'custom');
    localStorage.setItem('gator_custom_color', hex);
    if (close) {
        closeBgColorModal();
        if (isLight) {
            showToast('已应用自定义颜色，已自动加深保证可读性');
        } else {
            showToast('已应用自定义颜色');
        }
    }

}

let autoThemeTimer = null;

function toggleAutoTheme() {
    const isOn = localStorage.getItem('gator_auto_theme') === 'true';
    if (isOn) {
        // 关闭
        localStorage.removeItem('gator_auto_theme');
        localStorage.removeItem('gator_auto_theme_start');
        if (autoThemeTimer) { clearInterval(autoThemeTimer); autoThemeTimer = null; }
        showToast('已关闭自动轮换');
    } else {
        // 开启
        localStorage.setItem('gator_auto_theme', 'true');
        localStorage.setItem('gator_auto_theme_start', Date.now().toString());
        startAutoThemeTimer();
        showToast('已开启自动轮换，每 12 小时更换');
    }
    updateAutoThemeBtn();
    closeBgColorModal();
    showFabCheckmark();
}

function startAutoThemeTimer() {
    if (autoThemeTimer) clearInterval(autoThemeTimer);
    // 计算距离下一次 12 小时还有多久
    const start = parseInt(localStorage.getItem('gator_auto_theme_start') || '0');
    const elapsed = Date.now() - start;
    const interval = 12 * 60 * 60 * 1000; // 12 小时
    const nextDelay = elapsed >= interval ? 0 : (interval - elapsed);

    // 先检查是否已经过了第一个 12 小时
    if (elapsed >= interval) {
        applyRandomTheme();
        localStorage.setItem('gator_auto_theme_start', Date.now().toString());
    }

    autoThemeTimer = setInterval(() => {
        applyRandomTheme();
        localStorage.setItem('gator_auto_theme_start', Date.now().toString());
    }, interval);
}

function applyRandomTheme() {
    const themeKeys = Object.keys(THEMES);
    const current = currentTheme;
    // 随机选一个不同的主题
    let next;
    do { next = themeKeys[Math.floor(Math.random() * themeKeys.length)]; } while (next === current && themeKeys.length > 1);
    applyTheme(next);
    localStorage.setItem('gator_theme', next);
}

function updateAutoThemeBtn() {
    const btn = document.getElementById('autoThemeBtn');
    const icon = document.getElementById('autoThemeIcon');
    const text = document.getElementById('autoThemeText');
    if (!btn) return;
    const isOn = localStorage.getItem('gator_auto_theme') === 'true';
    const theme = THEMES[currentTheme] || THEMES.blue;
    if (isOn) {
        btn.style.background = theme.primaryLight;
        btn.style.color = theme.primaryDark;
        text.textContent = '自动轮换中';
        if (icon) icon.style.transform = 'rotate(0deg)';
    } else {
        btn.style.background = '';
        btn.style.color = '';
        text.textContent = '自动轮换';
        if (icon) icon.style.transform = '';
    }
}

function getContrastColor(hex) {
    const r = parseInt(hex.slice(1,3), 16);
    const g = parseInt(hex.slice(3,5), 16);
    const b = parseInt(hex.slice(5,7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#1F2937' : '#FFFFFF';
}

function updateThemeColorSelection() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    document.querySelectorAll('.theme-color-btn').forEach(btn => {
        // 移除旧的选中标记
        const old = btn.querySelector('.theme-check');
        if (old) old.remove();
        btn.style.outline = '';

        if (btn.dataset.theme === currentTheme) {
            // 添加强调色选中框
            btn.style.outline = `2.5px solid ${theme.primaryDark}`;
            btn.style.outlineOffset = '-2.5px';
            // 添加对勾（使用背景色的对比色）
            const bg = getComputedStyle(btn).backgroundColor;
            const rgb = bg.match(/\d+/g);
            const hex = rgb ? '#' + rgb.slice(0,3).map(v => parseInt(v).toString(16).padStart(2,'0')).join('') : '#DBEAFE';
            const contrast = getContrastColor(hex);
            const check = document.createElement('div');
            check.className = 'theme-check absolute inset-0 flex items-center justify-center';
            check.innerHTML = `<svg class="w-5 h-5 drop-shadow-sm" fill="none" stroke="${contrast}" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`;
            btn.appendChild(check);
        }
    });
}

function setThemeColor(themeName) {
    applyTheme(themeName);
    closeBgColorModal();
    showFabCheckmark();
    showToast('主题颜色已更改');
}

// ===== 标签栏渲染（全部固定左侧，其余可滚动，齿轮固定右侧）=====
function renderTabBar() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    const scrollArea = document.getElementById('tagScrollArea');
    if (!scrollArea) return;

    // 更新"全部"按钮样式和文字
    const allBtn = document.querySelector('.tab-btn[data-tab="all"]');
    if (allBtn) {
        const allCount = showTagCount ? items.length : 0;
        const allCountStr = showTagCount && allCount > 0 ? ` ${allCount}` : '';
        allBtn.textContent = `全部${allCountStr}`;
        if (currentFilter.tab === 'all') {
            allBtn.style.backgroundColor = theme.primary;
            allBtn.style.color = '#fff';
        } else {
            allBtn.style.backgroundColor = theme.primaryLight;
            allBtn.style.color = theme.primaryDark;
        }
    }

    // 渲染滚动区域内的 tag 按钮（排除"全部"，未分类优先显示，无灵感时隐藏）
    scrollArea.innerHTML = '';
    const sortedTags = tags.filter(t => t.id !== 'all').sort((a, b) => {
        if (a.system) return -1;  // 系统预设（未分类）排最前
        if (b.system) return 1;
        return 0;
    });
    sortedTags.forEach(tag => {
        // 未分类：无灵感时隐藏
        if (tag.system && items.filter(i => i.type === tag.name).length === 0) return;
        const btn = document.createElement('button');
        btn.className = 'tab-btn px-4 py-2 rounded-full text-[14px] whitespace-nowrap transition flex-shrink-0';
        btn.dataset.tab = tag.id;
        btn.onclick = () => filterByTab(tag.id);
        // 分类数量
        const count = showTagCount ? items.filter(i => i.type === tag.name).length : 0;
        const countStr = showTagCount && count > 0 ? ` ${count}` : '';
        btn.textContent = tag.emoji ? `${tag.emoji} ${tag.name}${countStr}` : `${tag.name}${countStr}`;

        if (tag.id === currentFilter.tab) {
            btn.classList.add('font-medium');
            btn.style.backgroundColor = theme.primary;
            btn.style.color = '#fff';
        } else {
            btn.style.backgroundColor = theme.primaryLight;
            btn.style.color = theme.primaryDark;
        }
        scrollArea.appendChild(btn);
    });
}

// ===== 未分类清空检测 =====
// 当未分类下最后一个灵感被删除或移走时，自动跳转全部并提示
function checkUncategorizedEmpty() {
    const ucTag = tags.find(t => t.name === '未分类');
    if (!ucTag) return false;
    const ucCount = items.filter(i => i.type === '未分类').length;
    if (ucCount === 0 && currentFilter.tab === ucTag.id) {
        currentFilter.tab = 'all';
        renderTabBar();
        renderFeed();
        showFabCheckmark();
        showToast('已全部完成分类');
        return true;
    }
    // 即使不在未分类页，也要刷新分类栏（隐藏未分类标签）
    if (ucCount === 0) {
        renderTabBar();
    }
    return false;
}

// ===== 标签滚动指示器（根据 scrollLeft 和 scrollWidth 计算进度条宽度）=====
function showTagScrollIndicator() {
    const indicator = document.getElementById('tagScrollIndicator');
    const scrollArea = document.getElementById('tagScrollArea');
    if (!indicator || !scrollArea) return;

    const scrollLeft = scrollArea.scrollLeft;
    const scrollWidth = scrollArea.scrollWidth;
    const clientWidth = scrollArea.clientWidth;
    const maxScroll = scrollWidth - clientWidth;

    if (maxScroll <= 0) { indicator.style.opacity = '0'; return; }

    // 计算滚动进度百分比，指示器宽度 = (可见区域 / 总宽度) * 100%
    const viewRatio = clientWidth / scrollWidth;
    const indicatorWidth = Math.max(viewRatio * 100, 20); // 最小 20%
    // 计算指示器偏移
    const scrollRatio = scrollLeft / maxScroll;
    const maxOffset = 100 - indicatorWidth;
    const indicatorOffset = scrollRatio * maxOffset;

    indicator.style.width = indicatorWidth + '%';
    indicator.style.marginLeft = indicatorOffset + '%';
    indicator.style.opacity = '1';
    clearTimeout(tagScrollTimer);
    tagScrollTimer = setTimeout(() => {
        indicator.style.opacity = '0';
    }, 1000);
}

// ===== 笔记簿管理 =====
function loadNotebooks() {
    try {
        const stored = localStorage.getItem(NOTEBOOKS_KEY);
        if (stored) notebooks = JSON.parse(stored);
        else { notebooks = [{ id: 'default', name: '默认笔记簿', createdAt: new Date().toISOString() }]; saveNotebooks(); }
    } catch (e) { notebooks = [{ id: 'default', name: '默认笔记簿', createdAt: new Date().toISOString() }]; }
    const savedCurrent = localStorage.getItem(CURRENT_NOTEBOOK_KEY);
    if (savedCurrent) currentNotebookId = savedCurrent;
}
function saveNotebooks() {
    localStorage.setItem(NOTEBOOKS_KEY, JSON.stringify(notebooks));
    localStorage.setItem(CURRENT_NOTEBOOK_KEY, currentNotebookId);
}
function getCurrentNotebookName() {
    const nb = notebooks.find(n => n.id === currentNotebookId);
    return nb ? nb.name : '默认笔记簿';
}
function updateNotebookNameDisplay() {
    const el = document.getElementById('currentNotebookName');
    if (el) el.textContent = getCurrentNotebookName();
}
function toggleNotebookMenu() {
    const m = document.getElementById('notebookMenuModal');
    if (m.classList.contains('hidden')) { renderNotebookList(); m.classList.remove('hidden'); }
    else m.classList.add('hidden');
}
function closeNotebookMenu() { document.getElementById('notebookMenuModal').classList.add('hidden'); showFabCheckmark(); }

function renderNotebookList() {
    const list = document.getElementById('notebookList');
    const theme = THEMES[currentTheme] || THEMES.blue;
    list.innerHTML = notebooks.map(nb => {
        const isActive = nb.id === currentNotebookId;
        const isDefault = nb.id === 'default';
        // 图标背景跟随主题色
        const iconBg = isActive ? theme.primary : theme.primaryLight;
        const iconColor = isActive ? '#fff' : theme.primaryDark;
        const nameColor = isActive ? theme.primary : '#111827';
        return `<div class="flex items-center justify-between px-4 py-3 transition cursor-pointer" style="background: ${isActive ? theme.primaryFaint : 'transparent'}" onclick="switchNotebook('${nb.id}')">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style="background: ${iconBg}">
                    <svg class="w-4 h-4" style="color: ${iconColor}" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                </div>
                <div>
                    <p class="text-[14px] font-medium" style="color: ${nameColor}">${escapeHtml(nb.name)}</p>
                    <p class="text-[11px] text-gray-400">${getNotebookItemCount(nb.id)} 条灵感</p>
                </div>
            </div>
            <div class="flex items-center gap-1">
                ${isActive ? `<span class="text-[12px] font-medium mr-1" style="color: ${theme.primary}">当前</span>` : ''}
                <button onclick="event.stopPropagation(); showRenameNotebookModal('${nb.id}')" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition btn-press">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                </button>
                ${!isDefault ? `<button onclick="event.stopPropagation(); showDeleteNotebookModal('${nb.id}')" class="w-8 h-8 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-400 hover:text-red-500 transition btn-press">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>` : ''}
            </div>
        </div>`;
    }).join('');
}
function getNotebookItemCount(id) {
    try { const s = localStorage.getItem(STORAGE_KEY + '_' + id); return s ? JSON.parse(s).length : 0; } catch(e) { return 0; }
}
function switchNotebook(id) {
    currentNotebookId = id; saveNotebooks(); loadItems(); renderFeed(); updateNotebookNameDisplay();
    closeNotebookMenu(); showFabCheckmark(); showToast('已切换到 ' + getCurrentNotebookName());
}

let deleteNotebookTargetId = null;
function showDeleteNotebookModal(id) {
    deleteNotebookTargetId = id;
    const nb = notebooks.find(n => n.id === id);
    if (!nb) return;
    document.getElementById('deleteNotebookName').textContent = nb.name;
    document.getElementById('deleteNotebookModal').classList.remove('hidden');
}
function closeDeleteNotebookModal() { document.getElementById('deleteNotebookModal').classList.add('hidden'); deleteNotebookTargetId = null; }
function confirmDeleteNotebook() {
    if (!deleteNotebookTargetId) { closeDeleteNotebookModal(); return; }
    const nb = notebooks.find(n => n.id === deleteNotebookTargetId);
    if (nb && nb.id !== 'default') {
        localStorage.removeItem(STORAGE_KEY + '_' + deleteNotebookTargetId);
        notebooks = notebooks.filter(n => n.id !== deleteNotebookTargetId);
        saveNotebooks();
        if (currentNotebookId === deleteNotebookTargetId) {
            currentNotebookId = 'default'; saveNotebooks(); loadItems(); renderFeed(); updateNotebookNameDisplay();
        }
        renderNotebookList();
        showToast('笔记簿已删除');
    }
    closeDeleteNotebookModal();
}

function showCreateNotebookModal() {
    closeNotebookMenu();
    document.getElementById('createNotebookModal').classList.remove('hidden');
    document.getElementById('newNotebookName').value = '';
    setTimeout(() => document.getElementById('newNotebookName').focus(), 100);
}
function closeCreateNotebookModal() { document.getElementById('createNotebookModal').classList.add('hidden'); }
function createNotebook() {
    const name = document.getElementById('newNotebookName').value.trim();
    if (!name) { showToast('请输入笔记簿名称'); return; }
    const newId = 'nb_' + Date.now();
    notebooks.push({ id: newId, name, createdAt: new Date().toISOString() });
    saveNotebooks(); closeCreateNotebookModal();
    switchNotebook(newId);
    showFabCheckmark();
    showToast('笔记簿创建成功');
}
function showRenameNotebookModal(id) {
    renameTargetId = id;
    const nb = notebooks.find(n => n.id === id);
    if (!nb) return;
    document.getElementById('renameNotebookInput').value = nb.name;
    document.getElementById('renameNotebookModal').classList.remove('hidden');
    setTimeout(() => document.getElementById('renameNotebookInput').focus(), 100);
}
function closeRenameNotebookModal() { document.getElementById('renameNotebookModal').classList.add('hidden'); renameTargetId = null; }
function confirmRenameNotebook() {
    const n = document.getElementById('renameNotebookInput').value.trim();
    if (!n) { showToast('请输入新名称'); return; }
    const nb = notebooks.find(x => x.id === renameTargetId);
    if (nb) { nb.name = n; saveNotebooks(); updateNotebookNameDisplay(); renderNotebookList(); showToast('重命名成功'); }
    closeRenameNotebookModal();
}

// ===== 数据管理 =====
function getStorageKey() { return STORAGE_KEY + '_' + currentNotebookId; }
function loadItems() { try { const s = localStorage.getItem(getStorageKey()); items = s ? JSON.parse(s) : []; } catch(e) { items = []; } }
function saveItems() { localStorage.setItem(getStorageKey(), JSON.stringify(items)); }

// ===== 背景颜色 =====
function toggleBgColor() {
    document.getElementById('bgColorModal').classList.remove('hidden');
    updateAutoThemeBtn();
    updateThemeColorSelection();
}
function closeBgColorModal() {
    document.getElementById('bgColorModal').classList.add('hidden');
    // 重置面板状态
    const halfPanel = document.getElementById('bgColorPanel');
    halfPanel.style.transform = '';
    halfPanel.style.opacity = '';
    const customPanel = document.getElementById('customColorPanel');
    customPanel.style.height = '0';
    customPanel.style.opacity = '0';
    customPanel.style.overflow = 'hidden';
    showFabCheckmark();
}

// ===== 布局切换 =====
let isAnimatingLayout = false;
function toggleLayout() {
    if (isAnimatingLayout) return;
    isAnimatingLayout = true;
    currentLayout = currentLayout === 'list' ? 'masonry' : 'list';
    localStorage.setItem(LAYOUT_KEY, currentLayout);
    const icon = document.getElementById('layoutIcon');
    icon.style.transform = 'rotate(180deg) scale(0.8)'; icon.style.opacity = '0.5';
    const container = document.getElementById('feedContainer');
    // 淡出
    container.style.transition = 'opacity 0.3s ease';
    container.style.opacity = '0';
    setTimeout(() => {
        updateLayoutIcon();
        icon.style.transform = 'rotate(0deg) scale(1)'; icon.style.opacity = '1';
        renderFeed();
        showFabLayoutIcon();
        showToast(currentLayout === 'masonry' ? '已切换为瀑布流' : '已切换为卡片流');
        requestAnimationFrame(() => {
            container.style.transition = 'opacity 0.3s ease';
            container.style.opacity = '1';
            setTimeout(() => { isAnimatingLayout = false; }, 300);
        });
    }, 150);
}
function updateLayoutIcon() {
    const icon = document.getElementById('layoutIcon');
    icon.innerHTML = currentLayout === 'list'
        ? '<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>'
        : '<path stroke-linecap="round" stroke-linejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>';
}

// ===== 标签筛选 =====
function filterByTab(tab) {
    currentFilter.tab = tab;
    renderTabBar();
    renderFeed();
    // 滚动标签到可视区域中央
    setTimeout(() => {
        const scrollArea = document.getElementById('tagScrollArea');
        if (!scrollArea) return;
        if (tab === 'all') {
            scrollArea.scrollTo({ left: 0, behavior: 'smooth' });
            return;
        }
        const btn = scrollArea.querySelector(`[data-tab="${tab}"]`);
        if (btn) {
            const areaRect = scrollArea.getBoundingClientRect();
            const btnRect = btn.getBoundingClientRect();
            const scrollLeft = btnRect.left - areaRect.left + scrollArea.scrollLeft - (areaRect.width / 2) + (btnRect.width / 2);
            scrollArea.scrollTo({ left: Math.max(0, scrollLeft), behavior: 'smooth' });
        }
    }, 50);
}

// ===== 搜索 =====
function handleSearch() { currentFilter.search = document.getElementById('searchInput').value.trim(); renderFeed(); }

// ===== 渲染 =====
// 小红书风格瀑布流布局算法
function layoutMasonry(container) {
    const cards = container.querySelectorAll('.card-wrapper');
    if (!cards.length) return;
    const gap = 10;
    const containerWidth = container.offsetWidth;
    if (containerWidth <= 0) return;
    const colWidth = (containerWidth - gap) / 2;
    const colHeights = [0, 0];
    cards.forEach(card => {
        card.style.transform = '';
        card.style.transition = 'none';
        card.style.position = 'absolute';
        card.style.width = colWidth + 'px';
    });
    void container.offsetHeight;
    cards.forEach(card => {
        const cardHeight = card.offsetHeight;
        const col = colHeights[0] <= colHeights[1] ? 0 : 1;
        const x = col * (colWidth + gap);
        const y = colHeights[col];
        card.style.transform = `translate(${x}px, ${y}px)`;
        colHeights[col] += cardHeight + gap;
    });
    container.style.height = Math.max(colHeights[0], colHeights[1]) + 'px';
}

function renderFeed(keepScroll, scrollToTop) {
    const container = document.getElementById('feedContainer');
    const emptyState = document.getElementById('emptyState');

    // FLIP 动画：记录所有卡片旧位置
    const oldRects = {};
    if (keepScroll) {
        container.querySelectorAll('.card-wrapper').forEach(el => {
            const id = el.dataset.id;
            if (id) oldRects[id] = el.getBoundingClientRect();
        });
    }

    // 保存滚动位置，重建后恢复
    const savedScroll = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop;

    let filtered = items.filter(item => {
        if (currentFilter.tab !== 'all') {
            const tag = tags.find(t => t.id === currentFilter.tab);
            if (tag && item.type !== tag.name) return false;
        }
        if (currentFilter.search) {
            const s = currentFilter.search.toLowerCase();
            return (item.title && item.title.toLowerCase().includes(s)) || item.content.toLowerCase().includes(s);
        }
        return true;
    });

    // pinned 的灵感始终排在最前面
    filtered.sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        return 0;
    });

    // 时间排序三态
    if (timeSortMode === 2) {
        // 按时间旧→新
        const pinned = filtered.filter(i => i.pinned).sort((a, b) => (b.pinnedAt || 0) - (a.pinnedAt || 0));
        const unpinned = filtered.filter(i => !i.pinned);
        unpinned.sort((a, b) => new Date(a.updatedAt || a.createdAt) - new Date(b.updatedAt || b.createdAt));
        filtered = [...pinned, ...unpinned];
    } else {
        // 默认 / timeSortMode === 1：按编辑时间新→旧（updatedAt 优先）
        const pinned = filtered.filter(i => i.pinned).sort((a, b) => (b.pinnedAt || 0) - (a.pinnedAt || 0));
        const unpinned = filtered.filter(i => !i.pinned);
        unpinned.sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt));
        filtered = [...pinned, ...unpinned];
    }

    if (filtered.length === 0) { container.innerHTML = ''; emptyState.classList.remove('hidden'); updateItemCount(0); return; }
    emptyState.classList.add('hidden');

    if (currentLayout === 'masonry') {
        // 小红书风格瀑布流：两列绝对定位，长短卡片不在同一行
        container.className = ''; // 清除 space-y-3 等 class，避免 margin 干扰绝对定位
        container.style.cssText = 'position:relative;display:block;';
        container.innerHTML = filtered.map(item => createCardHTML(item)).join('');
        // 双重 rAF 确保卡片已完成布局计算
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                layoutMasonry(container);
                // 恢复滚动或滚到顶部
                if (scrollToTop) window.scrollTo({ top: 0, behavior: 'smooth' });
                else if (keepScroll) window.scrollTo(0, savedScroll);
                // 瀑布流：对位置变化的卡片做 opacity 闪烁（不能用 transform，会和 layoutMasonry 冲突）
                if (keepScroll && Object.keys(oldRects).length > 0) {
                    container.querySelectorAll('.card-wrapper').forEach(el => {
                        const id = el.dataset.id;
                        const oldRect = oldRects[id];
                        if (!oldRect) return;
                        const newRect = el.getBoundingClientRect();
                        const dy = Math.abs(oldRect.top - newRect.top);
                        if (dy < 5) return; // 位置几乎没变
                        el.style.transition = 'opacity 0.3s ease';
                        el.style.opacity = '0.4';
                        requestAnimationFrame(() => {
                            requestAnimationFrame(() => {
                                el.style.opacity = '';
                            });
                        });
                    });
                }
            });
        });
    } else {
        container.style.cssText = 'display:flex;flex-direction:column;gap:8px;';
        container.innerHTML = filtered.map(item => createCardHTML(item)).join('');
    }
    bindCardEvents();
    updateItemCount(filtered.length);
    startRestoredAutoClear();

    // 卡片流：恢复滚动 + FLIP 动画
    if (currentLayout !== 'masonry') {
        if (scrollToTop) window.scrollTo({ top: 0, behavior: 'smooth' });
        else if (keepScroll) window.scrollTo(0, savedScroll);
        // FLIP 动画：所有卡片从旧位置平滑过渡到新位置
        if (keepScroll && Object.keys(oldRects).length > 0) {
            container.querySelectorAll('.card-wrapper').forEach(el => {
                const id = el.dataset.id;
                const oldRect = oldRects[id];
                if (!oldRect) return;
                const newRect = el.getBoundingClientRect();
                const dx = oldRect.left - newRect.left;
                const dy = oldRect.top - newRect.top;
                if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return;
                el.style.transform = `translate(${dx}px, ${dy}px)`;
                el.style.transition = 'none';
                requestAnimationFrame(() => {
                    el.style.transition = 'transform 0.4s cubic-bezier(0.32, 0.72, 0, 1)';
                    el.style.transform = '';
                });
            });
        }
    }

    // 置顶卡片泛光高亮（与 toast 同步：300ms 淡入，2s 后 300ms 淡出）
    const highlightItems = filtered.filter(i => i._highlight).map(i => ({ id: i.id }));
    filtered.forEach(i => { if (i._highlight) delete i._highlight; });
    if (highlightItems.length) {
        setTimeout(() => {
            highlightItems.forEach(({ id }) => {
                const el = document.getElementById('card-' + id);
                if (!el) return;
                const theme = THEMES[currentTheme] || THEMES.blue;
                // 用互补色（反色）做泛光，不用 border 避免顶部横线
                const compMatch = (theme.complementary || '').match(/#[0-9A-Fa-f]{6}/);
                const comp = compMatch ? compMatch[0] : '#F97316';
                const glow = `0 0 16px ${comp}44, 0 0 6px ${comp}22`;
                el.style.boxShadow = glow;
                el.style.outline = `1px solid ${comp}55`;
                el.style.outlineOffset = '-1px';
                el.animate([
                    { boxShadow: '0 0 0px transparent', outlineColor: 'transparent' },
                    { boxShadow: glow, outlineColor: comp + '55' }
                ], { duration: 300, easing: 'ease-out', fill: 'forwards' });
                setTimeout(() => {
                    el.animate([
                        { boxShadow: glow, outlineColor: comp + '55' },
                        { boxShadow: '0 0 0px transparent', outlineColor: 'transparent' }
                    ], { duration: 300, easing: 'ease-in', fill: 'forwards' }).onfinish = () => {
                        el.style.boxShadow = '';
                        el.style.outline = '';
                        el.style.outlineOffset = '';
                    };
                }, 2000);
            });
        }, 100);
    }
}

// ===== 卡片事件绑定（长按删除）=====
let longPressTimer = null;
let currentSlidedCard = null;
let isLongPressing = false;

function bindCardEvents() {
    document.querySelectorAll('.card-wrapper').forEach(wrapper => {
        const content = wrapper.querySelector('.card-content');
        if (!content) return;
        isLongPressing = false;

        const startLP = () => {
            if (batchDeleteMode) return;
            isLongPressing = false;
            if (longPressTimer) clearTimeout(longPressTimer);
            content.classList.add('pressing');
            longPressTimer = setTimeout(() => {
                isLongPressing = true;
                content.classList.remove('pressing');
                if (currentSlidedCard && currentSlidedCard !== wrapper) closeSlidedCard(currentSlidedCard);
                content.style.transform = 'translateX(-70px)';
                currentSlidedCard = wrapper;
                if (navigator.vibrate) navigator.vibrate(50);
            }, 500);
        };
        const cancelLP = () => {
            if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
            content.classList.remove('pressing');
        };

        wrapper.addEventListener('touchstart', startLP, { passive: true });
        wrapper.addEventListener('mousedown', startLP);
        wrapper.addEventListener('touchend', cancelLP);
        wrapper.addEventListener('mouseup', cancelLP);
        wrapper.addEventListener('touchcancel', cancelLP);
        wrapper.addEventListener('mouseleave', cancelLP);

        content.addEventListener('click', (e) => {
            if (isLongPressing) { isLongPressing = false; return; }
            if (content.style.transform === 'translateX(-70px)') { closeSlidedCard(wrapper); return; }
            if (currentSlidedCard && currentSlidedCard !== wrapper) closeSlidedCard(currentSlidedCard);
            if (batchDeleteMode) {
                const id = wrapper.dataset.id;
                if (id) toggleBatchSelect(id);
                return;
            }
            if (batchPinMode) {
                const id = wrapper.dataset.id;
                if (id) togglePinFromBatch(id);
                return;
            }
            // 清除近期恢复标记
            clearRestoredBadge(wrapper.dataset.id);
            const id = wrapper.dataset.id;
            if (id) showDetailModal(id);
        });
    });

    document.addEventListener('click', (e) => {
        if (currentSlidedCard && !currentSlidedCard.contains(e.target)) closeSlidedCard(currentSlidedCard);
        // 批量删除/置顶模式下点击非卡片区域，保存置顶并退出
        if (batchDeleteMode || batchPinMode) {
            const isCard = e.target.closest('.card-wrapper');
            const isFab = e.target.closest('#fabMain');
            const isBatchBar = e.target.closest('#batchSelectAllBar');
            const isLayoutToggle = e.target.closest('#layoutToggleBtn');
            if (!isCard && !isFab && !isBatchBar && !isLayoutToggle) {
                if (batchDeleteMode) exitBatchDeleteMode();
                if (batchPinMode) exitBatchPinMode();
            }
        }
    });
}

function clearRestoredBadge(id) {
    if (!id) return;
    const item = items.find(i => i.id === id);
    if (item && item._justRestored) {
        delete item._justRestored;
        saveItems();
        // 延迟 1s 后移除 DOM 上的 badge（淡出效果）
        setTimeout(() => {
            const wrapper = document.getElementById('card-' + id);
            if (wrapper) {
                const badge = wrapper.querySelector('.restore-badge');
                if (badge) {
                    badge.style.transition = 'opacity 0.3s';
                    badge.style.opacity = '0';
                    setTimeout(() => badge.remove(), 300);
                }
            }
        }, 1000);
    }
}

// 1min 后自动清除所有近期恢复标记
let restoredAutoClearTimer = null;
function startRestoredAutoClear() {
    if (restoredAutoClearTimer) clearTimeout(restoredAutoClearTimer);
    const hasRestored = items.some(i => i._justRestored);
    if (!hasRestored) return;
    restoredAutoClearTimer = setTimeout(() => {
        let changed = false;
        items.forEach(item => {
            if (item._justRestored) {
                delete item._justRestored;
                changed = true;
            }
        });
        if (changed) {
            saveItems();
            document.querySelectorAll('.restore-badge').forEach(badge => {
                badge.style.transition = 'opacity 0.3s';
                badge.style.opacity = '0';
                setTimeout(() => badge.remove(), 300);
            });
        }
    }, 60000);
}

function closeSlidedCard(wrapper) {
    if (!wrapper) return;
    const c = wrapper.querySelector('.card-content');
    if (c) c.style.transform = '';
    if (currentSlidedCard === wrapper) currentSlidedCard = null;
}

// ===== 卡片 HTML =====
function createCardHTML(item) {
    const tag = tags.find(t => t.name === item.type);
    const tagEmoji = tag ? tag.emoji : '';
    const timeStr = formatTime(item.updatedAt || item.createdAt);
    const kw = currentFilter.search;
    const titleHtml = highlightText(item.title || '新记录', kw);
    // 富文本预览（不含图片）
    const contentHtml = renderContentPreview(item.content, kw);
    // 检测 content 中的第一张图片
    const imgMatch = item.content && item.content.match(/!\[[^\]]*\]\(([^)]+)\)/);
    const firstImageUrl = imgMatch ? imgMatch[1] : null;
    // 批量删除模式下的复选框（右上角偏下）
    const batchCheckbox = batchDeleteMode ? `
        <div class="absolute top-4 right-2 z-10" onclick="event.stopPropagation()">
            <button onclick="toggleBatchSelect('${item.id}')" class="batch-checkbox-circle w-6 h-6 rounded-full border-2 flex items-center justify-center transition btn-press ${batchSelectedIds.has(item.id) ? 'batch-checked' : 'border-gray-300 bg-white/80'}" style="${batchSelectedIds.has(item.id) ? 'background:var(--theme-primary,#3B82F6); border-color:var(--theme-primary,#3B82F6);' : ''}">
                ${batchSelectedIds.has(item.id) ? '<svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>' : ''}
            </button>
        </div>
    ` : '';

    // 滑动删除按钮：批量模式下隐藏
    const deleteBtnHtml = (batchDeleteMode || batchPinMode) ? '' : `<div style="position:absolute;right:0;top:0;bottom:0;width:70px;background:#FEE2E2;display:flex;align-items:center;justify-content:center;z-index:1;border-radius:16px;" onclick="showDeleteModal('${item.id}', event)">
        <svg class="w-6 h-6" style="color:#EF4444;" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
    </div>`;

    // pin 针：批量删除模式下不显示；批量置顶模式下所有卡片都显示可点击的 pin 针；正常模式下只显示已置顶的
    let pinnedHtml = '';
    if (batchDeleteMode) {
        // 批量删除模式下不显示 pin 针
        pinnedHtml = '';
    } else if (batchPinMode) {
        pinnedHtml = `<div class="pin-icon absolute top-3 right-2 z-10 cursor-pointer" data-id="${item.id}" onclick="event.stopPropagation(); togglePinFromBatch('${item.id}')" style="color: var(--theme-primary, #3B82F6); opacity: ${item.pinned ? '0.7' : '0.2'}; transition: opacity 0.2s;" onmouseenter="this.style.opacity='1'" onmouseleave="this.style.opacity='${item.pinned ? '0.7' : '0.2'}'">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16 12V4H17V2H7V4H8V12L6 14V16H11.2V22H12.8V16H18V14L16 12Z"/></svg>
        </div>`;
    } else if (item.pinned) {
        pinnedHtml = `<div class="pin-icon absolute top-3 right-2 z-10 cursor-pointer" data-id="${item.id}" onclick="event.stopPropagation(); togglePin('${item.id}')" style="color: var(--theme-primary, #3B82F6); opacity: 0.7; transition: opacity 0.2s, transform 0.2s;" onmouseenter="this.style.opacity='1';this.style.transform='scale(1.2)'" onmouseleave="this.style.opacity='0.7';this.style.transform='scale(1)'">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16 12V4H17V2H7V4H8V12L6 14V16H11.2V22H12.8V16H18V14L16 12Z"/></svg>
        </div>`;
    }

    // 近期恢复提示（带线框，靠右）
    const restoredBadge = item._justRestored ? `<span class="restore-badge ml-auto text-[10px] px-1.5 py-[1px] rounded-lg border pointer-events-none" style="color:var(--theme-primary,#3B82F6); border-color:var(--theme-primary,#3B82F6); opacity:0.7;">近期恢复<span class="restore-dot inline-block w-1.5 h-1.5 rounded-full ml-0.5 align-middle" style="background:var(--theme-primary,#3B82F6)"></span></span>` : '';

    // 图片卡片样式（带图预览模式下，masonry 布局中有图片时显示为图片卡片）
    if (imagePreviewMode && currentLayout === 'masonry' && firstImageUrl && !batchDeleteMode && !batchPinMode) {
        return `<div class="card-wrapper masonry-item" id="card-${item.id}" data-id="${item.id}" style="position:relative;overflow:hidden;border-radius:16px;">
            ${deleteBtnHtml}
            ${batchCheckbox}
            <div class="card-content bg-white rounded-2xl overflow-hidden card-shadow" style="position:relative;z-index:2;">
                ${pinnedHtml}
                <div class="card-image-wrap" style="position:relative;width:100%;padding-bottom:75%;overflow:hidden;background:#f5f5f5;border-radius:16px;">
                    <img src="${firstImageUrl}" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;" loading="lazy" onerror="this.style.display='none'">
                </div>
                <div class="p-3">
                    <h4 class="font-semibold text-gray-900 text-[13px] line-clamp-2">${titleHtml}</h4>
                    <div class="flex items-center gap-2 mt-1.5">
                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">${tagEmoji} ${item.type}</span>
                        <span class="text-[10px] text-gray-400">${timeStr}</span>
                        ${restoredBadge}
                    </div>
                </div>
            </div>
        </div>`;
    }

    if (currentLayout === 'masonry') {
        return `<div class="card-wrapper masonry-item" id="card-${item.id}" data-id="${item.id}" style="position:relative;overflow:hidden;border-radius:16px;">
            ${deleteBtnHtml}
            ${batchCheckbox}
            <div class="card-content bg-white rounded-2xl p-4 card-shadow" style="position:relative;z-index:2;">
                ${pinnedHtml}
                <h4 class="font-semibold text-gray-900 text-[14px] mb-1 line-clamp-2">${titleHtml}</h4>
                <p class="text-[12px] text-gray-500 line-clamp-5">${contentHtml}</p>
                <div class="flex items-center gap-2 mt-2">
                    <span class="text-[11px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">${tagEmoji} ${item.type}</span>
                    <span class="text-[11px] text-gray-400">${timeStr}</span>
                    ${restoredBadge}
                </div>
            </div>
        </div>`;
    }

    return `<div class="card-wrapper" id="card-${item.id}" data-id="${item.id}" style="position:relative;overflow:hidden;border-radius:16px;">
        ${deleteBtnHtml}
        ${batchCheckbox}
        <div class="card-content bg-white rounded-2xl p-4 card-shadow" style="position:relative;z-index:2;">
            ${pinnedHtml}
            <h4 class="font-semibold text-gray-900 text-[15px] mb-0.5">${titleHtml}</h4>
            <p class="text-[13px] text-gray-500 mb-2.5 line-clamp-2">${contentHtml}</p>
            <div class="flex items-center gap-2">
                <span class="text-[11px] px-2.5 py-1 rounded-full bg-gray-100 text-gray-600">${tagEmoji} ${item.type}</span>
                <span class="text-[11px] text-gray-400">${timeStr}</span>
                ${restoredBadge}
            </div>
        </div>
    </div>`;
}

function formatTime(iso) {
    const d = new Date(iso);
    return `${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}
function escapeHtml(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
function highlightText(text, keyword) {
    const escaped = escapeHtml(text);
    if (!keyword) return escaped;
    const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return escaped.replace(regex, '<mark class="search-highlight">$1</mark>');
}

// 首页卡片富文本预览（精简版：只保留加粗、换行、列表前标）
function renderContentPreview(content, keyword) {
    if (!content) return '';
    let text = content;
    // 去掉图片标记 ![alt](url)，替换为 [图片]
    text = text.replace(/!\[[^\]]*\]\([^)]+\)/g, '[图片]');
    // 去掉链接标记 [text](url)，只保留 text
    text = text.replace(/\[([^\]]*)\]\([^)]+\)/g, '$1');
    // 去掉标题标记（### 等），不限定行首（预览截断后可能不在行首）
    text = text.replace(/#{1,5}\s+/g, ' ');
    // 去掉引用标记
    text = text.replace(/^>\s/gm, '');
    // 去掉任务列表标记
    text = text.replace(/^- \[[ x]\]\s/gm, '');
    // 去掉行内代码标记
    text = text.replace(/`([^`]*)`/g, '$1');
    // 去掉加粗/斜体标记
    text = text.replace(/\*\*(.*?)\*\*/g, '$1');
    text = text.replace(/\*(.*?)\*/g, '$1');
    // 去掉分割线
    text = text.replace(/^---+$/gm, '');
    // 处理无序列表前标（包括缩进的）
    text = text.replace(/^(\s*)-\s+/gm, function(m, indent) {
        const level = indent.replace(/\t/g, '   ').length;
        const symbols = ['•', '○', '■'];
        const sym = symbols[Math.min(Math.floor(level / 3), 2)];
        // 缩进的子项前添加换行，保持层级感
        return level > 0 ? '\n' + sym + ' ' : sym + ' ';
    });
    // 处理有序列表前标（数字. 字母. 罗马数字.）
    text = text.replace(/^(\s*)(\d+)\.\s+/gm, function(m, indent, num) {
        return indent ? '\n' + num + '. ' : num + '. ';
    });
    text = text.replace(/^(\s*)([a-zA-Z])\.\s+/gm, function(m, indent, letter) {
        return indent ? '\n' + letter + '. ' : letter + '. ';
    });
    text = text.replace(/^(\s*)([ivxIVX]+)\.\s+/gm, function(m, indent, roman) {
        return indent ? '\n' + roman + '. ' : roman + '. ';
    });
    // 合并连续空行为单行（避免预览中出现大片空白）
    text = text.replace(/\n{2,}/g, '\n');
    // 去掉首尾空白
    text = text.trim();
    // 转义 HTML
    text = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    // 换行（连续空行合并为一个换行）
    text = text.replace(/\n{2,}/g, '\n');
    text = text.replace(/\n/g, '<br>');
    // 搜索高亮
    if (keyword) {
        const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        text = text.replace(regex, '<mark class="search-highlight">$1</mark>');
    }
    return text;
}

// ===== Emoji 选择器（内置图标库 + 最近使用历史）=====
let emojiPage = 0;
const EMOJI_PAGE_SIZE = 80;

function openEmojiPicker(target) {
    emojiPickerTarget = target;
    emojiPage = 0;
    const modal = document.getElementById('emojiPickerModal');
    renderEmojiGrid();
    modal.classList.remove('hidden');
}

function renderEmojiGrid() {
    const grid = document.getElementById('emojiGrid');

    // 确定当前选中的 emoji
    let currentSelected = '💡';
    if (emojiPickerTarget === 'input') currentSelected = currentEmoji;
    else if (emojiPickerTarget === 'detail') currentSelected = detailEmoji;
    else if (emojiPickerTarget === 'newTag') currentSelected = newTagEmoji;
    else if (emojiPickerTarget === 'inlineTag') currentSelected = inlineTagEmoji;
    else if (emojiPickerTarget === 'editTag') currentSelected = editTagEmoji;
    else if (emojiPickerTarget === 'fullscreen') currentSelected = detailEmoji;

    const sel = (emoji) => emoji === currentSelected ? 'bg-brand-light ring-2 ring-brand-dark/30' : '';
    const btn = (emoji) => `<button class="emoji-grid-item w-[44px] h-[44px] flex items-center justify-center rounded-lg text-[24px] hover:bg-gray-100 active:bg-gray-200 transition ${sel(emoji)}" onclick="selectEmojiFromGrid('${emoji}')">${emoji}</button>`;

    let html = '';

    // 最近使用区域（始终显示）
    if (emojiRecent.length > 0) {
        html += '<p class="text-[12px] text-gray-400 font-medium mb-1.5">最近使用</p>';
        html += '<div class="flex flex-wrap gap-[4px] mb-2">';
        emojiRecent.forEach(e => { html += btn(e); });
        html += '</div><div class="border-t border-gray-100 my-2"></div>';
    }

    // 分页加载完整库
    const start = 0;
    const end = (emojiPage + 1) * EMOJI_PAGE_SIZE;
    const visibleEmojis = EMOJI_LIBRARY.slice(start, end);
    const hasMore = end < EMOJI_LIBRARY.length;

    html += '<div class="flex flex-wrap gap-[4px]">';
    visibleEmojis.forEach(e => { html += btn(e); });
    html += '</div>';

    if (hasMore) {
        const remaining = EMOJI_LIBRARY.length - end;
        html += `<button onclick="loadMoreEmoji()" class="w-full py-2.5 text-[13px] text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-xl transition mt-2 btn-press">加载更多（剩余 ${remaining} 个）</button>`;
    }

    grid.innerHTML = html;
}

function loadMoreEmoji() {
    emojiPage++;
    renderEmojiGrid();
}

function selectEmojiFromGrid(emoji) {
    // 更新选中状态
    document.querySelectorAll('.emoji-grid-item').forEach(btn => {
        btn.classList.remove('bg-brand-light', 'ring-2', 'ring-brand-dark/30');
        if (btn.textContent === emoji) {
            btn.classList.add('bg-brand-light', 'ring-2', 'ring-brand-dark/30');
        }
    });

    // 添加到最近使用（去重，最多保留 24 个）
    emojiRecent = emojiRecent.filter(e => e !== emoji);
    emojiRecent.unshift(emoji);
    if (emojiRecent.length > 24) emojiRecent = emojiRecent.slice(0, 24);
    saveEmojiRecent();

    if (emojiPickerTarget === 'input') {
        currentEmoji = emoji;
        document.getElementById('inputEmojiBtn').textContent = currentEmoji;
    } else if (emojiPickerTarget === 'detail') {
        detailEmoji = emoji;
        document.getElementById('detailEmojiBtn').textContent = detailEmoji;
    } else if (emojiPickerTarget === 'newTag') {
        newTagEmoji = emoji;
        document.getElementById('newTagEmojiBtn').textContent = newTagEmoji;
    } else if (emojiPickerTarget === 'inlineTag') {
        inlineTagEmoji = emoji;
        document.getElementById('inlineTagEmojiBtn').textContent = inlineTagEmoji;
    } else if (emojiPickerTarget === 'editTag') {
        editTagEmoji = emoji;
        document.getElementById('editTagEmojiBtn').textContent = editTagEmoji;
    } else if (emojiPickerTarget === 'fullscreen') {
        detailEmoji = emoji;
        document.getElementById('fullscreenEmojiBtn').textContent = detailEmoji;
    }
}

function closeEmojiPicker() { document.getElementById('emojiPickerModal').classList.add('hidden'); }
function confirmEmoji() {
    closeEmojiPicker();
}

// ===== Tag 管理 =====
function toggleTagManage() {
    const menu = document.getElementById('tagGearMenuModal');
    const icon = document.getElementById('tagGearIcon');
    if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
        icon.classList.add('spin');
        renderTagManageList();
        updateTimeSortBtn();
    } else {
        closeTagGearMenu();
    }
}
function closeTagGearMenu() {
    document.getElementById('tagGearMenuModal').classList.add('hidden');
    document.getElementById('tagGearIcon').classList.remove('spin');
    document.getElementById('addTagArea').classList.add('hidden');
    document.getElementById('editTagArea').classList.add('hidden');
    showFabCheckmark();
}
function closeTagManage() {
    document.getElementById('tagManageModal').classList.add('hidden');
    document.getElementById('tagGearIcon').classList.remove('spin');
    document.getElementById('addTagArea').classList.add('hidden');
    document.getElementById('editTagArea').classList.add('hidden');
    showFabCheckmark();
    editTagId = null;
}

function renderTagManageList() {
    const list = document.getElementById('tagManageList');
    list.innerHTML = tags.filter(t => t.id !== 'all' && !t.system).map((tag, index) => `
        <div class="tag-manage-item flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-gray-50" draggable="true" data-index="${index}" data-id="${tag.id}">
            <div class="flex items-center gap-3 flex-1">
                <svg class="w-4 h-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 8h16M4 16h16"/></svg>
                <span class="text-[20px]">${tag.emoji || ''}</span>
                <span class="text-[14px] font-medium text-gray-900">${escapeHtml(tag.name)}</span>
            </div>
            ${tag.editable ? `
                <div class="flex items-center gap-1 ml-2">
                    <button onclick="startEditTag('${tag.id}')" class="w-8 h-8 rounded-lg hover:bg-blue-50 flex items-center justify-center text-gray-400 hover:text-blue-500 transition btn-press" title="编辑">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    </button>
                    ${tag.deletable ? `
                        <button onclick="deleteTag('${tag.id}')" class="w-8 h-8 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-400 hover:text-red-500 transition btn-press" title="删除">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        </button>
                    ` : ''}
                </div>
            ` : ''}
        </div>
    `).join('');

    bindTagDragEvents();
}

function bindTagDragEvents() {
    const tagItems = document.querySelectorAll('.tag-manage-item');
    let draggedItem = null;

    tagItems.forEach(item => {
        item.addEventListener('dragstart', (e) => {
            draggedItem = item;
            item.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
        });
        item.addEventListener('dragend', () => {
            item.classList.remove('dragging');
            // 读取 DOM 顺序，同步更新 tags 数组（排除 'all'）
            const list = document.getElementById('tagManageList');
            const newOrder = Array.from(list.querySelectorAll('.tag-manage-item')).map(el => el.dataset.id);
            const allTag = tags.find(t => t.id === 'all');
            const otherTags = newOrder.map(id => tags.find(t => t.id === id)).filter(Boolean);
            tags = [allTag, ...otherTags];
            saveTags();
            renderTabBar();
            draggedItem = null;
        });
        item.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (!draggedItem || draggedItem === item) return;
            const rect = item.getBoundingClientRect();
            const midY = rect.top + rect.height / 2;
            if (e.clientY < midY) item.parentNode.insertBefore(draggedItem, item);
            else item.parentNode.insertBefore(draggedItem, item.nextSibling);
        });
    });
}

function renameTag(tagId, newName) {
    const tag = tags.find(t => t.id === tagId);
    if (!tag || !tag.editable) return;
    const oldName = tag.name;
    tag.name = newName.trim() || oldName;
    saveTags();
    items.forEach(item => { if (item.type === oldName) item.type = tag.name; });
    saveItems();
    renderTabBar();
    renderFeed();
    showToast('分类名称已更新');
}

let pendingDeleteTagId = null;

function deleteTag(tagId) {
    const tag = tags.find(t => t.id === tagId);
    if (!tag || !tag.deletable) { showToast('该分类不可删除'); return; }
    pendingDeleteTagId = tagId;
    const count = items.filter(i => i.type === tag.name).length;
    document.getElementById('deleteTagDesc').innerHTML = count > 0
        ? `注意：该分类下的 <b>${count}</b> 条灵感将变为「未分类」`
        : '确定删除此分类？';
    document.getElementById('deleteTagModal').classList.remove('hidden');
    // 垃圾桶特效（只动 SVG 图标，不动圆底，循环直到弹窗关闭）
    const iconSvg = document.getElementById('deleteTagIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-20deg) scale(0.3)', offset: 0.2 },
            { transform: 'rotate(15deg) scale(0.6)', offset: 0.45 },
            { transform: 'rotate(-8deg) scale(1.15)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1500, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}
function closeDeleteTagModal() {
    const iconSvg = document.getElementById('deleteTagIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('deleteTagModal').classList.add('hidden'); pendingDeleteTagId = null;
}
function confirmDeleteTag() {
    if (!pendingDeleteTagId) return;
    const tag = tags.find(t => t.id === pendingDeleteTagId);
    tags = tags.filter(t => t.id !== pendingDeleteTagId);
    // 确保"未分类"tag存在（按名字匹配，不匹配emoji）
    if (!tags.find(t => t.name === '未分类')) {
        tags.push({ id: 'tag_uncategorized_' + Date.now(), name: '未分类', emoji: '📋', editable: false, deletable: false, system: true });
    }
    saveTags();
    if (tag) items.forEach(item => { if (item.type === tag.name) item.type = '未分类'; });
    saveItems();
    closeDeleteTagModal();
    renderTagManageList();
    renderTabBar();
    renderFeed();
    showFabCheckmark();
    showToast('分类已删除');
}

// ===== 编辑分类（铅笔按钮）=====
function startEditTag(tagId) {
    const tag = tags.find(t => t.id === tagId);
    if (!tag || !tag.editable) return;
    editTagId = tagId;
    editTagEmoji = tag.emoji || '🏷️';
    document.getElementById('editTagEmojiBtn').textContent = editTagEmoji;
    document.getElementById('editTagName').value = tag.name;
    document.getElementById('editTagArea').classList.remove('hidden');
    document.getElementById('addTagArea').classList.add('hidden');
    setTimeout(() => document.getElementById('editTagName').focus(), 100);
}

function confirmEditTag() {
    if (!editTagId) return;
    const tag = tags.find(t => t.id === editTagId);
    if (!tag) return;
    const newName = document.getElementById('editTagName').value.trim();
    if (!newName) { showToast('请输入分类名称'); return; }
    const oldName = tag.name;
    tag.name = newName;
    tag.emoji = editTagEmoji;
    saveTags();
    // 同步更新已有灵感的分类名
    items.forEach(item => { if (item.type === oldName) item.type = newName; });
    saveItems();
    document.getElementById('editTagArea').classList.add('hidden');
    editTagId = null;
    renderTagManageList();
    renderTabBar();
    renderFeed();
    showToast('分类已更新');
}

function cancelEditTag() {
    document.getElementById('editTagArea').classList.add('hidden');
    editTagId = null;
}

function showAddTagInput() {
    const area = document.getElementById('addTagArea');
    area.classList.toggle('hidden');
    if (!area.classList.contains('hidden')) {
        newTagEmoji = '🏷️';
        document.getElementById('newTagEmojiBtn').textContent = newTagEmoji;
        document.getElementById('newTagName').value = '';
        document.getElementById('newTagName').focus();
    }
}

function addNewTag() {
    const name = document.getElementById('newTagName').value.trim();
    if (!name) { showToast('请输入分类名称'); return; }
    if (tags.find(t => t.name === name)) { showToast('该分类已存在'); return; }
    const newTag = {
        id: 'tag_' + Date.now(),
        name: name,
        emoji: newTagEmoji,
        editable: true,
        deletable: true
    };
    tags.push(newTag);
    saveTags();
    document.getElementById('newTagName').value = '';
    document.getElementById('addTagArea').classList.add('hidden');
    renderTagManageList();
    renderTabBar();
    showToast('分类已添加');
}

// ===== 时间排序（三态切换）=====
function toggleTimeSort() {
    timeSortMode = (timeSortMode + 1) % 3;
    localStorage.setItem('gator_time_sort', timeSortMode);
    // SVG 切换过渡特效
    const svg = document.getElementById('timeSortSvg');
    if (svg) {
        svg.style.transition = 'transform 0.25s ease, opacity 0.15s ease';
        svg.style.transform = 'scale(0.7) rotate(-90deg)';
        svg.style.opacity = '0';
        setTimeout(() => {
            updateTimeSortBtn();
            svg.style.transform = 'scale(0.7) rotate(90deg)';
            requestAnimationFrame(() => {
                svg.style.transform = 'scale(1) rotate(0deg)';
                svg.style.opacity = '1';
            });
        }, 150);
    } else {
        updateTimeSortBtn();
    }
    renderFeed();
    // 震动动画
    const btn = document.getElementById('timeSortIconBtn');
    if (btn) {
        btn.classList.remove('sort-bounce');
        void btn.offsetWidth;
        btn.classList.add('sort-bounce');
    }
    if (timeSortMode === 1) showToast('按时间排序：新 → 旧');
    else if (timeSortMode === 2) showToast('按时间排序：旧 → 新');
    else showToast('已取消时间排序');
}

function updateTimeSortBtn() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    const svg = document.getElementById('timeSortSvg');
    const btn = document.getElementById('timeSortIconBtn');
    if (!svg || !btn) return;

    if (timeSortMode === 1) {
        // 新→旧：箭头朝下
        svg.style.color = theme.primaryDark;
        btn.style.background = theme.primaryLight;
        svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12"/>';
    } else if (timeSortMode === 2) {
        // 旧→新：箭头朝上（翻转箭头部分）
        svg.style.color = theme.primaryDark;
        btn.style.background = theme.primaryLight;
        svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M3 4h13M3 8h9m-9 4h18m-4 4l4 4m0 0l4-4m-4 4V0"/>';
    } else {
        // 默认：纯排序线，无箭头
        svg.style.color = '#9CA3AF';
        btn.style.background = '';
        svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M3 4h13M3 8h9m-9 4h6"/>';
    }
}

// ===== AI 功能（开发中）=====
function openAIFeature() {
    showToast('🤖 AI 功能正在开发中，敬请期待');
}

// ===== 添加（分类联动当前 tag）=====
function openInputModal() {
    document.getElementById('inputModal').classList.remove('hidden');
    // 根据当前选中的 tag 设置默认分类
    if (currentFilter.tab !== 'all') {
        const tag = tags.find(t => t.id === currentFilter.tab);
        if (tag) selectedType = tag.name;
    } else {
        selectedType = '效率';
    }
    updateTypeButtons();
    currentEmoji = '💡';
    document.getElementById('inputEmojiBtn').textContent = currentEmoji;
    document.getElementById('titleInput').value = '';
    document.getElementById('contentInput').value = '';
    renderInputTypeList();
    // 隐藏内联新增区域
    document.getElementById('inlineAddTagArea').classList.add('hidden');
    setTimeout(() => document.getElementById('titleInput').focus(), 100);
}
function closeInputModal() {
    document.getElementById('inputModal').classList.add('hidden');
    document.getElementById('titleInput').value = '';
    document.getElementById('contentInput').value = '';
    document.getElementById('inlineAddTagArea').classList.add('hidden');
    selectedType = '效率'; updateTypeButtons();
}

function renderInputTypeList() {
    const container = document.getElementById('inputTypeList');
    if (!container) return;
    const theme = THEMES[currentTheme] || THEMES.blue;

    // 渲染分类标签
    let html = tags.filter(t => t.id !== 'all').map(tag => {
        const isSelected = tag.name === selectedType;
        return `<button onclick="selectType('${tag.name}')" class="type-tag px-4 py-2 rounded-full text-[13px] whitespace-nowrap border border-transparent"
            data-type="${tag.name}"
            style="background: ${isSelected ? theme.primary : theme.primaryFaint}; color: ${isSelected ? '#fff' : theme.primaryDark}">
            ${tag.emoji || ''} ${tag.name}
        </button>`;
    }).join('');

    // 在末尾添加固定的 "+" 按钮（flex-shrink-0）
    html += `<button onclick="showInlineAddTagArea()" class="type-tag px-4 py-2 rounded-full text-[13px] whitespace-nowrap border border-dashed border-gray-300 text-gray-400 hover:text-gray-600 hover:border-gray-400 transition flex-shrink-0" style="background: transparent; color: #9ca3af;">+</button>`;

    container.innerHTML = html;
}

// 显示内联新增分类区域
function showInlineAddTagArea() {
    document.getElementById('inlineAddTagArea').classList.remove('hidden');
    inlineTagEmoji = '🏷️';
    document.getElementById('inlineTagEmojiBtn').textContent = inlineTagEmoji;
    document.getElementById('inlineTagName').value = '';
    setTimeout(() => document.getElementById('inlineTagName').focus(), 100);
}

// 确认内联新增分类
function confirmInlineAddTag() {
    const name = document.getElementById('inlineTagName').value.trim();
    if (!name) { showToast('请输入分类名称'); return; }
    if (tags.find(t => t.name === name)) { showToast('该分类已存在'); return; }
    const newTag = {
        id: 'tag_' + Date.now(),
        name: name,
        emoji: inlineTagEmoji,
        editable: true,
        deletable: true
    };
    tags.push(newTag);
    saveTags();
    // 隐藏输入区
    document.getElementById('inlineAddTagArea').classList.add('hidden');
    // 选中新分类
    selectedType = name;
    // 刷新列表
    renderInputTypeList();
    updateTypeButtons();
    showToast('分类已添加');
}

function selectType(type) { selectedType = type; updateTypeButtons(); }
function updateTypeButtons() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    document.querySelectorAll('.type-tag').forEach(btn => {
        if (btn.dataset.type === selectedType) { btn.style.background = theme.primary; btn.style.color = '#fff'; }
        else if (btn.dataset.type) { btn.style.background = theme.primaryFaint; btn.style.color = theme.primaryDark; }
    });
}
function addItem() {
    const title = document.getElementById('titleInput').value.trim();
    const content = document.getElementById('contentInput').value.trim();
    if (!title && !content) { showToast('请输入内容'); return; }
    const fullTitle = currentEmoji + ' ' + (title || '新记录');
    items.unshift({ id: 'item_' + Date.now(), title: fullTitle, content: content || '', type: selectedType || '效率', createdAt: new Date().toISOString() });
    saveItems(); renderFeed(); showFabCheckmark(); closeInputModal();
    showToast('已添加到 ' + getCurrentNotebookName());
}

// ===== 删除确认（灵感） =====
function showDeleteModal(id, e) {
    if (e) e.stopPropagation();
    if (currentSlidedCard) closeSlidedCard(currentSlidedCard);
    deleteTargetId = id;
    const item = items.find(i => i.id === id);
    const nameEl = document.getElementById('deleteItemName');
    if (item && item.title) { nameEl.textContent = item.title; nameEl.classList.remove('hidden'); }
    else nameEl.classList.add('hidden');
    document.getElementById('deleteModalTitle').textContent = '删除此灵感？';
    document.getElementById('deleteModalDesc').textContent = '删除后可在回收站恢复';
    document.getElementById('deleteModal').classList.remove('hidden');
    // 垃圾桶特效（只动 SVG 图标，不动圆底，循环直到弹窗关闭）
    const iconSvg = document.getElementById('deleteIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-20deg) scale(0.3)', offset: 0.2 },
            { transform: 'rotate(15deg) scale(0.6)', offset: 0.45 },
            { transform: 'rotate(-8deg) scale(1.15)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1500, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}
function closeDeleteModal() {
    const iconSvg = document.getElementById('deleteIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('deleteModal').classList.add('hidden'); deleteTargetId = null;
}
function confirmDelete() {
    if (!deleteTargetId) { closeDeleteModal(); return; }
    const item = items.find(i => i.id === deleteTargetId);
    if (item) moveToRecycleBin(item);
    items = items.filter(i => i.id !== deleteTargetId);
    saveItems(); renderFeed(); showFabCheckmark(); showToast('已删除'); closeDeleteModal(); checkUncategorizedEmpty();
}

// ===== 灵感详情/编辑 =====
function showDetailModal(id) {
    detailTargetId = id;
    const item = items.find(i => i.id === id);
    if (!item) return;
    const match = item.title.match(/^(\S+)\s+(.*)$/);
    if (match) { detailEmoji = match[1]; document.getElementById('detailTitle').value = match[2] || ''; }
    else { detailEmoji = '💡'; document.getElementById('detailTitle').value = item.title || ''; }
    document.getElementById('detailEmojiBtn').textContent = detailEmoji;
    document.getElementById('detailContent').value = item.content || '';
    // 渲染 HTML 预览（与全屏编辑器一致）
    const previewEl = document.getElementById('detailContentPreview');
    if (previewEl) {
        previewEl.innerHTML = markdownToHtml(item.content || '');
        // 底部留白
        initBottomSpacer('detailContentPreview', null);
        // 恢复滚动位置（1分钟内打开过则恢复，否则置顶）
        const cache = scrollPositionCache[id];
        const now = Date.now();
        if (cache && cache.previewScroll !== undefined && (now - cache.timestamp) < 60000) {
            setTimeout(() => { previewEl.scrollTop = cache.previewScroll; }, 50);
        } else {
            previewEl.scrollTop = 0;
        }
    }
    // 保存原始值用于对比
    detailOriginalEmoji = detailEmoji;
    detailOriginalTitle = document.getElementById('detailTitle').value.trim();
    detailOriginalContent = item.content || '';
    // 未分类卡片：强制要求用户选择分类
    const isUncategorized = item.type === '未分类';
    detailSelectedType = isUncategorized ? '' : (item.type || '效率');
    renderDetailTypeList();
    updateDetailTypeButtons();
    updatePinBtnState(item.pinned);
    // 未分类提示
    const typeHint = document.getElementById('detailTypeHint');
    if (typeHint) {
        if (isUncategorized) {
            typeHint.textContent = '请为此灵感选择一个分类';
            typeHint.classList.remove('hidden');
        } else {
            typeHint.classList.add('hidden');
        }
    }
    document.getElementById('detailModal').classList.remove('hidden');
}
function closeDetailModal() {
    // 关闭前保存滚动位置
    const closedId = detailTargetId;
    const previewEl = document.getElementById('detailContentPreview');
    if (closedId && previewEl) {
        if (!scrollPositionCache[closedId]) scrollPositionCache[closedId] = {};
        scrollPositionCache[closedId].previewScroll = previewEl.scrollTop;
        scrollPositionCache[closedId].timestamp = Date.now();
    }
    // 关闭前自动保存（如果内容有变化）
    const hadChanges = hasUnsavedChangesDetail();
    autoSaveDetail();
    // 如果有变化，标记高亮并重新渲染
    if (hadChanges && closedId) {
        const item = items.find(i => i.id === closedId);
        if (item) item._highlight = true;
    }
    document.getElementById('detailModal').classList.add('hidden');
    detailTargetId = null;
    showFabCheckmark();
    // 重置展开菜单
    const menu = document.getElementById('detailActionMenu');
    const icon = document.getElementById('detailFabIcon');
    if (menu) { menu.classList.add('opacity-0', 'pointer-events-none'); menu.style.transform = 'translateY(10px)'; }
    if (icon) { icon.style.transform = 'rotate(0deg)'; }
    // 重新渲染以显示高亮
    renderFeed();
}

// 详情弹窗的未保存检测
function hasUnsavedChangesDetail() {
    if (!detailTargetId) return false;
    const item = items.find(i => i.id === detailTargetId);
    if (!item) return false;
    const title = (document.getElementById('detailTitle').value || '').trim();
    const content = (document.getElementById('detailContent').value || '').trim().replace(/\r\n/g, '\n');
    const origTitle = (detailOriginalTitle || '').trim();
    const origContent = (detailOriginalContent || '').trim().replace(/\r\n/g, '\n');
    return (detailEmoji !== detailOriginalEmoji) ||
           (title !== origTitle) ||
           (content !== origContent) ||
           (item.type !== detailSelectedType);
}

// 详情页底部大加号展开/收起菜单
function toggleDetailActionMenu() {
    const menu = document.getElementById('detailActionMenu');
    const icon = document.getElementById('detailFabIcon');
    if (!menu || !icon) return;
    const isOpen = !menu.classList.contains('opacity-0');
    if (isOpen) {
        menu.classList.add('opacity-0', 'pointer-events-none');
        menu.style.transform = 'translateY(10px)';
        icon.style.transform = 'rotate(0deg)';
    } else {
        menu.classList.remove('opacity-0', 'pointer-events-none');
        menu.style.transform = 'translateY(0)';
        icon.style.transform = 'rotate(45deg)';
    }
}

// 自动保存：仅当标题或正文有变化时才保存并更新时间戳
function autoSaveDetail() {
    if (!detailTargetId) return;
    const item = items.find(i => i.id === detailTargetId);
    if (!item) return;
    const title = document.getElementById('detailTitle').value.trim();
    const content = document.getElementById('detailContent').value.trim();
    if (!title && !content) return;
    const newTitle = detailEmoji + ' ' + (title || '新记录');
    const newContent = content || '';
    // 只有当 emoji、标题或正文发生变化时才更新时间
    const textChanged = (detailEmoji !== detailOriginalEmoji) ||
                        (title !== detailOriginalTitle) ||
                        (newContent !== detailOriginalContent);
    item.title = newTitle;
    item.content = newContent;
    item.type = detailSelectedType;
    if (textChanged) {
        item.updatedAt = new Date().toISOString();
    }
    saveItems();
}

// ===== 全屏编辑 =====
// ===== 底部留白：滚到内容底部时增加空白空间（参考备忘录 app） =====
function initBottomSpacer(wrapId, contentId) {
    const wrap = document.getElementById(wrapId);
    const content = document.getElementById(contentId);
    if (!wrap) return;
    const target = content || wrap; // 如果 contentId 为空，则 wrap 自身既是滚动容器也是内容容器

    // 移除旧的监听器和 spacer
    if (wrap._bottomSpacerHandler) {
        wrap.removeEventListener('scroll', wrap._bottomSpacerHandler);
    }
    const oldSpacer = target.querySelector('[data-bottom-spacer]');
    if (oldSpacer) oldSpacer.remove();

    // 获取最后一行文字的高度
    function getLastLineHeight() {
        const allChildren = target.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, div, span, blockquote');
        let lastTextEl = null;
        for (let i = allChildren.length - 1; i >= 0; i--) {
            const el = allChildren[i];
            if (el.dataset && (el.dataset.bottomSpacer || el.dataset.scrollSpacer)) continue;
            if (el.closest('[data-bottom-spacer]') || el.closest('[data-scroll-spacer]')) continue;
            if (el.textContent.trim()) {
                lastTextEl = el;
                break;
            }
        }
        if (!lastTextEl) return 40;
        const style = window.getComputedStyle(lastTextEl);
        const fontSize = parseFloat(style.fontSize) || 16;
        const lineHeight = parseFloat(style.lineHeight) || fontSize * 1.6;
        return lineHeight;
    }

    wrap._bottomSpacerHandler = function() {
        const spacer = target.querySelector('[data-bottom-spacer]');
        const threshold = 30;

        if (wrap.scrollTop + wrap.clientHeight >= wrap.scrollHeight - threshold) {
            const lastLineH = getLastLineHeight();
            const maxH = wrap.clientHeight * 0.4;
            const spacerH = Math.min(lastLineH, maxH);

            if (!spacer) {
                const newSpacer = document.createElement('div');
                newSpacer.dataset.bottomSpacer = 'true';
                newSpacer.style.height = spacerH + 'px';
                newSpacer.style.pointerEvents = 'none';
                newSpacer.setAttribute('contenteditable', 'false');
                target.appendChild(newSpacer);
            } else {
                spacer.style.height = spacerH + 'px';
            }
        } else {
            if (spacer) spacer.remove();
        }
    };

    wrap.addEventListener('scroll', wrap._bottomSpacerHandler);
}

function openFullscreenEditor() {
    if (!detailTargetId) return;
    const modal = document.getElementById('fullscreenEditorModal');
    document.getElementById('fullscreenEmojiBtn').textContent = detailEmoji;
    document.getElementById('fullscreenTitle').value = document.getElementById('detailTitle').value;
    const content = document.getElementById('detailContent').value || '';
    document.getElementById('fullscreenEditor').innerHTML = markdownToHtml(content);
    modal.classList.remove('hidden');
    // 恢复滚动位置（1分钟内打开过则恢复，否则置顶）
    const wrap = document.getElementById('fullscreenEditorWrap');
    const cache = scrollPositionCache[detailTargetId];
    const now = Date.now();
    if (wrap && cache && cache.editorScroll !== undefined && (now - cache.timestamp) < 60000) {
        setTimeout(() => { wrap.scrollTop = cache.editorScroll; }, 50);
    } else if (wrap) {
        wrap.scrollTop = 0;
    }
    // 清除工具栏高亮（默认无选中状态）
    setTimeout(() => {
        const sel = window.getSelection();
        sel.removeAllRanges();
        updateToolbarHighlight();
    }, 50);
    // 底部留白：滚到内容底部时增加空白空间
    initBottomSpacer('fullscreenEditorWrap', 'fullscreenEditor');
}

// ===== 未保存检测 =====
function hasUnsavedChanges() {
    const originalTitle = (document.getElementById('detailTitle').value || '').trim();
    const originalContent = (document.getElementById('detailContent').value || '').trim().replace(/\r\n/g, '\n');
    const currentTitle = (document.getElementById('fullscreenTitle').value || '').trim();
    const currentContent = (htmlToMarkdown(document.getElementById('fullscreenEditor').innerHTML) || '').trim().replace(/\r\n/g, '\n');
    return currentTitle !== originalTitle || currentContent !== originalContent;
}

function showUnsavedModal() {
    document.getElementById('unsavedModal').classList.remove('hidden');
    // 编辑笔特效（循环旋转+缩放，参考删除确认框的垃圾桶动画）
    const iconSvg = document.getElementById('unsavedIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-15deg) scale(0.85)', offset: 0.25 },
            { transform: 'rotate(10deg) scale(1.1)', offset: 0.5 },
            { transform: 'rotate(-5deg) scale(0.95)', offset: 0.75 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1200, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}

function closeUnsavedModal() {
    const iconSvg = document.getElementById('unsavedIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('unsavedModal').classList.add('hidden');
}

function discardFullscreenEditor() {
    closeUnsavedModal();
    // 不保存：直接关闭弹窗，不回写内容到详情
    const modal = document.getElementById('fullscreenEditorModal');
    modal.classList.add('hidden');
}

function saveAndCloseFullscreenEditor() {
    closeUnsavedModal();
    saveFullscreenEditor();
}

function _doCloseFullscreenEditor() {
    // 保存编辑界面的滚动位置
    const wrap = document.getElementById('fullscreenEditorWrap');
    if (detailTargetId && wrap) {
        if (!scrollPositionCache[detailTargetId]) scrollPositionCache[detailTargetId] = {};
        scrollPositionCache[detailTargetId].editorScroll = wrap.scrollTop;
        scrollPositionCache[detailTargetId].timestamp = Date.now();
    }
    const modal = document.getElementById('fullscreenEditorModal');
    modal.classList.add('hidden');
    document.getElementById('detailEmojiBtn').textContent = detailEmoji;
    document.getElementById('detailTitle').value = document.getElementById('fullscreenTitle').value;
    const mdContent = htmlToMarkdown(document.getElementById('fullscreenEditor').innerHTML);
    document.getElementById('detailContent').value = mdContent;
    // 同步更新详情预览
    const previewEl = document.getElementById('detailContentPreview');
    if (previewEl) {
        previewEl.innerHTML = markdownToHtml(mdContent);
        // 底部留白
        initBottomSpacer('detailContentPreview', null);
    }
}

function closeFullscreenEditor() {
    if (hasUnsavedChanges()) {
        showUnsavedModal();
    } else {
        _doCloseFullscreenEditor();
    }
}

function saveFullscreenEditor() {
    const title = document.getElementById('fullscreenTitle').value.trim();
    const content = htmlToMarkdown(document.getElementById('fullscreenEditor').innerHTML);
    if (!title && !content) { showToast('请输入内容'); return; }

    if (detailTargetId) {
        document.getElementById('detailTitle').value = document.getElementById('fullscreenTitle').value;
        document.getElementById('detailContent').value = content;
        // 直接更新 item 并标记高亮
        const item = items.find(i => i.id === detailTargetId);
        if (item) {
            item.title = detailEmoji + ' ' + (title || '新记录');
            item.content = content || '';
            item.type = detailSelectedType;
            item.updatedAt = new Date().toISOString();
            item._highlight = true;
            saveItems();
        }
        closeFullscreenEditor();
        closeDetailModal();
        showToast('已保存');
        checkUncategorizedEmpty();
        renderFeed();
    } else {
        const newItem = {
            id: 'item_' + Date.now(),
            title: detailEmoji + ' ' + (title || '新记录'),
            content: content || '',
            type: detailSelectedType,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            pinned: false
        };
        items.unshift(newItem);
        saveItems(); renderFeed(); renderTabBar(); showFabCheckmark(); showToast('已添加');
        closeFullscreenEditor();
    }
}

function openFullscreenEditorFromInput() {
    closeInputModal();
    detailTargetId = null;
    detailEmoji = currentEmoji || '💡';
    detailSelectedType = currentFilter.tab !== 'all' ? tags.find(t => t.id === currentFilter.tab)?.name || '效率' : '效率';
    const modal = document.getElementById('fullscreenEditorModal');
    document.getElementById('fullscreenEmojiBtn').textContent = detailEmoji;
    document.getElementById('fullscreenTitle').value = '';
    document.getElementById('fullscreenEditor').innerHTML = '';
    modal.classList.remove('hidden');
}

// ===== Markdown 工具栏 =====
// ===== 所见即所得编辑器命令 =====
function wysiwygCmd(type) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    // 保存当前选区（editor.focus() 可能导致光标跳转）
    const sel = window.getSelection();
    let savedRange = null;
    if (sel.rangeCount > 0) {
        savedRange = sel.getRangeAt(0).cloneRange();
    }
    editor.focus();
    // 恢复选区
    if (savedRange) {
        sel.removeAllRanges();
        sel.addRange(savedRange);
    }
    // 检查选区是否在编辑器内，如果不在则不执行（防止误操作）
    if (!sel.rangeCount) return;
    let checkNode = sel.anchorNode;
    if (checkNode && checkNode.nodeType === 3) checkNode = checkNode.parentNode;
    if (checkNode && !editor.contains(checkNode)) return;

    if (type === 'bold') {
        document.execCommand('bold', false, null);
    } else if (type === 'italic') {
        document.execCommand('italic', false, null);
    } else if (type === 'undo') {
        document.execCommand('undo', false, null);
    } else if (type === 'h1' || type === 'h2' || type === 'h3' || type === 'h4' || type === 'h5') {
        const level = type.charAt(1);
        const currentBlock = document.queryCommandValue('formatBlock').replace(/[<>]/g, '').toLowerCase();
        // 找到光标所在的实际块级元素（用于 DOM 操作替换）
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        const blockEl = node ? node.closest('h1,h2,h3,h4,h5,h6,blockquote,p') : null;
        // 如果当前已经是同级别标题，恢复为正文（用 DOM 替换，不能用 formatBlock）
        if (currentBlock === 'h' + level) {
            if (blockEl) {
                const p = document.createElement('p');
                while (blockEl.firstChild) p.appendChild(blockEl.firstChild);
                blockEl.parentNode.replaceChild(p, blockEl);
                const newRange = document.createRange();
                newRange.selectNodeContents(p);
                newRange.collapse(false);
                sel.removeAllRanges();
                sel.addRange(newRange);
            }
            // 取消加粗和斜体（只在已激活时才取消）
            if (document.queryCommandState('bold')) document.execCommand('bold', false, null);
            if (document.queryCommandState('italic')) document.execCommand('italic', false, null);
        } else {
            // 防止标题嵌套：如果当前在标题或引用内，先通过 DOM 操作将外层元素转为 p
            if (currentBlock.startsWith('h') || currentBlock === 'blockquote') {
                if (blockEl) {
                    const p = document.createElement('p');
                    while (blockEl.firstChild) p.appendChild(blockEl.firstChild);
                    blockEl.parentNode.replaceChild(p, blockEl);
                    const newRange = document.createRange();
                    newRange.selectNodeContents(p);
                    newRange.collapse(false);
                    sel.removeAllRanges();
                    sel.addRange(newRange);
                }
            }
            document.execCommand('formatBlock', false, 'h' + level);
            if (!sel.toString()) {
                const h = editor.querySelector('h' + level);
                if (h && h.textContent === '') h.textContent = '标题';
            }
        }
    } else if (type === 'insertUnorderedList') {
        document.execCommand('insertUnorderedList', false, null);
    } else if (type === 'insertOrderedList') {
        document.execCommand('insertOrderedList', false, null);
    } else if (type === 'task') {
        // 检测光标/选区是否在待办中，如果是则取消待办
        const range = sel.getRangeAt(0);
        let node = range.startContainer;
        if (node && node.nodeType === 3) node = node.parentNode;
        // 检测是否在 li 中的待办（需要检查多种情况）
        let inTaskLi = node ? node.closest('li') : null;
        if (!inTaskLi) {
            // 检查 commonAncestorContainer
            let common = range.commonAncestorContainer;
            if (common.nodeType === 3) common = common.parentNode;
            inTaskLi = common ? common.closest('li') : null;
        }
        if (!inTaskLi && (node && (node.tagName === 'OL' || node.tagName === 'UL'))) {
            // 选中了整个 li，检查子元素
            const selectedLi = range.startContainer.childNodes[range.startOffset];
            if (selectedLi && selectedLi.tagName === 'LI' && selectedLi.querySelector('input[type="checkbox"]')) {
                inTaskLi = selectedLi;
            }
        }
        if (inTaskLi && inTaskLi.querySelector('input[type="checkbox"]')) {
            // 取消 li 中的待办：恢复为普通列表项
            const span = inTaskLi.querySelector('span');
            const text = span ? span.textContent : '';
            // 收集嵌套列表
            let nestedHtml = '';
            for (const child of inTaskLi.childNodes) {
                if (child.nodeType === 1 && (child.tagName === 'OL' || child.tagName === 'UL')) {
                    nestedHtml += child.outerHTML;
                }
            }
            // 直接修改 li（不用 insertHTML，避免嵌套 ol 导致结构错乱）
            inTaskLi.removeAttribute('style');
            inTaskLi.innerHTML = (text || '<br>') + nestedHtml;
            // 光标移到 li 中
            const newRange = document.createRange();
            newRange.setStart(inTaskLi.firstChild || inTaskLi, 0);
            newRange.collapse(true);
            sel.removeAllRanges();
            sel.addRange(newRange);
            setTimeout(updateToolbarHighlight, 10);
            return;
        }
        // 检测是否在 div 中的待办
        const inTaskDiv = node ? node.closest('div[data-task]') : null;
        if (inTaskDiv && inTaskDiv.querySelector('input[type="checkbox"]')) {
            // 取消 div 中的待办：转换为普通段落
            const span = inTaskDiv.querySelector('span');
            const text = span ? span.textContent : '';
            const p = document.createElement('p');
            p.textContent = text || '\u200B';
            inTaskDiv.parentNode.insertBefore(p, inTaskDiv);
            inTaskDiv.remove();
            const newRange = document.createRange();
            newRange.setStart(p.firstChild || p, 0);
            newRange.collapse(true);
            sel.removeAllRanges();
            sel.addRange(newRange);
            setTimeout(updateToolbarHighlight, 10);
            return;
        }
        // 如果有选中文本，把选中文本变为待办；否则把当前行变为待办
        let text = sel.toString();
        // 检测光标/选区是否在有序/无序列表的某个 li 中
        let inLi = null;
        if (sel.rangeCount > 0) {
            const r = sel.getRangeAt(0);
            let startNode = r.startContainer;
            if (startNode.nodeType === 3) startNode = startNode.parentNode;
            inLi = startNode.closest ? startNode.closest('li') : null;
            // 如果 startNode 不在 li 中，检查 commonAncestorContainer
            if (!inLi) {
                let common = r.commonAncestorContainer;
                if (common.nodeType === 3) common = common.parentNode;
                inLi = common.closest ? common.closest('li') : null;
            }
            // 如果选中了整个 li（startNode 是 ol/ul），检查 startNode 的子元素
            if (!inLi && (startNode.tagName === 'OL' || startNode.tagName === 'UL')) {
                // 检查选中的是否是单个 li
                const selectedLi = r.startContainer.childNodes[r.startOffset];
                if (selectedLi && selectedLi.tagName === 'LI' && selectedLi === r.endContainer.childNodes[r.endOffset - 1]) {
                    inLi = selectedLi;
                }
            }
        }
        if (inLi) {
            // 只转换当前 li 的文本部分为待办（保留嵌套列表）
            const listEl = inLi.closest('ol, ul');
            if (listEl) {
                // 提取 li 的直接文本（不包括嵌套 ol/ul）
                let liText = '';
                let nestedHtml = '';
                for (const child of inLi.childNodes) {
                    if (child.nodeType === 3) {
                        liText += child.textContent;
                    } else if (child.nodeType === 1 && child.tagName !== 'OL' && child.tagName !== 'UL') {
                        liText += child.textContent;
                    } else if (child.nodeType === 1 && (child.tagName === 'OL' || child.tagName === 'UL')) {
                        nestedHtml += child.outerHTML;
                    }
                }
                liText = liText.trim() || '待办事项';
                const escapedText = liText.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                // 使用 execCommand insertHTML 替换整个 li（支持 undo）
                const taskHtml = `<li style="list-style-type:none;margin-left:-20px"><div data-task="true" style="display:flex;align-items:center;gap:4px" contenteditable="false"><input type="checkbox" onclick="handleTaskCheck(this)" style="margin:0;flex-shrink:0"><span style="flex:1;min-width:0" contenteditable="true">${escapedText}</span></div>${nestedHtml}</li>`;
                // 记录 inLi 在父元素中的位置，用于 insertHTML 后定位新 li
                const liParent = inLi.parentNode;
                const liIndex = Array.from(liParent.childNodes).indexOf(inLi);
                const sel2 = window.getSelection();
                const range2 = document.createRange();
                range2.selectNode(inLi);
                sel2.removeAllRanges();
                sel2.addRange(range2);
                document.execCommand('insertHTML', false, taskHtml);
                // 光标移到刚创建的待办 span 中
                setTimeout(() => {
                    const newLi = liParent.childNodes[liIndex];
                    const taskSpan = newLi ? newLi.querySelector('span') : null;
                    if (taskSpan && taskSpan.firstChild) {
                        const newRange = document.createRange();
                        newRange.selectNodeContents(taskSpan);
                        const s = window.getSelection();
                        s.removeAllRanges();
                        s.addRange(newRange);
                    }
                    updateToolbarHighlight();
                }, 10);
                return;
            }
        }
        if (!text) {
            let node2 = range.startContainer;
            if (node2.nodeType === 3) node2 = node2.parentNode;
            let block = node2.closest('p, div, h1, h2, h3, h4, h5, h6, blockquote') || node2;
            text = block.textContent || '';
            const blockRange = document.createRange();
            blockRange.selectNodeContents(block);
            sel.removeAllRanges();
            sel.addRange(blockRange);
            text = blockRange.toString() || '待办事项';
        }
        // 非列表中的待办：使用 div
        const html = `<div data-task="true" style="display:flex;align-items:center;gap:4px;margin:4px 0;margin-left:4px" contenteditable="false"><input type="checkbox" onclick="handleTaskCheck(this)" style="margin:0;flex-shrink:0"><span style="flex:1;min-width:0" contenteditable="true">${text}</span></div>`;
        if (sel.toString() || sel.rangeCount) {
            const temp = document.createElement('div');
            temp.innerHTML = html;
            const taskEl = temp.firstChild;
            const range3 = sel.getRangeAt(0);
            range3.deleteContents();
            range3.insertNode(taskEl);
            const taskSpan = taskEl.querySelector('span');
            if (taskSpan) {
                const newRange = document.createRange();
                newRange.selectNodeContents(taskSpan);
                sel.removeAllRanges();
                sel.addRange(newRange);
            }
        } else {
            document.execCommand('insertHTML', false, html);
        }
    } else if (type === 'quote') {
        // 检测是否已在 blockquote 中，如果是则取消
        const range = sel.getRangeAt(0);
        let node = range.startContainer;
        if (node && node.nodeType === 3) node = node.parentNode;
        const inBlockquote = node ? node.closest('blockquote') : null;
        if (inBlockquote) {
            // 取消引用：将 blockquote 的子元素移到 blockquote 的位置
            const parent = inBlockquote.parentNode;
            const children = Array.from(inBlockquote.childNodes);
            children.forEach(child => parent.insertBefore(child, inBlockquote));
            inBlockquote.remove();
            // 恢复光标
            if (node && editor.contains(node)) {
                const newRange = document.createRange();
                newRange.setStart(node, 0);
                newRange.collapse(true);
                sel.removeAllRanges();
                sel.addRange(newRange);
            }
        } else {
            // 创建引用：找到光标所在的块级容器（ol/ul/p/h1 等），用 blockquote 包裹
            const block = node ? node.closest('ol, ul, p, h1, h2, h3, h4, h5, h6, div, li') : null;
            if (block) {
                // 如果在列表中，包裹其父 ol/ul
                const listContainer = block.closest('ol, ul');
                if (listContainer) {
                    // 保存光标位置信息
                    const anchorOffset = sel.anchorOffset;
                    let anchorNode = sel.anchorNode;
                    if (anchorNode.nodeType === 3) anchorNode = anchorNode.parentNode;
                    const bq = document.createElement('blockquote');
                    listContainer.parentNode.insertBefore(bq, listContainer);
                    bq.appendChild(listContainer);
                    // 恢复光标
                    if (editor.contains(anchorNode)) {
                        const newRange = document.createRange();
                        try {
                            newRange.setStart(anchorNode, Math.min(anchorOffset, anchorNode.childNodes.length || anchorNode.textContent.length || 0));
                        } catch(e) {
                            newRange.selectNodeContents(anchorNode);
                            newRange.collapse(true);
                        }
                        newRange.collapse(true);
                        sel.removeAllRanges();
                        sel.addRange(newRange);
                    }
                } else {
                    // 非 li：用 formatBlock
                    document.execCommand('formatBlock', false, 'blockquote');
                }
            } else {
                document.execCommand('formatBlock', false, 'blockquote');
            }
        }
    } else if (type === 'indent') {
        // 检测是否在待办中，如果是则只缩进当前任务项
        const range = sel.getRangeAt(0);
        let node = range.startContainer;
        if (node && node.nodeType === 3) node = node.parentNode;
        const taskLi = node ? node.closest('li') : null;
        if (taskLi && taskLi.querySelector('input[type="checkbox"]')) {
            const currentMargin = parseInt(taskLi.style.marginLeft) || -20;
            taskLi.style.marginLeft = Math.min(currentMargin + 20, 0) + 'px';
        } else {
            const taskDiv = node ? node.closest('div[data-task]') : null;
            if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                const currentMargin = parseInt(taskDiv.style.marginLeft) || 4;
                taskDiv.style.marginLeft = (currentMargin + 20) + 'px';
            } else {
                document.execCommand('indent', false, null);
                setTimeout(() => {
                    const sel = window.getSelection();
                    if (sel.rangeCount > 0) {
                        let node = sel.anchorNode;
                        if (node && node.nodeType === 3) node = node.parentNode;
                        const li = node ? node.closest('li') : null;
                        if (li) applyNestStyleOnIndent(li);
                    }
                }, 50);
            }
        }
    } else if (type === 'outdent') {
        // 检测是否在待办中
        const range2 = sel.getRangeAt(0);
        let node2 = range2.startContainer;
        if (node2 && node2.nodeType === 3) node2 = node2.parentNode;
        const taskLi2 = node2 ? node2.closest('li') : null;
        if (taskLi2 && taskLi2.querySelector('input[type="checkbox"]')) {
            const currentMargin = parseInt(taskLi2.style.marginLeft) || -20;
            taskLi2.style.marginLeft = Math.max(currentMargin - 20, -20) + 'px';
        } else {
            const taskDiv2 = node2 ? node2.closest('div[data-task]') : null;
            if (taskDiv2 && taskDiv2.querySelector('input[type="checkbox"]')) {
                const currentMargin = parseInt(taskDiv2.style.marginLeft) || 4;
                taskDiv2.style.marginLeft = Math.max(currentMargin - 20, 4) + 'px';
            } else {
                document.execCommand('outdent', false, null);
            }
        }
    } else if (type === 'image') {
        document.getElementById('imageUpload').click();
    }
    // 更新工具栏高亮
    setTimeout(updateToolbarHighlight, 10);
}

// ===== 列表弹出菜单 =====
// 有序列表类型配置
const OL_TYPES = [
    { id: 'decimal', label: '数字 (1, 2, 3)', icon: '1.', css: 'decimal', sample: '1.' },
    { id: 'decimal-leading-zero', label: '前导零 (01, 02, 03)', icon: '01', css: 'decimal-leading-zero', sample: '01.' },
    { id: 'lower-alpha', label: '小写字母 (a, b, c)', icon: 'a.', css: 'lower-alpha', sample: 'a.' },
    { id: 'upper-alpha', label: '大写字母 (A, B, C)', icon: 'A.', css: 'upper-alpha', sample: 'A.' },
    { id: 'lower-roman', label: '小写罗马 (i, ii, iii)', icon: 'i.', css: 'lower-roman', sample: 'i.' },
    { id: 'upper-roman', label: '大写罗马 (I, II, III)', icon: 'I.', css: 'upper-roman', sample: 'I.' },
    { id: 'cjk-ideographic', label: '中文 (一, 二, 三)', icon: '一', css: 'cjk-ideographic', sample: '一.' },
    { id: 'lower-greek', label: '希腊字母 (α, β, γ)', icon: 'α.', css: 'lower-greek', sample: 'α.' },
];

// 有序列表缩进模式
const OL_NEST_MODES = [
    { id: 'flat', label: '统一编号', desc: '所有层级使用相同编号', levels: ['decimal','decimal','decimal'] },
    { id: 'hierarchical', label: '层级递进', desc: '1 → a → i', levels: ['decimal','lower-alpha','lower-roman'] },
    { id: 'decimal-dot', label: '多级编号', desc: '1 → 1.1 → 1.1.1', levels: ['decimal','decimal','decimal'], dotNotation: true },
];

// 无序列表缩进层级样式
const UL_NEST_LEVELS = ['disc', 'circle', 'square'];

let listPopupState = { type: null, currentOlType: 'decimal', currentStart: 1, currentUlType: 'disc', olNestMode: 'flat' };

function openListPopup(type, btnEl) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    editor.focus();

    listPopupState.type = type;
    const popup = document.getElementById('listPopup');
    const overlay = document.getElementById('listPopupOverlay');
    const orderedPanel = document.getElementById('listPopupOrdered');
    const unorderedPanel = document.getElementById('listPopupUnordered');

    // 检测当前光标是否在列表中
    const sel = window.getSelection();
    let inOl = false, inUl = false, currentStart = 1, currentOlCss = 'decimal', currentUlCss = 'disc';
    listPopupState._targetOl = null;
    listPopupState._targetUl = null;
    if (sel.rangeCount > 0) {
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        const li = node ? node.closest('li') : null;
        if (li) {
            const ol = li.closest('ol');
            const ul = li.closest('ul');
            if (ol) {
                inOl = true;
                listPopupState._targetOl = ol;
                currentOlCss = ol.style.listStyleType || 'decimal';
                currentStart = parseInt(ol.getAttribute('start')) || 1;
            }
            if (ul) {
                inUl = true;
                listPopupState._targetUl = ul;
                currentUlCss = ul.style.listStyleType || 'disc';
            }
        }
    }

    if (type === 'ol') {
        orderedPanel.classList.remove('hidden');
        unorderedPanel.classList.add('hidden');
        // 构建有序列表类型子菜单
        buildOlTypeSubmenu(currentOlCss);
        // 更新编号控制状态
        updateOlControls(currentStart);
        // 构建缩进模式选项
        buildOlNestModeOptions();
    } else {
        orderedPanel.classList.add('hidden');
        unorderedPanel.classList.remove('hidden');
        // 高亮当前无序列表样式
        updateUlControls(currentUlCss);
    }

    // 定位弹窗
    const rect = btnEl.getBoundingClientRect();
    popup.style.bottom = (window.innerHeight - rect.top + 6) + 'px';
    popup.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - 200)) + 'px';

    overlay.classList.remove('hidden');
    requestAnimationFrame(() => popup.classList.add('show'));
}

function closeListPopup() {
    const popup = document.getElementById('listPopup');
    const overlay = document.getElementById('listPopupOverlay');
    const picker = document.getElementById('listNumberPicker');
    popup.classList.remove('show');
    overlay.classList.add('hidden');
    picker.classList.add('hidden');
}

function buildOlTypeSubmenu(activeType) {
    const submenu = document.getElementById('listTypeSubmenu');
    const labelEl = document.getElementById('listTypeLabel');
    const iconEl = document.querySelector('#listTypeItem .item-icon');
    const active = OL_TYPES.find(t => t.css === activeType) || OL_TYPES[0];
    listPopupState.currentOlType = activeType;
    labelEl.textContent = active.label;
    iconEl.textContent = active.sample;

    submenu.innerHTML = OL_TYPES.map(t => {
        const cls = t.css === activeType ? ' active' : '';
        return `<div class="list-popup-item${cls}" onclick="selectOlType('${t.css}', '${t.label}', '${t.sample}')">
            <span class="item-icon">${t.sample}</span>
            <span class="item-label">${t.label}</span>
        </div>`;
    }).join('');
}

function selectOlType(css, label, sample) {
    listPopupState.currentOlType = css;
    document.getElementById('listTypeLabel').textContent = label;
    document.querySelector('#listTypeItem .item-icon').textContent = sample;
    // 更新子菜单高亮
    document.querySelectorAll('#listTypeSubmenu .list-popup-item').forEach(el => el.classList.remove('active'));
    event.currentTarget.classList.add('active');
    // 隐藏子菜单
    document.getElementById('listTypeSubmenu').classList.remove('show');
    // 应用到编辑器（使用保存的引用）
    if (listPopupState._targetOl) {
        listPopupState._targetOl.style.listStyleType = css;
    }
}

// 构建有序列表缩进模式选项
function buildOlNestModeOptions() {
    const container = document.getElementById('olNestModeOptions');
    if (!container) return;
    container.innerHTML = OL_NEST_MODES.map(m => {
        const cls = m.id === listPopupState.olNestMode ? ' active' : '';
        return `<div class="list-popup-item${cls}" onclick="selectOlNestMode('${m.id}')" style="padding:8px 14px">
            <span class="item-icon" style="font-size:13px">${m.desc}</span>
            <span class="item-label" style="font-size:13px">${m.label}</span>
        </div>`;
    }).join('');
}

function selectOlNestMode(modeId) {
    listPopupState.olNestMode = modeId;
    document.querySelectorAll('#olNestModeOptions .list-popup-item').forEach(el => el.classList.remove('active'));
    event.currentTarget.classList.add('active');
    // 应用到编辑器中所有嵌套列表
    applyOlNestModeToEditor(modeId);
}

// 将缩进模式应用到编辑器中所有嵌套 OL
function applyOlNestModeToEditor(modeId) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    const mode = OL_NEST_MODES.find(m => m.id === modeId);
    if (!mode) return;
    // 遍历所有 ol，根据嵌套深度设置样式
    editor.querySelectorAll('ol').forEach(ol => {
        const depth = getListDepth(ol, 'ol');
        const levelStyle = mode.levels[Math.min(depth, mode.levels.length - 1)];
        ol.style.listStyleType = levelStyle;
        if (mode.dotNotation && depth > 0) {
            ol.setAttribute('data-dot-notation', 'true');
        } else {
            ol.removeAttribute('data-dot-notation');
        }
    });
}

// 获取列表元素的嵌套深度
function getListDepth(el, tag) {
    let depth = 0;
    let parent = el.parentElement;
    while (parent) {
        if (parent.tagName === tag.toUpperCase()) depth++;
        parent = parent.parentElement;
    }
    return depth;
}

// Tab 缩进时自动切换列表样式
function applyNestStyleOnIndent(li) {
    if (!li) return;
    const parentList = li.parentElement;
    if (!parentList) return;
    const depth = getListDepth(parentList, parentList.tagName.toLowerCase());
    if (parentList.tagName === 'OL') {
        const mode = OL_NEST_MODES.find(m => m.id === listPopupState.olNestMode) || OL_NEST_MODES[0];
        const levelStyle = mode.levels[Math.min(depth, mode.levels.length - 1)];
        parentList.style.listStyleType = levelStyle;
        if (mode.dotNotation && depth > 0) {
            parentList.setAttribute('data-dot-notation', 'true');
        }
    } else if (parentList.tagName === 'UL') {
        // 无序列表自动按层级切换
        const levelStyle = UL_NEST_LEVELS[Math.min(depth, UL_NEST_LEVELS.length - 1)];
        parentList.style.listStyleType = levelStyle;
    }
    // 递归处理子列表
    li.querySelectorAll('ol, ul').forEach(childList => {
        const childDepth = getListDepth(childList, childList.tagName.toLowerCase());
        if (childList.tagName === 'OL') {
            const mode = OL_NEST_MODES.find(m => m.id === listPopupState.olNestMode) || OL_NEST_MODES[0];
            const cs = mode.levels[Math.min(childDepth, mode.levels.length - 1)];
            childList.style.listStyleType = cs;
        } else {
            const cs = UL_NEST_LEVELS[Math.min(childDepth, UL_NEST_LEVELS.length - 1)];
            childList.style.listStyleType = cs;
        }
    });
}

// ===== 折叠/展开功能 =====
const FOLD_TOGGLE_HTML = '<span class="fold-toggle" contenteditable="false" onclick="event.stopPropagation(); toggleFold(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></span>';

function toggleFoldAtCursor() {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    let node = sel.anchorNode;
    if (node && node.nodeType === 3) node = node.parentNode;
    // 查找最近的标题或列表项
    const heading = node ? node.closest('h1,h2,h3,h4,h5') : null;
    const li = node ? node.closest('li') : null;
    if (heading) {
        toggleFoldForHeading(heading);
    } else if (li) {
        toggleFoldForLi(li);
    }
}

function toggleFoldForHeading(h) {
    const toggle = h.querySelector('.fold-toggle');
    if (toggle) {
        // 已有折叠按钮，切换状态
        toggle.classList.toggle('collapsed');
        // 折叠/展开标题后的所有兄弟元素直到下一个同级或更高级标题
        let sibling = h.nextElementSibling;
        const hLevel = parseInt(h.tagName[1]);
        while (sibling) {
            if (sibling.tagName.match(/^H[1-5]$/)) {
                const sibLevel = parseInt(sibling.tagName[1]);
                if (sibLevel <= hLevel) break;
            }
            sibling.classList.toggle('foldable-collapsed', toggle.classList.contains('collapsed'));
            sibling = sibling.nextElementSibling;
        }
    } else {
        // 添加折叠按钮
        h.insertAdjacentHTML('afterbegin', FOLD_TOGGLE_HTML);
    }
}

function toggleFoldForLi(li) {
    const toggle = li.querySelector('.fold-toggle');
    if (toggle) {
        toggle.classList.toggle('collapsed');
        // 折叠/展开 li 内的子列表
        const subLists = li.querySelectorAll(':scope > ul, :scope > ol');
        subLists.forEach(sl => sl.classList.toggle('foldable-collapsed', toggle.classList.contains('collapsed')));
    } else {
        // 添加折叠按钮，需要把 li 内容包裹
        const childLists = li.querySelectorAll(':scope > ul, :scope > ol');
        if (childLists.length === 0) return; // 没有子列表不需要折叠
        li.classList.add('foldable-parent');
        // 包裹内容
        const wrap = document.createElement('span');
        wrap.className = 'fold-content-wrap';
        while (li.firstChild) {
            wrap.appendChild(li.firstChild);
        }
        li.appendChild(wrap);
        li.insertAdjacentHTML('afterbegin', FOLD_TOGGLE_HTML);
    }
}

function toggleFold(toggleEl) {
    toggleEl.classList.toggle('collapsed');
    const heading = toggleEl.closest('h1,h2,h3,h4,h5');
    if (heading) {
        const hLevel = parseInt(heading.tagName[1]);
        let sibling = heading.nextElementSibling;
        while (sibling) {
            if (sibling.tagName.match(/^H[1-5]$/)) {
                const sibLevel = parseInt(sibling.tagName[1]);
                if (sibLevel <= hLevel) break;
            }
            sibling.classList.toggle('foldable-collapsed', toggleEl.classList.contains('collapsed'));
            sibling = sibling.nextElementSibling;
        }
    } else {
        const li = toggleEl.closest('li');
        if (li) {
            const subLists = li.querySelectorAll(':scope > ul, :scope > ol');
            subLists.forEach(sl => sl.classList.toggle('foldable-collapsed', toggleEl.classList.contains('collapsed')));
        }
    }
}

function toggleOlSubmenu(e) {
    e.stopPropagation();
    const submenu = document.getElementById('listTypeSubmenu');
    const popup = document.getElementById('listPopup');
    const isShowing = submenu.classList.contains('show');
    if (!isShowing) {
        // 检查是否超出右边界，如果是则改为左侧展开
        const popupRect = popup.getBoundingClientRect();
        if (popupRect.right + 170 > window.innerWidth) {
            submenu.style.left = 'auto';
            submenu.style.right = '100%';
            submenu.style.top = '-4px';
        } else {
            submenu.style.left = '100%';
            submenu.style.right = 'auto';
        }
    }
    submenu.classList.toggle('show');
}

function updateOlControls(currentStart) {
    listPopupState.currentStart = currentStart;
    const continueItem = document.getElementById('listContinueItem');
    const newStartItem = document.getElementById('listNewStartItem');
    // 序号为1时，继续和新编号灰色
    if (currentStart <= 1) {
        continueItem.classList.add('disabled');
        newStartItem.classList.add('disabled');
    } else {
        continueItem.classList.remove('disabled');
        newStartItem.classList.remove('disabled');
    }
}

function updateUlControls(activeType) {
    listPopupState.currentUlType = activeType;
    document.querySelectorAll('#listPopupUnordered .list-popup-item').forEach(el => {
        el.classList.toggle('active', el.dataset.ul === activeType);
    });
}

function listAction(action, param) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    editor.focus();
    const sel = window.getSelection();

    if (action === 'ul') {
        // 无序列表：应用样式
        const style = param || 'disc';
        listPopupState.currentUlType = style;
        // 如果当前在待办项中，先转为正文再创建列表（互斥）
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        // 也通过编辑器查找光标附近的待办（因为 contenteditable=false 内 sel.anchorNode 可能为 null）
        let taskDiv = node ? node.closest('div[data-task]') : null;
        if (!taskDiv) {
            const allTasks = editor.querySelectorAll('div[data-task]');
            for (const t of allTasks) {
                if (t.querySelector('input[type="checkbox"]') && editor.contains(t)) {
                    taskDiv = t;
                }
            }
        }
        if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
            const span = taskDiv.querySelector('span');
            const text = span ? span.textContent : taskDiv.textContent;
            // 直接用 DOM 创建 <ul><li> 替代待办（execCommand 在移除 contenteditable=false 后不工作）
            const ul = document.createElement('ul');
            ul.style.listStyleType = style;
            const li = document.createElement('li');
            li.textContent = text || '';
            ul.appendChild(li);
            taskDiv.parentNode.insertBefore(ul, taskDiv);
            taskDiv.remove();
            // 光标移到 li 文本末尾
            editor.focus();
            const newRange = document.createRange();
            const textNode = li.firstChild || li;
            newRange.setStart(textNode, textNode.textContent ? textNode.textContent.length : 0);
            newRange.collapse(true);
            sel.removeAllRanges();
            sel.addRange(newRange);
            listPopupState._targetUl = ul;
            closeListPopup();
            setTimeout(updateToolbarHighlight, 30);
            return;
        }
        // 如果不在列表中，先创建
        const inList = node ? node.closest('li') : null;
        if (!inList) {
            document.execCommand('insertUnorderedList', false, null);
        } else {
            const ol = node.closest('ol');
            if (ol) {
                document.execCommand('insertUnorderedList', false, null);
            }
        }
        // 应用样式
        setTimeout(() => {
            const editor = document.getElementById('fullscreenEditor');
            const ul = editor.querySelector('ul');
            if (ul) {
                if (style === 'diamond') {
                    ul.style.listStyleType = 'diamond';
                } else {
                    ul.style.listStyleType = style;
                }
                listPopupState._targetUl = ul;
            }
        }, 20);
        closeListPopup();
    } else if (action === 'continue') {
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        // 如果当前在待办项中，先转为正文（互斥）
        let taskDiv = node ? node.closest('div[data-task]') : null;
        if (!taskDiv) {
            const allTasks = editor.querySelectorAll('div[data-task]');
            for (const t of allTasks) {
                if (t.querySelector('input[type="checkbox"]') && editor.contains(t)) {
                    taskDiv = t;
                }
            }
        }
        if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
            const span = taskDiv.querySelector('span');
            const text = span ? span.textContent : taskDiv.textContent;
            // 直接用 DOM 创建 <ol><li> 替代待办
            const ol = document.createElement('ol');
            ol.style.listStyleType = listPopupState.currentOlType;
            const li = document.createElement('li');
            li.textContent = text || '';
            ol.appendChild(li);
            taskDiv.parentNode.insertBefore(ol, taskDiv);
            taskDiv.remove();
            editor.focus();
            const newRange = document.createRange();
            const textNode = li.firstChild || li;
            newRange.setStart(textNode, textNode.textContent ? textNode.textContent.length : 0);
            newRange.collapse(true);
            sel.removeAllRanges();
            sel.addRange(newRange);
            listPopupState._targetOl = ol;
            closeListPopup();
            setTimeout(updateToolbarHighlight, 30);
            return;
        }
        const inOl = node ? node.closest('ol') : null;
        if (!inOl) {
            document.execCommand('insertOrderedList', false, null);
        }
        setTimeout(() => {
            const editor = document.getElementById('fullscreenEditor');
            const ol = editor.querySelector('ol');
            if (ol) {
                ol.style.listStyleType = listPopupState.currentOlType;
                listPopupState._targetOl = ol;
            }
        }, 20);
        closeListPopup();
    } else if (action === 'newstart') {
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        // 如果当前在待办项中，先转为正文（互斥）
        let taskDiv2 = node ? node.closest('div[data-task]') : null;
        if (!taskDiv2) {
            const allTasks2 = editor.querySelectorAll('div[data-task]');
            for (const t of allTasks2) {
                if (t.querySelector('input[type="checkbox"]') && editor.contains(t)) {
                    taskDiv2 = t;
                }
            }
        }
        if (taskDiv2 && taskDiv2.querySelector('input[type="checkbox"]')) {
            const span = taskDiv2.querySelector('span');
            const text = span ? span.textContent : taskDiv2.textContent;
            // 直接用 DOM 创建 <ol><li> 替代待办
            const ol = document.createElement('ol');
            ol.style.listStyleType = listPopupState.currentOlType;
            ol.setAttribute('start', '1');
            const li = document.createElement('li');
            li.textContent = text || '';
            ol.appendChild(li);
            taskDiv2.parentNode.insertBefore(ol, taskDiv2);
            taskDiv2.remove();
            editor.focus();
            const newRange = document.createRange();
            const textNode = li.firstChild || li;
            newRange.setStart(textNode, textNode.textContent ? textNode.textContent.length : 0);
            newRange.collapse(true);
            sel.removeAllRanges();
            sel.addRange(newRange);
            listPopupState._targetOl = ol;
            listPopupState.currentStart = 1;
            closeListPopup();
            setTimeout(updateToolbarHighlight, 30);
            return;
        }
        const inOl = node ? node.closest('ol') : null;
        if (!inOl) {
            document.execCommand('insertOrderedList', false, null);
        }
        setTimeout(() => {
            const editor = document.getElementById('fullscreenEditor');
            const ol = editor.querySelector('ol');
            if (ol) {
                ol.setAttribute('start', '1');
                ol.style.listStyleType = listPopupState.currentOlType;
                listPopupState.currentStart = 1;
                listPopupState._targetOl = ol;
            }
        }, 20);
        closeListPopup();
    } else if (action === 'changenumber') {
        // 显示编号值选择器
        const picker = document.getElementById('listNumberPicker');
        const changeItem = document.getElementById('listChangeNumItem');
        if (picker.classList.contains('hidden')) {
            picker.classList.remove('hidden');
            changeItem.classList.add('hidden');
            // 生成1-20的数字按钮
            picker.innerHTML = '';
            for (let i = 1; i <= 20; i++) {
                const btn = document.createElement('div');
                btn.className = 'list-number-btn' + (i === listPopupState.currentStart ? ' active' : '');
                btn.textContent = i;
                btn.onclick = function(e) {
                    e.stopPropagation();
                    applyListStart(i);
                };
                picker.appendChild(btn);
            }
        } else {
            picker.classList.add('hidden');
            changeItem.classList.remove('hidden');
        }
    }
    setTimeout(updateToolbarHighlight, 30);
}

function applyListType(cssType) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    const sel = window.getSelection();
    let node = sel.anchorNode;
    if (node && node.nodeType === 3) node = node.parentNode;
    const ol = node ? node.closest('ol') : null;
    if (ol) {
        ol.style.listStyleType = cssType;
    }
}

function applyListStart(num) {
    if (listPopupState._targetOl) {
        listPopupState._targetOl.setAttribute('start', String(num));
        listPopupState.currentStart = num;
    }
    closeListPopup();
    setTimeout(updateToolbarHighlight, 30);
}

// 处理图片上传（本地文件，自动压缩）
function handleImageUpload(input) {
    const file = input.files[0];
    if (!file) return;
    input.value = '';

    const SIZE_LIMIT = 10 * 1024 * 1024; // 10MB
    if (file.size > SIZE_LIMIT) {
        // 超过10MB，用Canvas压缩
        compressImage(file, 0.8, 2400, function(dataUrl, originalSrc) {
            insertImageToEditor(dataUrl, originalSrc);
        });
    } else {
        // 小于10MB，直接读取
        const reader = new FileReader();
        reader.onload = function(e) {
            insertImageToEditor(e.target.result);
        };
        reader.readAsDataURL(file);
    }
}

// Canvas压缩图片
function compressImage(file, quality, maxDimension, callback) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const originalSrc = e.target.result;
        const img = new Image();
        img.onload = function() {
            let w = img.width, h = img.height;
            let compressed = false;
            // 如果尺寸超过maxDimension，等比缩小
            if (w > maxDimension || h > maxDimension) {
                if (w > h) { h = Math.round(h * maxDimension / w); w = maxDimension; }
                else { w = Math.round(w * maxDimension / h); h = maxDimension; }
                compressed = true;
            }
            if (compressed) {
                const canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, w, h);
                const dataUrl = canvas.toDataURL('image/jpeg', quality);
                callback(dataUrl, originalSrc);
            } else {
                callback(originalSrc, null);
            }
        };
        img.src = originalSrc;
    };
    reader.readAsDataURL(file);
}

// ===== 图片预览 =====
let imagePreviewState = { currentSrc: '', originalSrc: null, showingOriginal: false };

function openImagePreview(src, originalSrc) {
    imagePreviewState.currentSrc = src;
    imagePreviewState.originalSrc = originalSrc;
    imagePreviewState.showingOriginal = false;
    const modal = document.getElementById('imagePreviewModal');
    const img = document.getElementById('imagePreviewImg');
    const btn = document.getElementById('viewOriginalBtn');
    img.src = src;
    if (originalSrc) {
        btn.classList.remove('hidden');
        btn.textContent = '查看原图';
    } else {
        btn.classList.add('hidden');
    }
    modal.classList.remove('hidden');
}

function closeImagePreview(e) {
    if (e && e.target !== document.getElementById('imagePreviewModal')) return;
    document.getElementById('imagePreviewModal').classList.add('hidden');
    document.getElementById('imagePreviewImg').src = '';
}

function viewOriginalImage() {
    const img = document.getElementById('imagePreviewImg');
    const btn = document.getElementById('viewOriginalBtn');
    if (imagePreviewState.showingOriginal) {
        img.src = imagePreviewState.currentSrc;
        btn.textContent = '查看原图';
        imagePreviewState.showingOriginal = false;
    } else {
        img.src = imagePreviewState.originalSrc;
        btn.textContent = '查看压缩图';
        imagePreviewState.showingOriginal = true;
    }
}

// 插入图片到编辑器
function insertImageToEditor(src, originalSrc) {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;
    editor.focus();
    const origAttr = originalSrc ? ` data-original="${originalSrc}"` : '';
    const html = `<img src="${src}"${origAttr} style="max-width:100%;border-radius:12px;margin:8px 0" loading="lazy">`;
    document.execCommand('insertHTML', false, html);
}

// 初始化所见即所得编辑器
function initMarkdownEditor() {
    const editor = document.getElementById('fullscreenEditor');
    if (!editor) return;

    // 辅助函数：获取上一个/下一个块级元素
    function getPreviousBlock(el, skipChildren, skipList) {
        // 如果是 ol/ul，返回最后一个顶层 li（递归向上时跳过）
        if (!skipList && (el.tagName === 'OL' || el.tagName === 'UL')) {
            const lastLi = el.lastElementChild;
            if (lastLi) return lastLi;
        }
        let prev = el.previousSibling;
        while (prev && (prev.nodeType === 3 && prev.textContent.trim() === '')) prev = prev.previousSibling;
        while (prev && prev.nodeType === 1 && prev.tagName === 'BR') prev = prev.previousSibling;
        if (!prev) {
            if (el.parentNode && el.parentNode !== editor) {
                // 如果父节点是 ol/ul，跳过 ol/ul 找前面的块（递归向上）
                if (el.parentNode.tagName === 'OL' || el.parentNode.tagName === 'UL') {
                    return getPreviousBlock(el.parentNode, true, true);
                }
                return el.parentNode;
            }
            return null;
        }
        // 如果 prev 是 ol/ul，返回最后一个顶层 li
        if (prev.tagName === 'OL' || prev.tagName === 'UL') {
            const lastLi = prev.lastElementChild;
            if (lastLi) return lastLi;
        }
        // 如果 prev 是 li 且有子列表，进入子列表的最后一个元素
        if (prev.tagName === 'LI' && !skipChildren) {
            const subList = prev.querySelector(':scope > ol, :scope > ul');
            if (subList && subList.lastElementChild) {
                // 递归找到子列表最深层的最后一个 li
                let deepest = subList.lastElementChild;
                while (true) {
                    const childList = deepest.querySelector(':scope > ol, :scope > ul');
                    if (childList && childList.lastElementChild) {
                        deepest = childList.lastElementChild;
                    } else break;
                }
                return deepest;
            }
        }
        // 如果 prev 是 li，返回它本身
        return prev;
    }
    function getNextBlock(el, skipChildren, skipList) {
        // 如果是 ol/ul，跳到第一个 li（递归向上时跳过）
        if (!skipList && (el.tagName === 'OL' || el.tagName === 'UL')) {
            const firstLi = el.firstElementChild;
            if (firstLi) return firstLi;
        }
        // 如果是 li，检查是否有子列表（跳到第一个子 li）
        if (el.tagName === 'LI' && !skipChildren) {
            const subList = el.querySelector(':scope > ol, :scope > ul');
            if (subList && subList.firstElementChild) return subList.firstElementChild;
        }
        let next = el.nextSibling;
        while (next && (next.nodeType === 3 && next.textContent.trim() === '')) next = next.nextSibling;
        while (next && next.nodeType === 1 && next.tagName === 'BR') next = next.nextSibling;
        if (!next) {
            if (el.parentNode && el.parentNode !== editor) {
                // 如果父节点是 ol/ul，跳过 ol/ul 找后面的块（递归向上）
                if (el.parentNode.tagName === 'OL' || el.parentNode.tagName === 'UL') {
                    return getNextBlock(el.parentNode, true, true);
                }
                return el.parentNode.nextSibling;
            }
            return null;
        }
        return next;
    }
    // 辅助函数：移动光标到块级元素的末尾（或开头）
    // toStart: true=开头, false=末尾
    // isArrowDown: 按键方向（用于进入ol/ul时决定第一个还是最后一个li）
    function moveCursorToEndOfBlock(block, sel, toStart, isArrowDown) {
        // 如果目标是待办 div，直接进入其 span 找文本节点
        const taskSpan = block.querySelector && block.querySelector('span[contenteditable="true"]');
        if (taskSpan) {
            const textNode = taskSpan.firstChild;
            if (textNode && textNode.nodeType === 3) {
                const range = document.createRange();
                range.setStart(textNode, toStart ? 0 : textNode.textContent.length);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
                return;
            }
            // span 为空，光标放到 span 开头/末尾
            const range = document.createRange();
            range.selectNodeContents(taskSpan);
            range.collapse(toStart ? true : false);
            sel.removeAllRanges();
            sel.addRange(range);
            return;
        }
        // 如果目标是 ol/ul，只找直接子 li 的文本（不进入嵌套子列表）
        // 按↓进入列表 → 跳到第一个 li
        // 按↑进入列表 → 跳到最后一个 li
        if (block.tagName === 'OL' || block.tagName === 'UL') {
            const liList = Array.from(block.children).filter(c => c.tagName === 'LI');
            const targetLi = isArrowDown ? liList[0] : liList[liList.length - 1];
            if (targetLi) {
                moveCursorToEndOfBlock(targetLi, sel, toStart, isArrowDown);
                return;
            }
        }
        // 找到块内最后一个（或第一个）可编辑的文本节点（不进入子 ol/ul）
        const textNodes = [];
        const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, {
            acceptNode: function(n) {
                // 跳过 contenteditable=false 的区域
                let p = n.parentElement;
                while (p && p !== block) {
                    if (p.contentEditable === 'false') return NodeFilter.FILTER_REJECT;
                    // 不进入子列表（ol/ul）
                    if (p.tagName === 'OL' || p.tagName === 'UL') return NodeFilter.FILTER_REJECT;
                    p = p.parentElement;
                }
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let tn;
        while (tn = walker.nextNode()) textNodes.push(tn);
        if (textNodes.length === 0) {
            // 没有文本节点，光标放到块内
            const range = document.createRange();
            range.selectNodeContents(block);
            range.collapse(toStart ? true : false);
            sel.removeAllRanges();
            sel.addRange(range);
            return;
        }
        const target = toStart ? textNodes[0] : textNodes[textNodes.length - 1];
        const offset = toStart ? 0 : target.textContent.length;
        const range = document.createRange();
        range.setStart(target, offset);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
        // 光标移动后自动滚动：光标位于屏幕中间偏上
        requestAnimationFrame(() => {
            const freshRange = sel.getRangeAt(0);
            const cursorRect = freshRange.getBoundingClientRect();
            const scroller = document.getElementById('fullscreenEditorWrap');
            if (scroller) {
                const scrollerRect = scroller.getBoundingClientRect();
                const scrollerHeight = scrollerRect.height;
                const targetY = scrollerRect.top + scrollerHeight * 0.4;
                const diff = cursorRect.top - targetY;
                if (diff > 0) {
                    const maxScroll = scroller.scrollHeight - scroller.clientHeight;
                    const newScrollTop = Math.min(scroller.scrollTop + diff, maxScroll);
                    if (newScrollTop >= maxScroll && cursorRect.bottom > scrollerRect.bottom - 100) {
                        const spacer = document.createElement('div');
                        spacer.style.height = (scrollerHeight * 0.5) + 'px';
                        spacer.dataset.scrollSpacer = 'true';
                        editor.appendChild(spacer);
                    }
                    scroller.scrollTop = Math.min(scroller.scrollTop + diff, scroller.scrollHeight - scroller.clientHeight);
                }
            }
        });
    }

    // Tab 键缩进 + Backspace 删除 checkbox + 快捷键
    editor.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + Z 撤销，Ctrl/Cmd + Shift + Z 重做
        if ((e.ctrlKey || e.metaKey) && !e.altKey) {
            if (e.key === 'z' && !e.shiftKey) {
                e.preventDefault();
                document.execCommand('undo', false, null);
                return;
            }
            if ((e.key === 'z' && e.shiftKey) || e.key === 'y') {
                e.preventDefault();
                document.execCommand('redo', false, null);
                return;
            }
        }
        // ArrowUp / ArrowDown：自定义导航（文末→文末，文首→文首）
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            const sel = window.getSelection();
            if (sel.isCollapsed && sel.rangeCount) {
                let anchorNode = sel.anchorNode;
                let anchorOffset = sel.anchorOffset;
                // 判断光标是否在当前文本节点的末尾/开头
                let atEnd = false, atStart = false;
                if (anchorNode && anchorNode.nodeType === 3) {
                    atEnd = anchorOffset >= anchorNode.textContent.length;
                    atStart = anchorOffset === 0;
                } else if (anchorNode && anchorNode.nodeType === 1) {
                    atEnd = true;
                    atStart = true;
                }
                // 找到光标所在的块级元素
                let block = null;
                if (anchorNode.nodeType === 3) {
                    const taskDiv = anchorNode.parentElement.closest('div[data-task]');
                    if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                        block = taskDiv;
                    } else {
                        block = anchorNode.parentElement.closest('p,div,h1,h2,h3,h4,h5,h6,li,blockquote,ol,ul');
                        if (!block || block === editor || block.contentEditable === 'false') {
                            block = anchorNode.parentElement;
                        }
                    }
                } else {
                    const taskDiv = anchorNode.closest('div[data-task]');
                    if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                        block = taskDiv;
                    } else {
                        block = anchorNode.closest('p,div,h1,h2,h3,h4,h5,h6,li,blockquote,ol,ul');
                        if (!block || block === editor) {
                            block = anchorNode;
                        }
                    }
                }
                if (!block) { /* fallback: let browser handle */ }
                else {
                    // 获取块内的文本节点列表（不进入子列表）
                    const blockTextNodes = [];
                    const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, {
                        acceptNode: function(n) {
                            let p = n.parentElement;
                            while (p && p !== block) {
                                if (p.contentEditable === 'false') return NodeFilter.FILTER_REJECT;
                                if (p.tagName === 'OL' || p.tagName === 'UL') return NodeFilter.FILTER_REJECT;
                                p = p.parentElement;
                            }
                            return NodeFilter.FILTER_ACCEPT;
                        }
                    });
                    let tn;
                    while (tn = walker.nextNode()) blockTextNodes.push(tn);
                    // 判断光标是否在块的边界（第一个文本节点的开头 或 最后一个文本节点的末尾）
                    const isAtBlockStart = atStart && blockTextNodes.length > 0 && anchorNode === blockTextNodes[0];
                    const isAtBlockEnd = atEnd && blockTextNodes.length > 0 && anchorNode === blockTextNodes[blockTextNodes.length - 1];
                    // 文末按↓ → 下一块末尾 | 文首按↑ → 上一块开头
                    // 文末按↑ → 上一块末尾 | 文首按↓ → 下一块开头
                    const shouldNavigate = (e.key === 'ArrowDown' && isAtBlockEnd) || (e.key === 'ArrowUp' && isAtBlockStart) ||
                                           (e.key === 'ArrowUp' && isAtBlockEnd) || (e.key === 'ArrowDown' && isAtBlockStart);
                    if (shouldNavigate) {
                        let targetBlock;
                        if (e.key === 'ArrowDown') {
                            targetBlock = getNextBlock(block, false);
                        } else {
                            targetBlock = getPreviousBlock(block);
                        }
                        if (targetBlock) {
                            e.preventDefault();
                            const toStart = atStart;
                            moveCursorToEndOfBlock(targetBlock, sel, toStart, e.key === 'ArrowDown');
                        }
                    }
                }
            }
        }
        if (e.key === 'Tab') {
            e.preventDefault();
            // 检测是否在待办 li 中
            const sel = window.getSelection();
            let tabNode = sel.anchorNode;
            if (tabNode && tabNode.nodeType === 3) tabNode = tabNode.parentNode;
            const taskLi = tabNode ? tabNode.closest('li') : null;
            if (taskLi && taskLi.querySelector('input[type="checkbox"]')) {
                // 待办 li 的缩进：调整 margin-left（增加=向右缩进，减少=向左反缩进）
                const currentMargin = parseInt(taskLi.style.marginLeft) || -20;
                if (e.shiftKey) {
                    // 反缩进（向左）
                    const newMargin = currentMargin - 20;
                    taskLi.style.marginLeft = Math.max(newMargin, -20) + 'px';
                } else {
                    // 缩进（向右）
                    const newMargin = currentMargin + 20;
                    taskLi.style.marginLeft = Math.min(newMargin, 0) + 'px';
                }
                // 保持光标在 span 中
                const span = taskLi.querySelector('span');
                if (span) {
                    const r = document.createRange();
                    r.selectNodeContents(span);
                    sel.removeAllRanges();
                    sel.addRange(r);
                    sel.collapseToEnd();
                }
                return;
            }
            // 检测是否在待办 div 中（非 li）
            const taskDiv = tabNode ? tabNode.closest('div[data-task]') : null;
            if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                const currentMargin = parseInt(taskDiv.style.marginLeft) || 4;
                if (e.shiftKey) {
                    const newMargin = Math.max(currentMargin - 20, 4);
                    taskDiv.style.marginLeft = newMargin + 'px';
                } else {
                    taskDiv.style.marginLeft = (currentMargin + 20) + 'px';
                }
                // 保持光标在 span 中
                const span = taskDiv.querySelector('span');
                if (span) {
                    const r = document.createRange();
                    r.selectNodeContents(span);
                    sel.removeAllRanges();
                    sel.addRange(r);
                    sel.collapseToEnd();
                }
                return;
            }
            // 非待办中的 Tab：普通缩进/反缩进
            if (e.shiftKey) {
                document.execCommand('outdent', false, null);
            } else {
                document.execCommand('indent', false, null);
            }
            // Tab 缩进/反缩进后，自动应用嵌套样式
            setTimeout(() => {
                const sel = window.getSelection();
                if (sel.rangeCount > 0) {
                    let node = sel.anchorNode;
                    if (node && node.nodeType === 3) node = node.parentNode;
                    const li = node ? node.closest('li') : null;
                    if (li) applyNestStyleOnIndent(li);
                }
            }, 50);
        }
        // Backspace 在 checkbox 后面时，删除整个 checkbox 容器
        // Backspace 在图片后面时，删除图片
        if (e.key === 'Backspace') {
            const sel = window.getSelection();
            if (sel.isCollapsed) {
                const node = sel.anchorNode;
                if (node && node.nodeType === 3) {
                    const parentSpan = node.parentElement;
                    // 检查是否在待办事项的 span 内
                    if (parentSpan && parentSpan.tagName === 'SPAN') {
                        const taskDiv = parentSpan.closest('div[data-task]');
                        if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                            const parentLi = taskDiv.closest('li');
                            // 在 span 开头按 Backspace
                            if (sel.anchorOffset === 0 && parentSpan.textContent.trim() !== '') {
                                e.preventDefault();
                                if (parentLi) {
                                    // li 中的待办：恢复为普通列表项（保留嵌套列表）
                                    const span = taskDiv.querySelector('span');
                                    const text = span ? span.textContent : '';
                                    let nestedHtml = '';
                                    for (const child of parentLi.childNodes) {
                                        if (child.nodeType === 1 && (child.tagName === 'OL' || child.tagName === 'UL')) {
                                            nestedHtml += child.outerHTML;
                                        }
                                    }
                                    // 直接修改 li（不用 insertHTML，避免嵌套 ol 导致结构错乱）
                                    parentLi.removeAttribute('style');
                                    parentLi.innerHTML = (text || '<br>') + nestedHtml;
                                    // 光标移到恢复的 li 文本末尾
                                    const textNode = parentLi.firstChild;
                                    if (textNode && textNode.nodeType === 3) {
                                        const nr = document.createRange();
                                        nr.setStart(textNode, textNode.textContent.length);
                                        nr.collapse(true);
                                        sel.removeAllRanges();
                                        sel.addRange(nr);
                                    }
                                    updateToolbarHighlight();
                                } else {
                                    // 非 li 中的待办：找上一个兄弟任务合并
                                    const prevSibling = taskDiv.previousElementSibling;
                                    if (prevSibling) {
                                        const prevTaskDiv = prevSibling.tagName === 'DIV' && prevSibling.dataset.task ? prevSibling : prevSibling.querySelector('div[data-task]');
                                        const prevSpan = prevTaskDiv ? prevTaskDiv.querySelector('span') : null;
                                        if (prevSpan) {
                                            const currentText = parentSpan.textContent;
                                            const prevTextLen = prevSpan.textContent.length;
                                            prevSpan.textContent += currentText;
                                            taskDiv.remove();
                                            const newRange = document.createRange();
                                            newRange.setStart(prevSpan.firstChild || prevSpan, prevTextLen);
                                            newRange.collapse(true);
                                            sel.removeAllRanges();
                                            sel.addRange(newRange);
                                        }
                                    } else {
                                        // 没有上一个兄弟：变为普通段落
                                        const p = document.createElement('p');
                                        p.textContent = parentSpan.textContent || '\u200B';
                                        taskDiv.parentNode.insertBefore(p, taskDiv);
                                        taskDiv.remove();
                                        const newRange = document.createRange();
                                        newRange.setStart(p.firstChild || p, 0);
                                        newRange.collapse(true);
                                        sel.removeAllRanges();
                                        sel.addRange(newRange);
                                    }
                                }
                                return;
                            }
                            // 空待办中按 Backspace：变为正文
                            if (parentSpan.textContent.trim() === '') {
                                e.preventDefault();
                                const text = parentSpan.textContent || '';
                                const parentLi = taskDiv.closest('li');
                                if (parentLi) {
                                    parentLi.removeAttribute('style');
                                    parentLi.innerHTML = '<br>';
                                    const newRange = document.createRange();
                                    newRange.setStart(parentLi.firstChild, 0);
                                    newRange.collapse(true);
                                    sel.removeAllRanges();
                                    sel.addRange(newRange);
                                } else {
                                    const p = document.createElement('p');
                                    p.innerHTML = '<br>';
                                    taskDiv.parentNode.insertBefore(p, taskDiv);
                                    taskDiv.remove();
                                    const newRange = document.createRange();
                                    newRange.setStart(p, 0);
                                    newRange.collapse(true);
                                    sel.removeAllRanges();
                                    sel.addRange(newRange);
                                }
                                return;
                            }
                        }
                    }
                    // 检查光标在文本节点最前面，且前一个兄弟是 img
                    if (sel.anchorOffset === 0) {
                        const prevSibling = node.previousSibling;
                        if (prevSibling && prevSibling.tagName === 'IMG') {
                            e.preventDefault();
                            prevSibling.parentNode.removeChild(prevSibling);
                            return;
                        }
                        // 也检查父元素的 previousSibling
                        if (parentSpan && parentSpan.previousSibling && parentSpan.previousSibling.tagName === 'IMG') {
                            e.preventDefault();
                            parentSpan.previousSibling.parentNode.removeChild(parentSpan.previousSibling);
                            return;
                        }
                    }
                }
                // 光标直接在 img 元素上（选中了图片）
                if (node && node.nodeType === 1 && node.tagName === 'IMG') {
                    e.preventDefault();
                    node.parentNode.removeChild(node);
                    return;
                }
                // 光标在待办 span 元素本身（非文本节点，如空 span 只有 <br>）
                if (node && node.nodeType === 1 && node.tagName === 'SPAN') {
                    const taskDiv = node.closest('div[data-task]');
                    if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                        e.preventDefault();
                        const p = document.createElement('p');
                        p.innerHTML = '<br>';
                        taskDiv.parentNode.insertBefore(p, taskDiv);
                        taskDiv.remove();
                        const newRange = document.createRange();
                        newRange.setStart(p, 0);
                        newRange.collapse(true);
                        sel.removeAllRanges();
                        sel.addRange(newRange);
                        return;
                    }
                }
            }
        }
        // Enter 键：在列表项末尾按回车时，如果有子列表，不拆分，而是在整个 li 后面创建新空 li
        if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
            const sel = window.getSelection();
            if (sel.isCollapsed && sel.rangeCount) {
                let node = sel.anchorNode;
                if (node && node.nodeType === 3) node = node.parentNode;

                // === 待办项中按 Enter：新建空待办或拆分待办 ===
                const taskDiv = node ? node.closest('div[data-task]') : null;
                if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                    const checkbox = taskDiv.querySelector('input[type="checkbox"]');
                    const span = taskDiv.querySelector('span');
                    // 检测是否在 li 中
                    const parentLi = taskDiv.closest('li');
                    if (span && span.textContent.trim() === '') {
                        // 空待办中按 Enter：退出待办模式
                        e.preventDefault();
                        if (parentLi) {
                            // 在 li 中：恢复为普通列表项
                            parentLi.removeAttribute('style');
                            parentLi.innerHTML = '<br>';
                            const newRange = document.createRange();
                            newRange.setStart(parentLi.firstChild, 0);
                            newRange.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(newRange);
                        } else {
                            // 不在 li 中：变为普通段落
                            const p = document.createElement('p');
                            p.innerHTML = '<br>';
                            taskDiv.parentNode.insertBefore(p, taskDiv);
                            taskDiv.remove();
                            const newRange = document.createRange();
                            newRange.setStart(p, 0);
                            newRange.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(newRange);
                        }
                        return;
                    } else {
                        e.preventDefault();
                        // 检查光标是否在文本中间（可拆分）还是末尾（新建空待办）
                        const textNode = sel.anchorNode;
                        const offset = sel.anchorOffset;
                        let beforeText = '', afterText = '';
                        if (textNode && textNode.nodeType === 3 && span.contains(textNode)) {
                            beforeText = textNode.textContent.substring(0, offset);
                            afterText = textNode.textContent.substring(offset);
                        } else if (textNode === span || (textNode && span.contains(textNode))) {
                            // 光标在 span 元素本身
                            beforeText = span.textContent;
                            afterText = '';
                        } else {
                            beforeText = span.textContent;
                            afterText = '';
                        }
                        beforeText = beforeText || '';
                        afterText = afterText || '';
                        const checkedAttr = checkbox.checked ? ' checked' : '';
                        const textDecoration = checkbox.checked ? 'line-through' : 'none';
                        const opacity = checkbox.checked ? '0.5' : '1';
                        if (afterText.trim()) {
                            // 光标在文本中间：拆分为两个待办（使用 execCommand 支持 undo）
                            // 更新当前待办文本
                            span.textContent = beforeText;
                            // 在当前待办后插入新待办（带后半段文本）
                            const escapedAfter = afterText.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                            if (parentLi) {
                                // 在 li 中：用 execCommand insertHTML 插入新 li
                                const newTaskHtml = `<li style="list-style-type:none;margin-left:${parentLi.style.marginLeft || '-20px'}"><div data-task="true" style="display:flex;align-items:center;gap:4px;text-decoration:${textDecoration};opacity:${opacity}" contenteditable="false"><input type="checkbox"${checkedAttr} onclick="handleTaskCheck(this)" style="margin:0;flex-shrink:0"><span style="flex:1;min-width:0" contenteditable="true">${escapedAfter}</span></div></li>`;
                                // 在当前 li 后面插入
                                const marker = document.createElement('span');
                                marker.id = '_task_split_marker';
                                parentLi.parentNode.insertBefore(marker, parentLi.nextSibling);
                                marker.outerHTML = newTaskHtml;
                                const newTaskLi = parentLi.nextSibling;
                                const newSpan = newTaskLi.querySelector('span');
                                const newRange = document.createRange();
                                newRange.setStart(newSpan.firstChild || newSpan, 0);
                                newRange.collapse(true);
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                            } else {
                                const newTaskHtml = `<div data-task="true" style="display:flex;align-items:center;gap:4px;margin:4px 0;margin-left:4px;text-decoration:${textDecoration};opacity:${opacity}" contenteditable="false"><input type="checkbox"${checkedAttr} onclick="handleTaskCheck(this)" style="margin:0;flex-shrink:0"><span style="flex:1;min-width:0" contenteditable="true">${escapedAfter}</span></div>`;
                                const marker = document.createElement('span');
                                marker.id = '_task_split_marker';
                                taskDiv.parentNode.insertBefore(marker, taskDiv.nextSibling);
                                marker.outerHTML = newTaskHtml;
                                const newTask = taskDiv.nextSibling;
                                const newSpan = newTask.querySelector('span');
                                const newRange = document.createRange();
                                newRange.setStart(newSpan.firstChild || newSpan, 0);
                                newRange.collapse(true);
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                            }
                        } else {
                            // 光标在末尾
                            if (parentLi) {
                                // 在 li 中的待办末尾按 Enter：创建普通列表项（退出待办模式）
                                e.preventDefault();
                                const newLiHtml = '<li><br></li>';
                                const temp = document.createElement('div');
                                temp.innerHTML = newLiHtml;
                                const newLi = temp.firstChild;
                                parentLi.parentNode.insertBefore(newLi, parentLi.nextSibling);
                                const newRange = document.createRange();
                                newRange.setStart(newLi.firstChild, 0);
                                newRange.collapse(true);
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                            } else {
                                // 非 li 中的待办末尾按 Enter：创建普通段落
                                e.preventDefault();
                                const p = document.createElement('p');
                                p.innerHTML = '<br>';
                                taskDiv.parentNode.insertBefore(p, taskDiv.nextSibling);
                                const newRange = document.createRange();
                                newRange.setStart(p, 0);
                                newRange.collapse(true);
                                sel.removeAllRanges();
                                sel.addRange(newRange);
                            }
                        }
                    }
                    return;
                }

                const li = node ? node.closest('li') : null;
                if (li) {
                    // === 5s 内空列表项再按 Enter：退出列表 ===
                    const liText = li.textContent.trim();
                    if (liText === '') {
                        const now = Date.now();
                        if (window._lastEmptyLiEnterTime && (now - window._lastEmptyLiEnterTime) < 5000) {
                            // 5s 内再次在空 li 中按 Enter，退出列表
                            e.preventDefault();
                            window._lastEmptyLiEnterTime = null;
                            // 将空 li 替换为空 p（放在列表容器之后）
                            const listEl = li.closest('ol, ul');
                            const p = document.createElement('p');
                            p.innerHTML = '<br>';
                            if (listEl && listEl.children.length <= 1) {
                                // 列表只剩这一个空 li，移除整个列表
                                listEl.parentNode.insertBefore(p, listEl);
                                listEl.remove();
                            } else {
                                // 列表还有其他项，只移除空 li
                                li.remove();
                                listEl.parentNode.insertBefore(p, listEl.nextSibling);
                            }
                            // 光标移到 p 中
                            const newRange = document.createRange();
                            newRange.setStart(p, 0);
                            newRange.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(newRange);
                            return;
                        }
                        window._lastEmptyLiEnterTime = now;
                    } else {
                        window._lastEmptyLiEnterTime = null;
                    }

                    // 检查当前 li 是否有子列表
                    const subLists = li.querySelectorAll(':scope > ol, :scope > ul');
                    if (subLists.length > 0) {
                        // 检查光标是否在 li 的文本末尾（即子列表之前）
                        const textParts = [];
                        for (const child of li.childNodes) {
                            if (child.nodeType === 3) textParts.push(child);
                            else if (child.nodeType === 1 && child.tagName !== 'OL' && child.tagName !== 'UL') textParts.push(child);
                        }
                        // 找到光标所在的文本部分
                        let cursorAtTextEnd = false;
                        for (const part of textParts) {
                            if (part.contains && part.contains(sel.anchorNode)) {
                                // 光标在这个文本部分中
                                if (sel.anchorNode.nodeType === 3) {
                                    cursorAtTextEnd = sel.anchorOffset >= sel.anchorNode.textContent.length;
                                } else {
                                    cursorAtTextEnd = true;
                                }
                                break;
                            }
                        }
                        if (cursorAtTextEnd) {
                            e.preventDefault();
                            // 在当前 li 后面创建新的空 li
                            const newLi = document.createElement('li');
                            newLi.innerHTML = '<br>';
                            li.parentNode.insertBefore(newLi, li.nextSibling);
                            // 把光标移到新 li 中
                            const newRange = document.createRange();
                            newRange.setStart(newLi, 0);
                            newRange.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(newRange);
                            return;
                        }
                    }
                }
            }
        }
    });
    // 粘贴图片支持（带压缩）
    editor.addEventListener('paste', function(e) {
        const items = e.clipboardData && e.clipboardData.items;
        if (!items) return;
        for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
                e.preventDefault();
                const blob = items[i].getAsFile();
                const SIZE_LIMIT = 10 * 1024 * 1024;
                if (blob.size > SIZE_LIMIT) {
                    compressImage(blob, 0.8, 2400, function(dataUrl, originalSrc) {
                        editor.focus();
                        insertImageToEditor(dataUrl, originalSrc);
                    });
                } else {
                    const reader = new FileReader();
                    reader.onload = function(evt) {
                        editor.focus();
                        insertImageToEditor(evt.target.result);
                    };
                    reader.readAsDataURL(blob);
                }
                return;
            }
        }
    });
    // 监听选区变化，高亮当前格式
    editor.addEventListener('keyup', updateToolbarHighlight);
    editor.addEventListener('mouseup', updateToolbarHighlight);
    editor.addEventListener('click', updateToolbarHighlight);
    // 点击 checkbox 时，将光标移到 span 中并更新工具栏高亮
    editor.addEventListener('click', function(e) {
        if (e.target.tagName === 'INPUT' && e.target.type === 'checkbox') {
            const taskDiv = e.target.closest('div[data-task]');
            if (taskDiv) {
                const span = taskDiv.querySelector('span');
                if (span) {
                    const newRange = document.createRange();
                    newRange.setStart(span.firstChild || span, 0);
                    newRange.collapse(true);
                    const s = window.getSelection();
                    s.removeAllRanges();
                    s.addRange(newRange);
                    setTimeout(updateToolbarHighlight, 10);
                }
            }
        }
    });
    // 点击图片打开预览
    editor.addEventListener('click', function(e) {
        if (e.target.tagName === 'IMG') {
            e.preventDefault();
            e.stopPropagation();
            const src = e.target.src;
            const originalSrc = e.target.getAttribute('data-original');
            openImagePreview(src, originalSrc);
        }
    });
    // 点击列表项右侧空白区域时，将光标移到文本末尾而非开头
    // 使用 mousedown 而非 click，避免光标先跳左边再跳右边的闪烁
    editor.addEventListener('mousedown', function(e) {
        // 只处理左键
        if (e.button !== 0) return;
        let node = e.target;
        if (!node) return;
        if (node.nodeType === 3) node = node.parentNode;
        // 检查是否点击了 checkbox（不拦截）
        if (node && node.tagName === 'INPUT' && node.type === 'checkbox') return;

        // 找到最近的块级元素
        let block = null;
        const li = node ? node.closest('li') : null;
        if (li) {
            block = li;
        } else {
            // 也处理 p, h1-h6, blockquote, div（待办）等块级元素
            block = node ? node.closest('p,div,h1,h2,h3,h4,h5,h6,blockquote') : null;
            // 如果是待办 div，找到它的 span
            if (block && block.querySelector('input[type="checkbox"]')) {
                // 点击待办区域时，让默认行为处理（点击 span 内部会自动定位）
                return;
            }
        }
        if (!block) return;

        // 找到块内最后一个有内容的文本节点及其右边界
        let lastTextNode = null;
        for (const child of block.childNodes) {
            if (child.nodeType === 3 && child.textContent.trim()) {
                lastTextNode = child;
            } else if (child.nodeType === 1 && child.tagName !== 'OL' && child.tagName !== 'UL') {
                const walker = document.createTreeWalker(child, NodeFilter.SHOW_TEXT, null);
                let textNode;
                while (textNode = walker.nextNode()) {
                    if (textNode.textContent.trim()) lastTextNode = textNode;
                }
            }
        }
        if (!lastTextNode) return;
        // 检查点击位置是否在最后一个文本节点的右边界之后（即空白区域）
        try {
            const textRange = document.createRange();
            textRange.selectNodeContents(lastTextNode);
            const textRect = textRange.getBoundingClientRect();
            if (e.clientX > textRect.right + 4) {
                e.preventDefault();
                // 立即设置光标到文本末尾，避免先跳到序号旁再跳回来的闪烁
                const sel = window.getSelection();
                const range = document.createRange();
                range.setStart(lastTextNode, lastTextNode.textContent.length);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
        } catch(err) {}
    });

    // 双击选中当前块的全部文本内容（不跨子元素边界）
    // 用 mousedown 检测双击，在第二次点击时阻止 selectstart 来避免浏览器选词
    let _lastClickTime = 0;
    let _lastClickBlock = null;
    let _blockOnSelectStart = null;
    editor.addEventListener('mousedown', function(e) {
        if (e.button !== 0) return;
        let node = e.target;
        if (!node) return;
        if (node.nodeType === 3) node = node.parentNode;
        // 找到光标所在的最内层块级元素
        let block = null;
        const taskDiv = node.closest('div[data-task]');
        if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
            block = taskDiv;
        } else {
            block = node.closest('p,h1,h2,h3,h4,h5,h6,blockquote');
            if (!block) {
                let el = node;
                while (el && el !== editor) {
                    if (el.tagName === 'LI') { block = el; break; }
                    el = el.parentElement;
                }
            }
        }
        if (!block) return;
        const now = Date.now();
        if (_lastClickBlock === block && (now - _lastClickTime) < 400) {
            // 双击确认：记录要全选的块，在 selectstart 时阻止并全选
            _blockOnSelectStart = block;
        } else {
            _blockOnSelectStart = null;
        }
        _lastClickTime = now;
        _lastClickBlock = block;
    });
    editor.addEventListener('selectstart', function(e) {
        if (_blockOnSelectStart) {
            e.preventDefault();
            const block = _blockOnSelectStart;
            _blockOnSelectStart = null;
            const sel = window.getSelection();
            const range = document.createRange();
            const isHeading = /^H[1-6]$/.test(block.tagName);
            const isLiWithSublist = block.tagName === 'LI' && block.querySelector(':scope > ol, :scope > ul');
            if (isLiWithSublist || isHeading) {
                let startNode = null, endNode = null;
                for (const child of block.childNodes) {
                    if (child.nodeType === 3 && child.textContent.trim()) {
                        if (!startNode) startNode = child;
                        endNode = child;
                    } else if (child.nodeType === 1 && child.tagName !== 'OL' && child.tagName !== 'UL' && !child.classList.contains('fold-toggle')) {
                        if (!startNode) startNode = child;
                        endNode = child;
                    }
                }
                if (startNode && endNode) {
                    range.setStart(startNode, 0);
                    if (endNode.nodeType === 3) range.setEnd(endNode, endNode.textContent.length);
                    else range.setEndAfter(endNode);
                } else {
                    range.selectNodeContents(block);
                }
            } else {
                range.selectNodeContents(block);
            }
            sel.removeAllRanges();
            sel.addRange(range);
        }
    });

    // 输入 "1." 或 "- " 自动转为有序/无序列表
    editor.addEventListener('input', function(e) {
        const sel = window.getSelection();
        if (!sel.isCollapsed || !sel.rangeCount) return;
        let node = sel.anchorNode;
        if (!node) return;
        // 如果光标已在列表上下文（li/ol/ul）内，不触发自动转换（避免干扰正常编辑）
        // 需要同时检查文本节点和元素节点的情况
        let checkNode = node.nodeType === 3 ? node.parentElement : node;
        if (checkNode && (checkNode.closest('li') || checkNode.closest('ol') || checkNode.closest('ul'))) return;
        if (node.nodeType !== 3) return;
        const text = node.textContent;
        const offset = sel.anchorOffset;
        // 检查光标前的文本是否匹配 "数字." 或 "- "
        const before = text.substring(0, offset);
        // 有序列表：匹配 "1." "2." 等（数字+点+空格或行尾）
        const olMatch = before.match(/(\d+)\.\s$/);
        if (olMatch) {
            const num = parseInt(olMatch[1]);
            // 替换 "1. " 为空，然后插入有序列表
            e.preventDefault();
            const range = sel.getRangeAt(0);
            range.setStart(node, offset - olMatch[0].length);
            range.deleteContents();
            document.execCommand('insertOrderedList', false, null);
            // 设置起始编号
            setTimeout(() => {
                const ol = editor.querySelector('ol');
                if (ol && num > 1) ol.setAttribute('start', String(num));
            }, 20);
            return;
        }
        // 无序列表：匹配 "- "
        const ulMatch = before.match(/-\s$/);
        if (ulMatch) {
            e.preventDefault();
            const range = sel.getRangeAt(0);
            range.setStart(node, offset - ulMatch[0].length);
            range.deleteContents();
            document.execCommand('insertUnorderedList', false, null);
            return;
        }
        // 打字时自动滚动：光标位于屏幕中间偏上
        requestAnimationFrame(() => {
            const freshRange = sel.getRangeAt(0);
            const cursorRect = freshRange.getBoundingClientRect();
            const scroller = document.getElementById('fullscreenEditorWrap');
            if (scroller) {
                const scrollerRect = scroller.getBoundingClientRect();
                const scrollerHeight = scrollerRect.height;
                // 目标：光标位于视口高度的 40% 处（中间偏上）
                const targetY = scrollerRect.top + scrollerHeight * 0.4;
                const diff = cursorRect.top - targetY;
                // 只有当光标在目标位置下方时才滚动
                if (diff > 0) {
                    // 如果滚动到底后光标仍在底部，添加底部留白
                    const maxScroll = scroller.scrollHeight - scroller.clientHeight;
                    const newScrollTop = Math.min(scroller.scrollTop + diff, maxScroll);
                    if (newScrollTop >= maxScroll && cursorRect.bottom > scrollerRect.bottom - 100) {
                        // 添加底部留白（半个视口高度）
                        const spacer = document.createElement('div');
                        spacer.style.height = (scrollerHeight * 0.5) + 'px';
                        spacer.dataset.scrollSpacer = 'true';
                        editor.appendChild(spacer);
                    }
                    scroller.scrollTop = Math.min(scroller.scrollTop + diff, scroller.scrollHeight - scroller.clientHeight);
                }
            }
        });
    });

    // 工具栏触摸/鼠标 tooltip 支持
    const tooltipEl = document.getElementById('mdTooltip');
    const tooltipText = document.getElementById('mdTooltipText');
    let tooltipTimer = null;

    function showToolbarTooltip(btn) {
        if (!tooltipEl || !tooltipText) return;
        const text = btn.getAttribute('data-tooltip');
        if (!text) return;
        tooltipText.textContent = text;
        // 计算位置：按钮上方居中
        const btnRect = btn.getBoundingClientRect();
        const toolbarHeight = 56; // 工具栏大致高度
        tooltipEl.style.left = (btnRect.left + btnRect.width / 2) + 'px';
        tooltipEl.style.bottom = (window.innerHeight - btnRect.top + 6) + 'px';
        tooltipEl.style.transform = 'translateX(-50%)';
        tooltipEl.style.opacity = '1';
    }

    function hideToolbarTooltip() {
        if (!tooltipEl) return;
        tooltipEl.style.opacity = '0';
        clearTimeout(tooltipTimer);
    }

    document.querySelectorAll('#fullscreenEditorModal .toolbar-btn').forEach(btn => {
        // 鼠标 hover
        btn.addEventListener('mouseenter', function() {
            clearTimeout(tooltipTimer);
            showToolbarTooltip(btn);
        });
        btn.addEventListener('mouseleave', function() {
            hideToolbarTooltip();
        });
        // 触摸支持
        btn.addEventListener('touchstart', function(e) {
            clearTimeout(tooltipTimer);
            showToolbarTooltip(btn);
            tooltipTimer = setTimeout(hideToolbarTooltip, 1500);
        }, { passive: true });
        btn.addEventListener('touchend', function() {
            tooltipTimer = setTimeout(hideToolbarTooltip, 800);
        });
    });
}

function updateToolbarHighlight() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    const activeColor = theme.primary;
    const activeBg = theme.primaryFaint;
    // 获取光标所在的最内层块级元素标签（穿透 li 检测 h1-h5）
    const sel = window.getSelection();
    let cursorBlock = '';
    let inUl = false, inOl = false, inTask = false;
    if (sel.rangeCount > 0) {
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        // 检测是否在待办中（li 或 div 中的 checkbox）
        if (node) {
            const taskLi = node.closest('li');
            if (taskLi && taskLi.querySelector('input[type="checkbox"]')) {
                inTask = true;
            } else {
                const taskDiv = node.closest('div[data-task]');
                if (taskDiv && taskDiv.querySelector('input[type="checkbox"]')) {
                    inTask = true;
                }
            }
        }
        // 检测是否在列表中（排除待办 li）
        if (node && !inTask) {
            const li = node.closest('li');
            if (li) {
                const ul = li.closest('ul');
                const ol = li.closest('ol');
                inUl = !!ul;
                inOl = !!ol;
            }
        }
        // 优先查找最近的 h1-h6/blockquote（穿透 li）
        const heading = node ? node.closest('h1,h2,h3,h4,h5,h6,blockquote') : null;
        if (heading) {
            cursorBlock = heading.tagName.toLowerCase();
        } else {
            // 回退到 formatBlock
            cursorBlock = document.queryCommandValue('formatBlock').replace(/[<>]/g, '').toLowerCase();
        }
    }
    document.querySelectorAll('.toolbar-btn').forEach(btn => {
        const cmd = btn.dataset.cmd;
        let isActive = false;
        if (cmd === 'bold') {
            isActive = document.queryCommandState('bold');
        } else if (cmd === 'italic') {
            isActive = document.queryCommandState('italic');
        } else if (cmd === 'insertUnorderedList') {
            isActive = inTask ? false : inUl;
        } else if (cmd === 'insertOrderedList') {
            isActive = inTask ? false : inOl;
        } else if (cmd === 'h1' || cmd === 'h2' || cmd === 'h3' || cmd === 'h4' || cmd === 'h5') {
            isActive = cursorBlock === cmd;
        } else if (cmd === 'quote') {
            isActive = cursorBlock === 'blockquote';
        } else if (cmd === 'task') {
            isActive = inTask;
        }
        if (isActive) {
            btn.style.color = activeColor;
            btn.style.backgroundColor = activeBg;
        } else {
            btn.style.color = '';
            btn.style.backgroundColor = '';
        }
    });
}

// HTML 转 Markdown（保存时用）
// 将嵌套 HTML 列表一次性转换为带缩进的 Markdown
function convertNestedListsToMd(html, tag) {
    // 找到所有顶层 <tag> 元素
    const outerRegex = new RegExp('<' + tag + '([^>]*)>([\\s\\S]*)</' + tag + '>', 'gi');
    return html.replace(outerRegex, function(match, attrs, inner) {
        return convertListTreeToMd(inner, attrs, tag, 0);
    });
}

// 递归转换列表树
function convertListTreeToMd(html, parentAttrs, parentTag, depth) {
    const indent = '   '.repeat(depth);
    const startMatch = parentAttrs.match(/start=["']?(\d+)/i);
    let idx = startMatch ? parseInt(startMatch[1]) : 1;
    const styleMatch = parentAttrs.match(/style=["'][^"']*list-style-type:\s*([^;"']+)/i);
    const listStyle = styleMatch ? styleMatch[1].trim() : (parentTag === 'ol' ? 'decimal' : 'disc');
    
    const numStr = (n) => {
        if (listStyle === 'lower-alpha') return String.fromCharCode(96 + n);
        if (listStyle === 'upper-alpha') return String.fromCharCode(64 + n);
        if (listStyle === 'lower-roman') {
            const romans = ['','i','ii','iii','iv','v','vi','vii','viii','ix','x',
                'xi','xii','xiii','xiv','xv','xvi','xvii','xviii','xix','xx'];
            return (romans[n] || String(n));
        }
        return String(n);
    };
    
    let result = '';
    let pos = 0;
    while (pos < html.length) {
        // 找到下一个 <li
        const liStart = html.indexOf('<li', pos);
        if (liStart === -1) {
            // 处理剩余的非 li 内容（如占位符）
            if (pos < html.length) {
                const remaining = html.substring(pos).replace(/<[^>]+>/g, '').trim();
                if (remaining) result += indent + remaining + '\n';
            }
            break;
        }
        // 处理 <li 之前的非 li 内容（如占位符）
        if (liStart > pos) {
            const beforeLi = html.substring(pos, liStart).replace(/<[^>]+>/g, '').trim();
            if (beforeLi) result += indent + beforeLi + '\n';
        }
        const liTagEnd = html.indexOf('>', liStart);
        if (liTagEnd === -1) break;
        const contentStart = liTagEnd + 1;
        
        // 用深度计数找到匹配的 </li>
        let liDepth = 1;
        let searchPos = contentStart;
        let liEnd = -1;
        while (searchPos < html.length && liDepth > 0) {
            const nextOpen = html.indexOf('<li', searchPos);
            const nextClose = html.indexOf('</li>', searchPos);
            if (nextClose === -1) break;
            if (nextOpen !== -1 && nextOpen < nextClose) {
                liDepth++;
                searchPos = nextOpen + 3;
            } else {
                liDepth--;
                if (liDepth === 0) liEnd = nextClose;
                searchPos = nextClose + 5;
            }
        }
        if (liEnd === -1) break;
        
        const liContent = html.substring(contentStart, liEnd);
        
        // 分离文本和嵌套列表
        let textParts = [];
        let childLists = [];
        let tempPos = 0;
        while (tempPos < liContent.length) {
            const olStart = liContent.indexOf('<ol', tempPos);
            const ulStart = liContent.indexOf('<ul', tempPos);
            let listStart = -1;
            let listTag = '';
            if (olStart !== -1 && (ulStart === -1 || olStart < ulStart)) {
                listStart = olStart;
                listTag = 'ol';
            } else if (ulStart !== -1) {
                listStart = ulStart;
                listTag = 'ul';
            }
            if (listStart === -1) {
                textParts.push(liContent.substring(tempPos));
                break;
            }
            textParts.push(liContent.substring(tempPos, listStart));
            // 找到匹配的 </ol> 或 </ul>
            const closeTag = '</' + listTag + '>';
            let listDepth = 1;
            let listSearchPos = listStart + listTag.length + 1;
            let listEnd = -1;
            while (listSearchPos < liContent.length && listDepth > 0) {
                const nextO = liContent.indexOf('<' + listTag, listSearchPos);
                const nextC = liContent.indexOf(closeTag, listSearchPos);
                if (nextC === -1) break;
                if (nextO !== -1 && nextO < nextC) {
                    listDepth++;
                    listSearchPos = nextO + listTag.length + 1;
                } else {
                    listDepth--;
                    if (listDepth === 0) listEnd = nextC;
                    listSearchPos = nextC + closeTag.length;
                }
            }
            if (listEnd === -1) {
                textParts.push(liContent.substring(tempPos));
                break;
            }
            // 提取列表标签的属性
            const listTagMatch = liContent.substring(listStart).match(new RegExp('<' + listTag + '([^>]*)>'));
            const listAttrs = listTagMatch ? listTagMatch[1] : '';
            const fullTagLen = listTagMatch ? listTagMatch[0].length : (listTag.length + 2);
            const listInner = liContent.substring(listStart + fullTagLen, listEnd);
            childLists.push({attrs: listAttrs, tag: listTag, inner: listInner});
            tempPos = listEnd + closeTag.length;
        }
        
        // 清理文本中的 HTML 标签
        let text = textParts.join('').replace(/<[^>]+>/g, '').trim();
        
        // 生成当前行
        if (parentTag === 'ol') {
            result += indent + numStr(idx) + '. ' + text + '\n';
            idx++;
        } else {
            result += indent + '- ' + text + '\n';
        }
        
        // 递归处理子列表
        for (const child of childLists) {
            result += convertListTreeToMd(child.inner, child.attrs, child.tag, depth + 1);
        }
        
        pos = liEnd + 5;
    }
    return result;
}

function htmlToMarkdown(html) {
    if (!html || !html.trim()) return '';
    let md = html;
    // 标题
    md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n\n');
    md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n\n');
    md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n\n');
    md = md.replace(/<h4[^>]*>(.*?)<\/h4>/gi, '#### $1\n\n');
    md = md.replace(/<h5[^>]*>(.*?)<\/h5>/gi, '##### $1\n\n');
    // 加粗
    md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
    md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
    // 斜体
    md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
    md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
    // 引用
    md = md.replace(/<blockquote[^>]*>(.*?)<\/blockquote>/gi, '> $1\n\n');
    // 任务列表（li 中的任务，可能有嵌套列表）
    // 用循环+深度计数来正确匹配嵌套 li
    let taskResults = [];
    let mdForTask = md;
    while (/<li[^>]*style="[^"]*list-style-type:\s*none[^"]*"[^>]*>/i.test(mdForTask)) {
        const startMatch = mdForTask.match(/<li[^>]*style="[^"]*list-style-type:\s*none[^"]*"[^>]*>/i);
        if (!startMatch) break;
        const startIdx = startMatch.index;
        const contentStart = startIdx + startMatch[0].length;
        let depth = 1;
        let pos = contentStart;
        let endIdx = -1;
        while (pos < mdForTask.length && depth > 0) {
            const nextOpen = mdForTask.indexOf('<li', pos);
            const nextClose = mdForTask.indexOf('</li>', pos);
            if (nextClose === -1) break;
            if (nextOpen !== -1 && nextOpen < nextClose) {
                depth++;
                pos = nextOpen + 3;
            } else {
                depth--;
                if (depth === 0) endIdx = nextClose;
                pos = nextClose + 5;
            }
        }
        if (endIdx === -1) break;
        const inner = mdForTask.substring(contentStart, endIdx);
        const divMatch = inner.match(/<div[^>]*data-task="true"[^>]*>\s*<input[^>]*type="checkbox"[^>]*>(?:\s*<\/input>)?\s*<span[^>]*>([\s\S]*?)<\/span>\s*<\/div>/i);
        if (divMatch) {
            const taskText = divMatch[1];
            const afterDiv = inner.replace(divMatch[0], '');
            // afterDiv 中可能包含嵌套列表（ol/ul），保留它们让后续 convertNestedListsToMd 处理
            // 只移除非列表的 HTML 标签
            const afterDivClean = afterDiv.replace(/<(?!\/?(?:ol|ul|li)\b)[^>]+>/g, '').replace(/<\/(?!ol|ul|li)\b[^>]*>/g, '').trim();
            taskResults.push('- [ ] ' + taskText + (afterDivClean ? '\n' + afterDivClean : ''));
            mdForTask = mdForTask.substring(0, startIdx) + '\nTASK_PLACEHOLDER_' + (taskResults.length - 1) + '\n' + mdForTask.substring(endIdx + 5);
        } else {
            break;
        }
    }
    // 将处理后的 md 用于后续
    md = mdForTask;
    // div 形式的任务
    md = md.replace(/<div[^>]*data-task="true"[^>]*>\s*<input[^>]*type="checkbox"[^>]*>(?:\s*<\/input>)?\s*<span[^>]*>(.*?)<\/span>\s*<\/div>/gi, '- [ ] $1\n');
    // 有序列表（逐层处理以支持嵌套）
    md = convertNestedListsToMd(md, 'ol');
    // 无序列表（逐层处理以支持嵌套）
    md = convertNestedListsToMd(md, 'ul');
    // 兜底：处理没有包裹在 ul/ol 中的 li
    md = md.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n');
    md = md.replace(/<\/?[uo]l[^>]*>/gi, '');
    // 图片
    md = md.replace(/<img[^>]*src="([^"]*)"[^>]*>/gi, '![]($1)\n\n');
    // 链接
    md = md.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
    // 代码块
    md = md.replace(/<pre[^>]*><code[^>]*>(.*?)<\/code><\/pre>/gi, '```\n$1\n```\n\n');
    // 行内代码
    md = md.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
    // 分割线
    md = md.replace(/<hr[^>]*>/gi, '\n---\n\n');
    // 换行
    md = md.replace(/<br[^>]*>/gi, '\n');
    // 段落
    md = md.replace(/<p[^>]*>(.*?)<\/p>/gi, '$1\n\n');
    // div
    md = md.replace(/<div[^>]*>(.*?)<\/div>/gi, '$1\n');
    // 清理剩余标签
    md = md.replace(/<[^>]+>/g, '');
    // 清理 HTML 实体
    md = md.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"');
    // 清理多余空行
    md = md.replace(/\n{3,}/g, '\n\n').trim();
    // 替换任务列表占位符
    taskResults.forEach((result, i) => {
        md = md.replace('TASK_PLACEHOLDER_' + i, result);
    });
    // 任务列表的嵌套列表可能还没被转换，再处理一次
    md = convertNestedListsToMd(md, 'ol');
    md = convertNestedListsToMd(md, 'ul');
    return md;
}

// Markdown 转 HTML（打开编辑器时用）
// 判断一行是否是列表项（包括缩进的子列表）
function isListLine(line) {
    const t = line.trim();
    return /^- /.test(t) || /^\d+\. /.test(t) || /^[a-zA-Z]\. /.test(t) || /^[ivxIVX]+\. /.test(t);
}

// 获取列表项的缩进级别（每级3个空格或1个tab）
function getIndentLevel(line) {
    const match = line.match(/^(\s*)/);
    if (!match) return 0;
    const spaces = match[1].replace(/\t/g, '   ').length;
    return Math.floor(spaces / 3);
}

// 判断列表项类型
function getListItemType(line) {
    const t = line.trim();
    if (/^- /.test(t)) return 'ul';
    return 'ol';
}

// 为嵌套列表添加层级样式（通过后处理 HTML 字符串）
function applyNestListStyles(html) {
    // 处理有序列表嵌套：ol > ol 第二层用 lower-alpha，第三层用 lower-roman
    html = html.replace(/(<ol>)(<li>)/g, '$1$2'); // 根层保持 decimal
    // 给非根层的 ol 添加样式（通过匹配嵌套在 li 内的 ol）
    let depth = 0;
    let result = '';
    for (let j = 0; j < html.length; j++) {
        if (html.substr(j, 4) === '<ol>') {
            if (depth > 0) {
                const style = depth === 1 ? ' style="list-style-type:lower-alpha"' : ' style="list-style-type:lower-roman"';
                result += '<ol' + style + '>';
            } else {
                result += '<ol>';
            }
            depth++;
            j += 3;
        } else if (html.substr(j, 5) === '</ol>') {
            depth--;
            result += '</ol>';
            j += 4;
        } else if (html.substr(j, 4) === '<ul>') {
            if (depth > 0) {
                const style = depth === 1 ? ' style="list-style-type:circle"' : ' style="list-style-type:square"';
                result += '<ul' + style + '>';
            } else {
                result += '<ul>';
            }
            depth++;
            j += 3;
        } else if (html.substr(j, 5) === '</ul>') {
            depth--;
            result += '</ul>';
            j += 4;
        } else {
            result += html[j];
        }
    }
    return result;
}

// 解析嵌套列表，返回 HTML 字符串
// 使用递归方式确保子列表嵌套在父 <li> 内部
function parseNestedList(lines, startIdx, rootType) {
    let i = startIdx;
    const baseIndent = getIndentLevel(lines[i]);
    const tag = rootType;
    let html = '<' + tag + '>';

    while (i < lines.length && isListLine(lines[i])) {
        const line = lines[i];
        const indent = getIndentLevel(line);
        const trimmed = line.trim();

        if (indent < baseIndent) break; // 回到更外层，停止

        if (indent === baseIndent) {
            // 同级列表项
            const liType = getListItemType(trimmed);
            let text = trimmed.replace(/^-\s+|^\d+\.\s+|^[a-zA-Z]\.\s+|^[ivxIVX]+\.\s+/, '');
            const escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            const richText = escaped.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>');

            // 检查下一行是否是子列表
            let hasSublist = (i + 1 < lines.length && isListLine(lines[i + 1]) && getIndentLevel(lines[i + 1]) > baseIndent);

            html += '<li>' + richText;
            if (hasSublist) {
                // 递归处理子列表
                const subType = getListItemType(lines[i + 1].trim());
                const subResult = parseNestedList(lines, i + 1, subType);
                html += subResult.html;
                i = subResult.nextIdx;
                html += '</li>';
            } else {
                html += '</li>';
                i++;
            }
        } else {
            // 缩进大于当前层级，跳过（由递归处理）
            break;
        }
    }

    html += '</' + tag + '>';
    return { html: html, nextIdx: i };
}

function markdownToHtml(md) {
    if (!md || !md.trim()) return '';
    // 先按行处理，再按段落合并
    const lines = md.split('\n');
    let result = [];
    let i = 0;
    while (i < lines.length) {
        const line = lines[i];
        const trimmed = line.trim();
        // 空行
        if (!trimmed) { i++; continue; }
        // 标题
        if (/^#{1,5} /.test(trimmed)) {
            const level = trimmed.match(/^(#{1,5}) /)[1].length;
            const text = trimmed.replace(/^#{1,5} /, '');
            const escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            const richText = escaped.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>');
            result.push('<h' + level + '>' + richText + '</h' + level + '>');
            i++; continue;
        }
        // 引用
        if (/^> /.test(trimmed)) {
            const text = trimmed.replace(/^> /, '');
            const escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            result.push('<blockquote>' + escaped + '</blockquote>');
            i++; continue;
        }
        // 任务列表
        if (/^- \[ \] /.test(trimmed) || /^- \[x\] /.test(trimmed)) {
            const checked = /^- \[x\]/i.test(trimmed);
            const text = trimmed.replace(/^- \[.\] /, '');
            const escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            const style = checked ? 'display:flex;align-items:center;gap:6px;margin:4px 0;opacity:0.5;text-decoration:line-through' : 'display:flex;align-items:center;gap:6px;margin:4px 0';
            result.push('<div style="' + style + '"><input type="checkbox"' + (checked ? ' checked' : '') + '><span>' + escaped + '</span></div>');
            i++; continue;
        }
        // 无序列表（支持嵌套缩进）
        if (/^- /.test(trimmed)) {
            const listResult = parseNestedList(lines, i, 'ul');
            listResult.html = applyNestListStyles(listResult.html);
            result.push(listResult.html);
            i = listResult.nextIdx;
            continue;
        }
        // 有序列表（支持嵌套缩进，匹配 数字. 或 字母. 或 罗马数字.）
        if (/^\d+\. /.test(trimmed) || /^[a-zA-Z]\. /.test(trimmed) || /^[ivxIVX]+\. /.test(trimmed)) {
            const listResult = parseNestedList(lines, i, 'ol');
            listResult.html = applyNestListStyles(listResult.html);
            result.push(listResult.html);
            i = listResult.nextIdx;
            continue;
        }
        // 图片
        if (/^!\[/.test(trimmed)) {
            const match = trimmed.match(/^!\[(.*?)\]\((.*?)\)/);
            if (match) {
                result.push('<img src="' + match[2] + '" alt="' + match[1] + '" style="max-width:100%;border-radius:12px;margin:8px 0" loading="lazy">');
                i++; continue;
            }
        }
        // 分割线
        if (/^---$/.test(trimmed)) {
            result.push('<hr>');
            i++; continue;
        }
        // 普通段落（收集连续非空、非特殊行）
        let paraLines = [];
        while (i < lines.length && lines[i].trim() && !/^#{1,5} /.test(lines[i].trim()) && !/^> /.test(lines[i].trim()) && !/^- \[.\] /.test(lines[i].trim()) && !/^- /.test(lines[i].trim()) && !/^\d+\. /.test(lines[i].trim()) && !/^---$/.test(lines[i].trim()) && !/^!\[/.test(lines[i].trim())) {
            const escaped = lines[i].replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            const richText = escaped.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>').replace(/`([^`]+)`/g,'<code style="background:#f3f4f6;color:#ef4444;padding:2px 6px;border-radius:4px;font-size:13px">$1</code>');
            paraLines.push(richText);
            i++;
        }
        if (paraLines.length > 0) {
            result.push('<p>' + paraLines.join('<br>') + '</p>');
        }
    }
    return result.join('');
}

function renderDetailTypeList() {
    const container = document.getElementById('detailTypeList');
    if (!container) return;
    const theme = THEMES[currentTheme] || THEMES.blue;
    container.innerHTML = tags.filter(t => t.id !== 'all' && !t.system).map(tag => {
        const isSelected = tag.name === detailSelectedType;
        return `<button onclick="selectDetailType('${tag.name}')" class="detail-type-tag px-4 py-2 rounded-full text-[13px] whitespace-nowrap border border-transparent"
            data-type="${tag.name}"
            style="background: ${isSelected ? theme.primary : theme.primaryFaint}; color: ${isSelected ? '#fff' : theme.primaryDark}">
            ${tag.emoji || ''} ${tag.name}
        </button>`;
    }).join('');
}

function selectDetailType(type) { detailSelectedType = type; updateDetailTypeButtons(); const h = document.getElementById('detailTypeHint'); if (h) h.classList.add('hidden'); }
function updateDetailTypeButtons() {
    const theme = THEMES[currentTheme] || THEMES.blue;
    document.querySelectorAll('.detail-type-tag').forEach(btn => {
        if (btn.dataset.type === detailSelectedType) { btn.style.background = theme.primary; btn.style.color = '#fff'; }
        else { btn.style.background = theme.primaryFaint; btn.style.color = theme.primaryDark; }
    });
}
// saveDetail 已改为自动保存模式，保留函数供兼容性调用
function saveDetail() {
    autoSaveDetail();
    closeDetailModal();
    showToast('已保存');
    checkUncategorizedEmpty();
}
function deleteFromDetail() {
    if (!detailTargetId) return;
    const id = detailTargetId;
    // 删除按钮垃圾桶动画（主题色底+白色SVG，与批量删除一致）
    const btn = document.getElementById('detailDeleteBtn');
    const icon = document.getElementById('detailDeleteIcon');
    if (btn && icon) {
        const theme = THEMES[currentTheme] || THEMES.blue;
        icon.getAnimations().forEach(a => a.cancel());
        btn.style.background = theme.primary;
        btn.style.color = '#fff';
        icon.setAttribute('stroke', '#fff');
        icon.animate([
            { transform: 'rotate(0deg) scale(1) translateY(0)' },
            { transform: 'rotate(-15deg) scale(0.4) translateY(-4px)', offset: 0.2 },
            { transform: 'rotate(10deg) scale(0.7) translateY(2px)', offset: 0.45 },
            { transform: 'rotate(-5deg) scale(1.12) translateY(-1px)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1) translateY(0)' }
        ], { duration: 500, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
    closeDetailModal();
    deleteTargetId = id;
    const item = items.find(i => i.id === id);
    const nameEl = document.getElementById('deleteItemName');
    if (item && item.title) { nameEl.textContent = item.title; nameEl.classList.remove('hidden'); }
    else nameEl.classList.add('hidden');
    document.getElementById('deleteModalTitle').textContent = '删除此灵感？';
    document.getElementById('deleteModalDesc').textContent = '删除后可在回收站恢复';
    document.getElementById('deleteModal').classList.remove('hidden');
    // 垃圾桶特效（只动 SVG 图标，循环直到弹窗关闭）
    const iconSvg = document.getElementById('deleteIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-20deg) scale(0.3)', offset: 0.2 },
            { transform: 'rotate(15deg) scale(0.6)', offset: 0.45 },
            { transform: 'rotate(-8deg) scale(1.15)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1500, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
    // 恢复删除按钮样式
    setTimeout(() => {
        if (btn) { btn.style.background = ''; btn.style.color = ''; }
        if (icon) icon.setAttribute('stroke', 'currentColor');
    }, 600);
}

// ===== 置顶（pin/unpin）=====
function updatePinBtnState(isPinned) {
    const btn = document.getElementById('pinBtn');
    const icon = document.getElementById('pinBtnIcon');
    const text = document.getElementById('pinBtnText');
    if (!btn || !icon || !text) return;
    icon.getAnimations().forEach(a => a.cancel());
    if (isPinned) {
        text.textContent = '取消置顶';
        btn.style.background = 'var(--theme-primary-light, #DBEAFE)';
        btn.style.color = 'var(--theme-primary-dark, #2563EB)';
        // 已置顶：实心pin针，带旋转缩放动画（与FAB变形一致）
        icon.innerHTML = '<path d="M16 12V4H17V2H7V4H8V12L6 14V16H11.2V22H12.8V16H18V14L16 12Z"/>';
        icon.style.opacity = '1';
        icon.animate([
            { transform: 'rotate(45deg) scale(0.3)', opacity: 0 },
            { transform: 'rotate(-10deg) scale(1.15)', opacity: 1, offset: 0.5 },
            { transform: 'rotate(0deg) scale(1)', opacity: 1 }
        ], { duration: 500, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    } else {
        text.textContent = '置顶';
        btn.style.background = '';
        btn.style.color = '';
        // 未置顶：空心/浅色pin针，带旋转缩放动画
        icon.innerHTML = '<path d="M16 12V4H17V2H7V4H8V12L6 14V16H11.2V22H12.8V16H18V14L16 12Z"/>';
        icon.style.opacity = '0.4';
        icon.animate([
            { transform: 'rotate(0deg) scale(1)', opacity: 1 },
            { transform: 'rotate(20deg) scale(1.1)', opacity: 0.8, offset: 0.3 },
            { transform: 'rotate(45deg) scale(0.8)', opacity: 0.4 }
        ], { duration: 400, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}

function pinItem() {
    if (!detailTargetId) return;
    const item = items.find(i => i.id === detailTargetId);
    if (!item) return;
    item.pinned = !item.pinned;
    if (item.pinned) item.pinnedAt = Date.now();
    saveItems();
    updatePinBtnState(item.pinned);
    if (item.pinned) item._highlight = true;
    showFabCheckmark();
    renderFeed(true, item.pinned);
    showToast(item.pinned ? '已置顶' : '已取消置顶');
}

function unpinFromCard(id) {
    const item = items.find(i => i.id === id);
    if (!item || !item.pinned) return;
    item.pinned = false;
    saveItems();
    renderFeed(true);
    showToast('已取消置顶');
}

// 正常模式下点击 pin 针切换置顶
function togglePin(id) {
    const item = items.find(i => i.id === id);
    if (!item) return;
    item.pinned = !item.pinned;
    if (item.pinned) item.pinnedAt = Date.now();
    saveItems();

    if (item.pinned) item._highlight = true;
    showFabCheckmark();
    renderFeed(true, item.pinned);
    showToast(item.pinned ? '已置顶' : '已取消置顶');
}

function togglePinFromBatch(id) {
    const item = items.find(i => i.id === id);
    if (!item) return;
    const wasPinned = item.pinned;
    item.pinned = !item.pinned;
    if (item.pinned) item.pinnedAt = Date.now();
    saveItems();

    if (item.pinned) item._highlight = true;
    showFabCheckmark();
    renderFeed(true, item.pinned);
    showToast(item.pinned ? '已置顶' : '已取消置顶');
    // 更新 FAB 状态（加号 ↔ pin 针）
    updateFabState();
}

// FAB 短暂显示✅动画（与 toast 同步：300ms 出现，2s 后 300ms 消失）
let fabCheckTimer = null;
let fabCheckActive = false; // ✅动画进行中标志
function showFabCheckmark() {
    const fabMain = document.getElementById('fabMain');
    const fabMainIcon = document.getElementById('fabMainIcon');
    if (!fabMain || !fabMainIcon) return;
    const theme = THEMES[currentTheme] || THEMES.blue;
    // 防抖：取消上一次未完成的✅
    if (fabCheckTimer) { clearTimeout(fabCheckTimer); fabCheckTimer = null; }
    fabCheckActive = true;
    fabMainIcon.getAnimations().forEach(a => a.cancel());
    fabMainIcon.classList.remove('fab-icon-spin'); // 移除 spin，避免 CSS 动画覆盖
    fabMain.style.background = theme.primary;
    fabMain.style.boxShadow = `0 4px 20px ${theme.primary}55`;
    fabMainIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>';
    fabMainIcon.setAttribute('stroke', '#fff');
    fabMainIcon.setAttribute('fill', 'none');
    fabMainIcon.setAttribute('stroke-width', '2.5');
    fabMainIcon.style.color = '#fff';
    // ✅ 出现动画
    fabMainIcon.animate([
        { transform: 'scale(0) rotate(-45deg)', opacity: 0 },
        { transform: 'scale(1.2) rotate(0deg)', opacity: 1, offset: 0.5 },
        { transform: 'scale(1) rotate(0deg)', opacity: 1 }
    ], { duration: 300, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', fill: 'forwards' });
    // 2s 后恢复（与 toast 淡出同步）
    fabCheckTimer = setTimeout(() => {
        fabCheckTimer = null;
        fabMainIcon.animate([
            { transform: 'scale(1) rotate(0deg)', opacity: 1 },
            { transform: 'scale(0) rotate(45deg)', opacity: 0 }
        ], { duration: 300, easing: 'ease-in', fill: 'forwards' }).onfinish = () => {
            fabCheckActive = false;
            updateFabState();
        };
    }, 2000);
}

// FAB 短暂显示布局图标动画（与 showFabCheckmark 一致，但显示的是布局图标）
function showFabLayoutIcon() {
    const fabMain = document.getElementById('fabMain');
    const fabMainIcon = document.getElementById('fabMainIcon');
    if (!fabMain || !fabMainIcon) return;
    const theme = THEMES[currentTheme] || THEMES.blue;
    // 防抖：取消上一次未完成的动画
    if (fabCheckTimer) { clearTimeout(fabCheckTimer); fabCheckTimer = null; }
    fabCheckActive = true;
    fabMainIcon.getAnimations().forEach(a => a.cancel());
    fabMainIcon.classList.remove('fab-icon-spin');
    fabMain.style.background = theme.primary;
    fabMain.style.boxShadow = `0 4px 20px ${theme.primary}55`;
    // 根据当前布局显示对应图标
    const isMasonry = currentLayout === 'masonry';
    fabMainIcon.innerHTML = isMasonry
        ? '<path stroke-linecap="round" stroke-linejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>'
        : '<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>';
    fabMainIcon.setAttribute('stroke', '#fff');
    fabMainIcon.setAttribute('fill', 'none');
    fabMainIcon.setAttribute('stroke-width', '2');
    fabMainIcon.style.color = '#fff';
    // 图标出现动画
    fabMainIcon.animate([
        { transform: 'scale(0) rotate(-45deg)', opacity: 0 },
        { transform: 'scale(1.2) rotate(0deg)', opacity: 1, offset: 0.5 },
        { transform: 'scale(1) rotate(0deg)', opacity: 1 }
    ], { duration: 300, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', fill: 'forwards' });
    // 2s 后恢复
    fabCheckTimer = setTimeout(() => {
        fabCheckTimer = null;
        fabMainIcon.animate([
            { transform: 'scale(1) rotate(0deg)', opacity: 1 },
            { transform: 'scale(0) rotate(45deg)', opacity: 0 }
        ], { duration: 300, easing: 'ease-in', fill: 'forwards' }).onfinish = () => {
            fabCheckActive = false;
            updateFabState();
        };
    }, 2000);
}

// ===== 其他 =====
// ===== Banner 管理 =====
const bannerDismissed = [false, false];
let bannerTimer = null;
let currentBannerIndex = 0;

function closeBanner(index) {
    bannerDismissed[index] = true;
    const scroll = document.getElementById('bannerScroll');
    if (!scroll) return;
    const banners = scroll.children;
    if (banners[index]) {
        banners[index].style.display = 'none';
    }
    stopBannerAutoPlay();
    // 如果所有 banner 都关闭了，隐藏整个区域
    if (bannerDismissed.every(v => v)) {
        document.getElementById('welcomeCard').style.display = 'none';
    } else {
        updateBannerDots();
        // 重置索引
        currentBannerIndex = 0;
        startBannerAutoPlay();
    }
}

function getVisibleBanners() {
    const scroll = document.getElementById('bannerScroll');
    if (!scroll) return [];
    return Array.from(scroll.children).filter(b => b.style.display !== 'none');
}

function scrollToBanner(index) {
    const scroll = document.getElementById('bannerScroll');
    const visibleBanners = getVisibleBanners();
    if (!scroll || visibleBanners.length <= 1 || index >= visibleBanners.length) return;
    const bannerWidth = visibleBanners[0].offsetWidth + 12;
    scroll.scrollTo({ left: bannerWidth * index, behavior: 'smooth' });
    currentBannerIndex = index;
    stopBannerAutoPlay();
    startBannerAutoPlay();
}

function updateBannerDots() {
    const dotsContainer = document.getElementById('bannerDots');
    const visibleBanners = getVisibleBanners();
    if (!dotsContainer) return;
    dotsContainer.innerHTML = '';
    visibleBanners.forEach((_, i) => {
        const btn = document.createElement('button');
        btn.className = `h-1.5 rounded-full transition-all banner-dot cursor-pointer ${i === currentBannerIndex ? 'w-5' : 'w-1.5 bg-gray-300'}`;
        if (i === currentBannerIndex) btn.style.background = 'var(--theme-primary, #3B82F6)';
        btn.onclick = () => scrollToBanner(i);
        dotsContainer.appendChild(btn);
    });
    if (visibleBanners.length <= 1) dotsContainer.style.display = 'none';
    else dotsContainer.style.display = '';
}

function startBannerAutoPlay() {
    stopBannerAutoPlay();
    const visibleBanners = getVisibleBanners();
    if (visibleBanners.length <= 1) return;
    bannerTimer = setInterval(() => {
        const visibleBanners = getVisibleBanners();
        if (visibleBanners.length <= 1) { stopBannerAutoPlay(); return; }
        currentBannerIndex = (currentBannerIndex + 1) % visibleBanners.length;
        scrollToBanner(currentBannerIndex);
    }, 3000);
}

function stopBannerAutoPlay() {
    if (bannerTimer) { clearInterval(bannerTimer); bannerTimer = null; }
}

function initBannerScroll() {
    const scroll = document.getElementById('bannerScroll');
    if (!scroll) return;
    // 滚动时更新指示点和索引
    scroll.addEventListener('scroll', () => {
        const scrollLeft = scroll.scrollLeft;
        const visibleBanners = getVisibleBanners();
        const dots = document.querySelectorAll('.banner-dot');
        if (visibleBanners.length <= 1 || dots.length === 0) return;
        const bannerWidth = visibleBanners[0].offsetWidth + 12;
        const newIndex = Math.round(scrollLeft / bannerWidth);
        if (newIndex !== currentBannerIndex) {
            currentBannerIndex = newIndex;
        }
        dots.forEach((dot, i) => {
            if (i === currentBannerIndex) {
                dot.classList.add('w-5');
                dot.classList.remove('w-1.5', 'bg-gray-300');
                dot.style.background = 'var(--theme-primary, #3B82F6)';
            } else {
                dot.classList.remove('w-5');
                dot.classList.add('w-1.5', 'bg-gray-300');
                dot.style.background = '';
            }
        });
    });
    // 触摸时暂停自动轮播
    scroll.addEventListener('touchstart', () => stopBannerAutoPlay(), { passive: true });
    scroll.addEventListener('touchend', () => startBannerAutoPlay(), { passive: true });
    // 启动自动轮播
    startBannerAutoPlay();
}

function initBannerHoverPause() {
    const scroll = document.getElementById('bannerScroll');
    if (!scroll) return;
    scroll.addEventListener('mouseenter', () => stopBannerAutoPlay());
    scroll.addEventListener('mouseleave', () => startBannerAutoPlay());
}
// ===== 回收站 =====
const RECYCLE_BIN_KEY = 'gator_recycle_bin';
let recycleBin = [];

function loadRecycleBin() {
    try { const s = localStorage.getItem(RECYCLE_BIN_KEY); recycleBin = s ? JSON.parse(s) : []; } catch(e) { recycleBin = []; }
}
function saveRecycleBin() { localStorage.setItem(RECYCLE_BIN_KEY, JSON.stringify(recycleBin)); }

function moveToRecycleBin(item) {
    recycleBin.unshift({
        ...item,
        deletedAt: new Date().toISOString(),
        deletedFromNotebook: currentNotebookId
    });
    saveRecycleBin();
}

function restoreFromRecycleBin(index) {
    const entry = recycleBin[index];
    if (!entry) return;
    // 恢复到原始笔记簿（如果存在），否则当前笔记簿
    const targetNotebook = entry.deletedFromNotebook || currentNotebookId;
    const key = STORAGE_KEY + '_' + targetNotebook;
    let targetItems = [];
    try { const s = localStorage.getItem(key); targetItems = s ? JSON.parse(s) : []; } catch(e) { targetItems = []; }
    // 移除 deletedAt 和 deletedFromNotebook，标记为近期恢复
    const restored = { ...entry };
    delete restored.deletedAt;
    delete restored.deletedFromNotebook;
    restored._justRestored = true;
    targetItems.unshift(restored);
    localStorage.setItem(key, JSON.stringify(targetItems));
    // 如果恢复到当前笔记簿，刷新列表
    if (targetNotebook === currentNotebookId) { loadItems(); renderFeed(); }
    recycleBin.splice(index, 1);
    saveRecycleBin();
    renderRecycleBinList();
    showToast('已恢复');
}

function permanentDeleteFromRecycleBin(index) {
    if (!confirm('确定永久删除此灵感？')) return;
    recycleBin.splice(index, 1);
    saveRecycleBin();
    renderRecycleBinList();
    showToast('已永久删除');
}

function clearRecycleBin() {
    if (recycleBin.length === 0) { showToast('回收站已经是空的'); return; }
    document.getElementById('clearRecycleBinDesc').textContent = `确定清空回收站？共 ${recycleBin.length} 条内容将永久删除，无法恢复。`;
    document.getElementById('clearRecycleBinModal').classList.remove('hidden');
    // 垃圾桶特效（与删除确认框一致）
    const iconSvg = document.getElementById('clearRecycleBinIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-20deg) scale(0.3)', offset: 0.2 },
            { transform: 'rotate(15deg) scale(0.6)', offset: 0.45 },
            { transform: 'rotate(-8deg) scale(1.15)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1500, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}
function closeClearRecycleBinModal() {
    const iconSvg = document.getElementById('clearRecycleBinIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('clearRecycleBinModal').classList.add('hidden');
}
function confirmClearRecycleBin() {
    recycleBin = [];
    saveRecycleBin();
    closeClearRecycleBinModal();
    renderRecycleBinList();
    showToast('回收站已清空');
}

function restoreAllFromRecycleBin() {
    if (recycleBin.length === 0) { showToast('回收站是空的'); return; }
    document.getElementById('restoreAllDesc').textContent = `将恢复回收站中的全部 ${recycleBin.length} 条灵感`;
    document.getElementById('restoreAllModal').classList.remove('hidden');
    // 恢复图标旋转动画（反向转一圈，停顿，循环）
    const iconSvg = document.getElementById('restoreAllIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-180deg) scale(0.85)', offset: 0.3 },
            { transform: 'rotate(-360deg) scale(1)', offset: 0.6 },
            { transform: 'rotate(-360deg) scale(1)', offset: 0.8 },
            { transform: 'rotate(-360deg) scale(1)' }
        ], { duration: 2000, iterations: Infinity, easing: 'cubic-bezier(0.77, 0, 0.175, 1)' });
    }
}
function closeRestoreAllModal() {
    const iconSvg = document.getElementById('restoreAllIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('restoreAllModal').classList.add('hidden');
}
function confirmRestoreAll() {
    recycleBin.forEach(entry => {
        const targetNotebook = entry.deletedFromNotebook || currentNotebookId;
        const key = STORAGE_KEY + '_' + targetNotebook;
        let targetItems = [];
        try { const s = localStorage.getItem(key); targetItems = s ? JSON.parse(s) : []; } catch(e) { targetItems = []; }
        const restored = { ...entry };
        delete restored.deletedAt;
        delete restored.deletedFromNotebook;
        targetItems.unshift(restored);
        localStorage.setItem(key, JSON.stringify(targetItems));
    });
    const restoredCount = recycleBin.length;
    recycleBin = [];
    saveRecycleBin();
    closeRestoreAllModal();
    loadItems();
    renderFeed();
    renderTabBar();
    renderRecycleBinList();
    showToast(`已恢复 ${restoredCount} 条灵感`);
}

function renderRecycleBinList() {
    const list = document.getElementById('recycleBinList');
    const empty = document.getElementById('recycleBinEmpty');
    if (!list || !empty) return;

    if (recycleBin.length === 0) {
        list.innerHTML = '';
        list.classList.add('hidden');
        empty.classList.remove('hidden');
        return;
    }
    empty.classList.add('hidden');
    list.classList.remove('hidden');

    list.innerHTML = recycleBin.map((entry, index) => {
        const tag = tags.find(t => t.name === entry.type);
        const tagEmoji = tag ? tag.emoji : '';
        const editTime = formatTime(entry.updatedAt || entry.createdAt);
        return `<div class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
            <div class="flex-1 min-w-0">
                <p class="text-[14px] font-medium text-gray-900 truncate">${escapeHtml(entry.title || '新记录')}</p>
                <div class="flex items-center gap-2 mt-1">
                    <span class="text-[11px] px-2 py-0.5 rounded-full bg-gray-200 text-gray-600">${tagEmoji} ${entry.type || '未分类'}</span>
                    <span class="text-[11px] text-gray-400">编辑于 ${editTime}</span>
                </div>
            </div>
            <button onclick="restoreFromRecycleBin(${index})" class="w-8 h-8 rounded-lg hover:bg-blue-50 flex items-center justify-center text-gray-400 hover:text-blue-500 transition btn-press flex-shrink-0" title="恢复">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            </button>
            <button onclick="permanentDeleteFromRecycleBin(${index})" class="w-8 h-8 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-400 hover:text-red-500 transition btn-press flex-shrink-0" title="永久删除">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
        </div>`;
    }).join('');
}

function openRecycleBin() {
    closeGearMenu();
    loadRecycleBin();
    renderRecycleBinList();
    document.getElementById('recycleBinModal').classList.remove('hidden');
}
function closeRecycleBin() { document.getElementById('recycleBinModal').classList.add('hidden'); showFabCheckmark(); }

// ===== 齿轮菜单 =====
function showSettings() {
    document.getElementById('gearMenuModal').classList.remove('hidden');
    updateTagCountSwitchUI();
}
function closeGearMenu() { document.getElementById('gearMenuModal').classList.add('hidden'); showFabCheckmark(); }

// ===== 显示分类数量 =====
function toggleShowTagCount() {
    showTagCount = !showTagCount;
    localStorage.setItem('gator_show_tag_count', showTagCount);
    updateTagCountSwitchUI();
    renderTabBar();
    showToast(showTagCount ? '已开启分类数量显示' : '已关闭分类数量显示');
    // 切换后"取消"变"完成"
    const cancelBtn = document.querySelector('#gearMenuModal button[onclick="closeGearMenu()"].bg-gray-100') ||
        document.querySelector('#gearMenuModal button.btn-press.bg-gray-100');
    // 通过文本查找取消按钮
    const btns = document.querySelectorAll('#gearMenuModal button');
    btns.forEach(btn => {
        if (btn.textContent.trim() === '取消') btn.textContent = '完成';
    });
}

function updateTagCountSwitchUI() {
    const sw = document.getElementById('showTagCountSwitch');
    const dot = document.getElementById('showTagCountDot');
    if (!sw || !dot) return;
    if (showTagCount) {
        sw.style.background = 'var(--theme-primary, #3B82F6)';
        dot.style.transform = 'translateX(20px)';
    } else {
        sw.style.background = '#e5e7eb';
        dot.style.transform = 'translateX(0)';
    }
}

function toggleImagePreviewMode() {
    imagePreviewMode = !imagePreviewMode;
    localStorage.setItem('gator_image_preview_mode', imagePreviewMode);
    updateImagePreviewSwitchUI();
    renderFeed();
    showToast(imagePreviewMode ? '已开启带图预览模式' : '已关闭带图预览模式');
    // 切换后"取消"变"完成"
    const btns = document.querySelectorAll('#gearMenuModal button');
    btns.forEach(btn => {
        if (btn.textContent.trim() === '取消') btn.textContent = '完成';
    });
}

function updateImagePreviewSwitchUI() {
    const sw = document.getElementById('imagePreviewSwitch');
    const dot = document.getElementById('imagePreviewDot');
    if (!sw || !dot) return;
    if (imagePreviewMode) {
        sw.style.background = 'var(--theme-primary, #3B82F6)';
        dot.style.transform = 'translateX(20px)';
    } else {
        sw.style.background = '#e5e7eb';
        dot.style.transform = 'translateX(0)';
    }
}

function updateItemCount(count) {
    const el = document.getElementById('itemTotalCount');
    if (el) el.textContent = count !== undefined ? count : items.length;
}

// ===== 灵感管理 =====
function openInspirationManage() {
    closeGearMenu();
    document.getElementById('inspirationManageModal').classList.remove('hidden');
    updateTimeSortBtn();
}
function closeInspirationManage() {
    document.getElementById('inspirationManageModal').classList.add('hidden');
    exitBatchDeleteMode();
    if (batchPinMode) exitBatchPinMode();
}

function clearAllItems() {
    if (items.length === 0) { showToast('当前没有灵感'); return; }
    document.getElementById('clearAllTitle').textContent = `确认清空全部 ${items.length} 条灵感？`;
    document.getElementById('clearAllDesc').innerHTML = `删除后将放入回收站<br>可恢复`;
    document.getElementById('clearAllModal').classList.remove('hidden');
    // 垃圾桶特效（与回收站清空一致）
    const iconSvg = document.getElementById('clearAllIcon');
    if (iconSvg) {
        iconSvg.getAnimations().forEach(a => a.cancel());
        iconSvg.animate([
            { transform: 'rotate(0deg) scale(1)' },
            { transform: 'rotate(-20deg) scale(0.3)', offset: 0.2 },
            { transform: 'rotate(15deg) scale(0.6)', offset: 0.45 },
            { transform: 'rotate(-8deg) scale(1.15)', offset: 0.7 },
            { transform: 'rotate(0deg) scale(1)' }
        ], { duration: 1500, iterations: Infinity, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
    }
}
function closeClearAllModal() {
    const iconSvg = document.getElementById('clearAllIcon');
    if (iconSvg) iconSvg.getAnimations().forEach(a => a.cancel());
    document.getElementById('clearAllModal').classList.add('hidden');
}
function confirmClearAll() {
    items.forEach(item => moveToRecycleBin(item));
    items = [];
    saveItems();
    closeClearAllModal();
    closeInspirationManage();
    renderFeed();
    renderTabBar();
    showToast('已清空全部灵感');
}

// ===== 批量删除 =====
let batchDeleteMode = false;
let batchSelectedIds = new Set();

// ===== 批量置顶 =====
let batchPinMode = false;

function startBatchPin() {
    batchPinMode = true;
    document.getElementById('inspirationManageModal').classList.add('hidden');
    document.getElementById('tagGearMenuModal').classList.add('hidden');
    document.getElementById('tagGearIcon').classList.remove('spin');
    renderFeed();
    showToast('点按 pin 针即可置顶/取消置顶');
    // FAB 动效延迟 0.5s
    setTimeout(() => updateFabState(), 500);
}

function exitBatchPinMode() {
    batchPinMode = false;
    const fabMainIcon = document.getElementById('fabMainIcon');
    const fabMain = document.getElementById('fabMain');
    if (fabMainIcon && fabMain) {
        fabMainIcon.getAnimations().forEach(a => a.cancel());
        // pin 针 → 加号 反向变形动画
        const anim = fabMainIcon.animate([
            { transform: 'rotate(0deg) scale(1) translateY(0)' },
            { transform: 'rotate(90deg) scale(0.4) translateY(-6px)', offset: 0.25 },
            { transform: 'rotate(180deg) scale(0.7) translateY(3px)', offset: 0.5 },
            { transform: 'rotate(350deg) scale(1.1) translateY(-1px)', offset: 0.75 },
            { transform: 'rotate(360deg) scale(1) translateY(0)' }
        ], { duration: 500, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
        fabMainIcon.classList.remove('fab-pin-morph', 'fab-pin-idle');
        anim.onfinish = () => { updateFabState(); renderFeed(); };
    } else {
        updateFabState();
        renderFeed();
    }
}

function startBatchDelete() {
    batchDeleteMode = true;
    batchSelectedIds = new Set();
    // 直接隐藏弹窗，不调用 closeInspirationManage（它会重置 batchDeleteMode）
    document.getElementById('inspirationManageModal').classList.add('hidden');
    document.getElementById('tagGearMenuModal').classList.add('hidden');
    document.getElementById('tagGearIcon').classList.remove('spin');
    updateBatchDeleteBar();
    renderFeed();
    // FAB 动效延迟 0.5s
    setTimeout(() => updateFabState(), 500);
}

function exitBatchDeleteMode() {
    batchDeleteMode = false;
    batchSelectedIds = new Set();
    const fabMainIcon = document.getElementById('fabMainIcon');
    const fabMain = document.getElementById('fabMain');
    if (fabMainIcon && fabMain) {
        fabMainIcon.getAnimations().forEach(a => a.cancel());
        // 垃圾桶 → 加号 反向变形动画
        const anim = fabMainIcon.animate([
            { transform: 'rotate(0deg) scale(1) translateY(0)' },
            { transform: 'rotate(15deg) scale(0.4) translateY(-6px)', offset: 0.25 },
            { transform: 'rotate(-10deg) scale(0.7) translateY(3px)', offset: 0.5 },
            { transform: 'rotate(5deg) scale(1.1) translateY(-1px)', offset: 0.75 },
            { transform: 'rotate(0deg) scale(1) translateY(0)' }
        ], { duration: 500, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
        fabMainIcon.classList.remove('fab-trash-morph', 'fab-trash-idle');
        anim.onfinish = () => {
            updateFabState();
            document.getElementById('batchSelectAllBar').classList.add('hidden');
            renderFeed();
        };
    } else {
        updateFabState();
        document.getElementById('batchSelectAllBar').classList.add('hidden');
        renderFeed();
    }
}

function selectAllItems() {
    const selectAllBtn = document.getElementById('selectAllBtn');
    if (batchSelectedIds.size === items.length && items.length > 0) {
        batchSelectedIds = new Set();
        selectAllBtn.textContent = '全选';
    } else {
        items.forEach(item => batchSelectedIds.add(item.id));
        selectAllBtn.textContent = '取消全选';
    }
    updateBatchDeleteBar();
    updateFabState();
    // 直接更新所有复选框 DOM，不重新渲染
    document.querySelectorAll('.batch-checkbox-circle').forEach(checkbox => {
        const wrapper = checkbox.closest('.card-wrapper');
        const id = wrapper ? wrapper.dataset.id : null;
        if (!id) return;
        if (batchSelectedIds.has(id)) {
            checkbox.classList.add('batch-checked');
            checkbox.classList.remove('border-gray-300', 'bg-white/80');
            checkbox.style.background = 'var(--theme-primary, #3B82F6)';
            checkbox.style.borderColor = 'var(--theme-primary, #3B82F6)';
            checkbox.innerHTML = '<svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';
        } else {
            checkbox.classList.remove('batch-checked');
            checkbox.classList.add('border-gray-300', 'bg-white/80');
            checkbox.style.background = '';
            checkbox.style.borderColor = '';
            checkbox.innerHTML = '';
        }
    });
}

function toggleBatchSelect(id) {
    if (batchSelectedIds.has(id)) batchSelectedIds.delete(id);
    else batchSelectedIds.add(id);
    updateBatchDeleteBar();
    updateFabState();
    // 直接更新对应卡片的复选框样式，不重新渲染整个列表
    const wrapper = document.querySelector(`.card-wrapper[data-id="${id}"]`);
    if (wrapper) {
        const checkbox = wrapper.querySelector('.batch-checkbox-circle');
        if (checkbox) {
            if (batchSelectedIds.has(id)) {
                checkbox.classList.add('batch-checked');
                checkbox.classList.remove('border-gray-300', 'bg-white/80');
                checkbox.style.background = 'var(--theme-primary, #3B82F6)';
                checkbox.style.borderColor = 'var(--theme-primary, #3B82F6)';
                checkbox.innerHTML = '<svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';
            } else {
                checkbox.classList.remove('batch-checked');
                checkbox.classList.add('border-gray-300', 'bg-white/80');
                checkbox.style.background = '';
                checkbox.style.borderColor = '';
                checkbox.innerHTML = '';
            }
        }
    }
}

function onFabMainClick() {
    if (batchPinMode) {
        exitBatchPinMode();
    } else if (batchDeleteMode && batchSelectedIds.size > 0) {
        confirmBatchDelete();
    } else if (batchDeleteMode) {
        exitBatchDeleteMode();
    } else {
        openInputModal();
    }
}

let fabState = 'normal'; // 'normal' | 'x' | 'trash' | 'check'
let fabMorphTimer = null;

function updateFabState() {
    const fabMain = document.getElementById('fabMain');
    const fabMainIcon = document.getElementById('fabMainIcon');
    const fabSmall = document.getElementById('fabSmall');
    const fabGear = document.getElementById('fabGear');
    if (!fabMain || !fabMainIcon) return;
    const theme = THEMES[currentTheme] || THEMES.blue;

    // 计算目标状态
    let newState = 'normal';
    if (batchDeleteMode) {
        newState = batchSelectedIds.size > 0 ? 'trash' : 'x';
    } else if (batchPinMode) {
        const hasPinned = items.some(i => i.pinned);
        newState = hasPinned ? 'pin' : 'check';
    }

    // 清除之前的定时器
    if (fabMorphTimer) { clearTimeout(fabMorphTimer); fabMorphTimer = null; }

    if (batchDeleteMode || batchPinMode) {
        // 隐藏两侧小按钮
        if (fabSmall) fabSmall.style.opacity = '0';
        if (fabSmall) fabSmall.style.pointerEvents = 'none';
        if (fabGear) fabGear.style.opacity = '0';
        if (fabGear) fabGear.style.pointerEvents = 'none';
        fabMain.classList.remove('fab-pulse');

        // 清除之前的定时器
        if (fabMorphTimer) { clearTimeout(fabMorphTimer); fabMorphTimer = null; }

        if (batchPinMode && newState === 'pin') {
            // 批量置顶且有已置顶卡片：加号 → pin 针变形动画
            fabMain.style.background = theme.primary;
            fabMain.style.boxShadow = `0 4px 20px ${theme.primary}55`;
            fabMainIcon.innerHTML = '<path d="M16 12V4H17V2H7V4H8V12L6 14V16H11.2V22H12.8V16H18V14L16 12Z"/>';
            fabMainIcon.style.color = '#fff';
            fabMainIcon.setAttribute('fill', 'currentColor');
            fabMainIcon.setAttribute('stroke', 'none');
            fabMainIcon.getAnimations().forEach(a => a.cancel());
            const pinMorphAnim = fabMainIcon.animate([
                { transform: 'rotate(0deg) scale(1) translateY(0)' },
                { transform: 'rotate(-90deg) scale(0.3) translateY(-8px)', offset: 0.25 },
                { transform: 'rotate(180deg) scale(0.6) translateY(4px)', offset: 0.5 },
                { transform: 'rotate(350deg) scale(1.15) translateY(-2px)', offset: 0.75 },
                { transform: 'rotate(360deg) scale(1) translateY(0)' }
            ], { duration: 700, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', fill: 'forwards' });
            pinMorphAnim.onfinish = () => {
                fabMainIcon.animate([
                    { transform: 'translateY(0) rotate(0deg)', filter: 'drop-shadow(0 0 0px transparent)' },
                    { transform: 'translateY(-3px) rotate(-5deg)', filter: 'drop-shadow(0 2px 6px ' + theme.primary + '80)', offset: 0.3 },
                    { transform: 'translateY(-1px) rotate(3deg)', filter: 'drop-shadow(0 4px 12px ' + theme.primary + 'B3)', offset: 0.6 },
                    { transform: 'translateY(0) rotate(0deg)', filter: 'drop-shadow(0 0 0px transparent)' }
                ], { duration: 2500, iterations: Infinity, easing: 'ease-in-out' });
            };
        } else if (batchPinMode) {
            // 批量置顶无已置顶卡片：加号 + 呼吸动画
            fabMain.style.background = theme.primary;
            fabMain.style.boxShadow = `0 4px 20px ${theme.primary}55`;
            fabMainIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>';
            fabMainIcon.style.color = '#fff';
            fabMainIcon.setAttribute('stroke', 'currentColor');
            fabMainIcon.setAttribute('fill', 'none');
            fabMainIcon.getAnimations().forEach(a => a.cancel());
            fabMainIcon.animate([
                { transform: 'translateY(0) rotate(0deg)', filter: 'drop-shadow(0 0 0px transparent)' },
                { transform: 'translateY(-3px) rotate(-5deg)', filter: 'drop-shadow(0 2px 6px ' + theme.primary + '80)', offset: 0.3 },
                { transform: 'translateY(-1px) rotate(3deg)', filter: 'drop-shadow(0 4px 12px ' + theme.primary + 'B3)', offset: 0.6 },
                { transform: 'translateY(0) rotate(0deg)', filter: 'drop-shadow(0 0 0px transparent)' }
            ], { duration: 2500, iterations: Infinity, easing: 'ease-in-out' });
        } else if (batchDeleteMode && newState === 'trash') {
            // 批量删除已选项目：垃圾桶
            fabMain.style.background = theme.primary;
            fabMain.style.boxShadow = `0 4px 16px ${theme.primary}66`;
            fabMainIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>';
            fabMainIcon.style.color = '#fff';
            fabMainIcon.setAttribute('stroke', 'currentColor');
            fabMainIcon.setAttribute('fill', 'none');
            fabMainIcon.getAnimations().forEach(a => a.cancel());
            fabMainIcon.animate([
                { transform: 'rotate(0deg) scale(1) translateY(0)' },
                { transform: 'rotate(-15deg) scale(0.4) translateY(-6px)', offset: 0.2 },
                { transform: 'rotate(10deg) scale(0.7) translateY(3px)', offset: 0.45 },
                { transform: 'rotate(-5deg) scale(1.12) translateY(-2px)', offset: 0.7 },
                { transform: 'rotate(0deg) scale(1) translateY(0)' }
            ], { duration: 700, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
        } else if (batchDeleteMode) {
            // 批量删除模式：垃圾桶 + 摇晃呼吸
            fabMain.style.background = theme.primary;
            fabMain.style.boxShadow = `0 4px 20px ${theme.primary}55`;
            fabMainIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>';
            fabMainIcon.style.color = '#fff';
            fabMainIcon.setAttribute('stroke', 'currentColor');
            fabMainIcon.setAttribute('fill', 'none');
            fabMainIcon.getAnimations().forEach(a => a.cancel());
            const trashMorphAnim = fabMainIcon.animate([
                { transform: 'rotate(0deg) scale(1) translateY(0)' },
                { transform: 'rotate(-15deg) scale(0.4) translateY(-6px)', offset: 0.2 },
                { transform: 'rotate(10deg) scale(0.7) translateY(3px)', offset: 0.45 },
                { transform: 'rotate(-5deg) scale(1.12) translateY(-2px)', offset: 0.7 },
                { transform: 'rotate(0deg) scale(1) translateY(0)' }
            ], { duration: 700, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });
            trashMorphAnim.onfinish = () => {
                fabMainIcon.animate([
                    { transform: 'rotate(0deg) translateY(0)', filter: 'drop-shadow(0 0 0px transparent)' },
                    { transform: 'rotate(-4deg) translateY(-2px)', filter: 'drop-shadow(0 2px 6px ' + theme.primary + '66)', offset: 0.25 },
                    { transform: 'rotate(4deg) translateY(-3px)', filter: 'drop-shadow(0 4px 10px ' + theme.primary + '99)', offset: 0.5 },
                    { transform: 'rotate(-2deg) translateY(-1px)', filter: 'drop-shadow(0 2px 4px ' + theme.primary + '4D)', offset: 0.75 },
                    { transform: 'rotate(0deg) translateY(0)', filter: 'drop-shadow(0 0 0px transparent)' }
                ], { duration: 2500, iterations: Infinity, easing: 'ease-in-out' });
            };
        }
    } else {
        // 恢复正常
        fabMain.classList.add('fab-pulse');
        fabMainIcon.getAnimations().forEach(a => a.cancel());
        if (fabSmall) { fabSmall.style.opacity = ''; fabSmall.style.pointerEvents = ''; }
        if (fabGear) { fabGear.style.opacity = ''; fabGear.style.pointerEvents = ''; }
        fabMain.style.background = theme.primary;
        fabMain.style.boxShadow = '';
        fabMainIcon.style.color = '';
        fabMainIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>';
        fabMainIcon.setAttribute('stroke', 'currentColor');
        fabMainIcon.setAttribute('fill', 'none');
        fabMainIcon.classList.remove('fab-icon-spin');
        if (!fabCheckActive) {
            void fabMainIcon.offsetWidth;
            fabMainIcon.classList.add('fab-icon-spin');
        }
    }

    // 更新状态记录
    fabState = newState;
}

function updateBatchDeleteBar() {
    const topBar = document.getElementById('batchSelectAllBar');
    if (!topBar) return;
    // 全选栏显示/隐藏
    topBar.classList.remove('hidden');
    document.getElementById('batchSelectInfo').textContent = `已选择 ${batchSelectedIds.size} 项`;
    // 更新全选按钮文字
    const selectAllBtn = document.getElementById('selectAllBtn');
    if (batchSelectedIds.size === items.length && items.length > 0) {
        selectAllBtn.textContent = '取消全选';
    } else {
        selectAllBtn.textContent = '全选';
    }
}

function showBatchDeleteConfirm() {
    if (batchSelectedIds.size === 0) { showToast('请先选择要删除的灵感'); return; }
    document.getElementById('batchDeleteDesc').textContent = `确定删除选中的 ${batchSelectedIds.size} 条灵感？删除后将无法恢复。`;
    document.getElementById('batchDeleteModal').classList.remove('hidden');
}
function closeBatchDeleteModal() { document.getElementById('batchDeleteModal').classList.add('hidden'); }

function confirmBatchDelete() {
    const count = batchSelectedIds.size;
    if (count === 0) { showToast('请先选择要删除的灵感'); return; }
    // 移入回收站
    batchSelectedIds.forEach(id => {
        const item = items.find(i => i.id === id);
        if (item) moveToRecycleBin(item);
    });
    items = items.filter(i => !batchSelectedIds.has(i.id));
    saveItems();
    // 先退出批量模式（跳过变形动画，直接恢复加号）
    batchDeleteMode = false;
    batchSelectedIds = new Set();
    document.getElementById('batchSelectAllBar').classList.add('hidden');
    updateFabState();
    renderFeed();
    // 再显示✅
    showFabCheckmark();
    showToast(`已删除 ${count} 项灵感 可在回收站恢复`);
    checkUncategorizedEmpty();
}

function addDemoData() {
    const now = Date.now();
    const day = 24 * 3600000;
    const startDate = new Date('2026-01-01').getTime();
    const totalDays = Math.floor((now - startDate) / day);

    // 确保 8 个分类存在
    const newCategories = [
        { name: '认知', emoji: '🧠' },
        { name: '收藏', emoji: '⭐' },
        { name: '效率', emoji: '⚡' },
        { name: '待办事项', emoji: '✅' },
        { name: '个人计划', emoji: '📋' },
        { name: '阅读', emoji: '📖' },
        { name: '灵感', emoji: '💡' },
        { name: '健康', emoji: '💪' }
    ];
    newCategories.forEach(cat => {
        if (!tags.find(t => t.name === cat.name)) {
            tags.push({ id: 'tag_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6), name: cat.name, emoji: cat.emoji, editable: true, deletable: true });
        }
    });
    saveTags();

    // 添加示例笔记簿
    if (!notebooks.find(n => n.name === '工作备忘')) {
        notebooks.push({ id: 'nb_work_' + Date.now(), name: '工作备忘', createdAt: new Date().toISOString() });
    }
    if (!notebooks.find(n => n.name === '生活随笔')) {
        notebooks.push({ id: 'nb_life_' + Date.now(), name: '生活随笔', createdAt: new Date().toISOString() });
    }
    saveNotebooks();

    const demoContents = [
        { title: '✅ 本周待办清单', content: '### 📌 紧急重要\n- [x] 完成项目需求评审\n- [x] 提交周报给团队负责人\n- [ ] 更新个人作品集\n- [ ] 预约年度体检\n\n### 📋 常规事项\n- [ ] 整理书架和桌面\n- [ ] 学习 Tailwind CSS 新特性\n- [ ] 回复 3 封待处理邮件\n- [ ] 准备周五分享会 PPT\n\n> 💡 **提示**：先完成紧急重要的事，再处理常规事项', type: '待办事项' },
        { title: '✅ 月末财务复盘清单', content: '### 📊 收支核对\n- [x] 核对信用卡账单\n- [x] 统计各分类支出\n- [ ] 检查订阅服务是否仍在使用\n- [ ] 更新下月预算\n\n### 💰 异项记录\n- [ ] 记录一笔意外收入或支出\n- [ ] 确认工资到账金额\n\n> 连续 3 个月餐饮支出超标，下月需要控制外卖频率', type: '待办事项' },
        { title: '✅ 旅行准备清单', content: '### 📄 证件与票务\n- [x] 确认护照有效期\n- [x] 预订机票和酒店\n- [ ] 打印行程单和保险单\n\n### 🔌 电子设备\n- [x] 充电器和数据线\n- [ ] 充电宝（满电）\n- [ ] 耳机和转接头\n\n### 👕 衣物与日用品\n- [ ] 根据天气预报准备衣物\n- [ ] 洗漱用品（旅行装）\n- [ ] 雨伞或防晒霜\n\n### 💊 药品\n- [ ] 感冒药和退烧药\n- [ ] 创可贴和肠胃药', type: '待办事项' },
        { title: '⚡ 会议效率提升技巧', content: '### 会前准备\n- **提前 24 小时**发送议程\n- 明确会议目标和预期产出\n- 参会者提前阅读相关材料\n\n### 会中执行\n- **站立会议控制在 15 分钟内**\n- 每人只说三件事：完成了什么、计划做什么、遇到什么阻碍\n- 指定专人记录行动项\n\n### 会后跟进\n- **24 小时内**发送会议纪要\n- 每个行动项明确负责人和截止日期\n- 取消没有明确目标的会议\n\n> 一场没有行动项的会议，本质上是一封可以写成邮件的通知。', type: '效率' },
        { title: '⚡ 番茄工作法的进阶用法', content: '### ⏱️ 按任务类型调整节奏\n\n- **深度工作**：50 分钟专注 + 10 分钟休息\n  - 适合：编码、写作、设计\n- **浅层事务**：15 分钟专注 + 5 分钟休息\n  - 适合：回邮件、整理文档、沟通协调\n- **创意发散**：25 分钟专注 + 5 分钟休息\n  - 适合：头脑风暴、方案构思\n\n### 📝 关键原则\n- 每个番茄钟**只做一件事**\n- 中断时记录原因，持续优化环境\n- 每天目标：4-6 个深度番茄钟\n\n> 不是所有工作都值得用番茄钟。机械性任务直接做完，别拖延。', type: '效率' },
        { title: '⚡ 邮件处理的两分钟规则', content: '### 📬 处理流程\n\n1. 打开邮件后**立即判断**处理时间\n2. 能在 **2 分钟内**处理完 → **立刻处理**\n3. 需要更长时间 → 加入待办列表并**归档**\n4. 纯信息通知 → 阅读后**直接归档**\n\n### 🎯 每日习惯\n- [ ] 每天固定 3 个时间段检查邮件\n- [ ] 批量处理而非实时响应\n- [ ] 收件箱保持**零邮件**状态\n\n> 邮件在收件箱中堆积会造成心理负担。清空收件箱 = 清空大脑。', type: '效率' },
        { title: '⭐ 高效命令行工具合集', content: '### 🔍 搜索与查找\n\n- **fzf** — 模糊查找神器，配合任何命令使用\n- **ripgrep (rg)** — 极速文本搜索，替代 grep\n- **fd** — 更友好的 find 替代，语法简洁\n\n### 📄 文件查看\n\n- **bat** — 带**语法高亮**和行号的 cat\n- **exa / eza** — 现代化的 ls，支持图标和 Git 状态\n- **delta** — 更好的 diff 显示\n\n### ⚡ 效率提升\n\n- **zoxide** — 智能目录跳转，记住常用路径\n- **tmux** — 终端复用，一个窗口多个会话\n\n> 工具不在多，在于**熟练使用**。先掌握 3 个，再逐步扩展。', type: '收藏' },
        { title: '⭐ 值得收藏的设计资源站', content: '### 🎨 灵感与作品\n\n- **Dribbble** — 设计师作品展示平台\n- **Behance** — Adobe 旗下，完整项目展示\n- **Awwwards** — 优秀网页设计评选\n\n### 🇨🇳 国内推荐\n\n- **站酷 (ZCOOL)** — 国内最大的设计师社区\n- **UI 中国** — UI/UX 设计师聚集地\n\n### 🛠️ 工具与素材\n\n- **Figma Community** — 免费设计模板和组件库\n- **Unsplash / Pexels** — 高质量免费图片\n- **Google Fonts** — 开源字体库\n\n> 收藏不是目的，**定期回顾并实践**才是价值所在。每周花 30 分钟浏览即可。', type: '收藏' },
        { title: '⭐ 值得订阅的技术 Newsletter', content: '### 🌐 英文推荐\n\n- **JavaScript Weekly** — JS 生态每周精选\n- **Frontend Focus** — 前端开发热点\n- **Node Weekly** — Node.js 社区动态\n- **CSS-Tricks** — CSS 技巧和教程\n\n### 🇨🇳 中文推荐\n\n- **前端精读** — 深度解析前端文章\n- **前端大全** — 前端知识体系整理\n- **阮一峰的网络日志** — 技术与生活思考\n\n### 📅 阅读策略\n\n- 每周固定 **30 分钟**浏览\n- 只精读 **2-3 篇**，其余收藏备查\n- 用 Gator 记录关键笔记 ✨', type: '收藏' },
        { title: '📋 Q2 个人成长计划', content: '### 💻 技术\n- [ ] 掌握 TypeScript **高级类型**（Conditional Types, Template Literals）\n- [ ] 完成 3 个 LeetCode 周赛\n- [ ] 搭建个人技术博客\n\n### 🎨 设计\n- [ ] 系统学习**色彩理论**（配色、对比度、情感表达）\n- [ ] 临摹 5 个优秀 UI 作品\n\n### 💪 健康\n- [ ] 每周跑步 **3 次**，每次 5 公里\n- [ ] 体重控制在目标范围内\n\n### 📖 阅读\n- [ ] 每月读完 **2 本书**并做笔记\n- [x] Q2 书单：《深度工作》《原子习惯》《设计心理学》\n\n> 季度末复盘，调整下季度计划。', type: '个人计划' },
        { title: '📋 年度技能学习路线图', content: '### Q1：前端工程化\n- Webpack / Vite 构建原理\n- Monorepo 管理（Turborepo / Nx）\n- CI/CD 自动化部署\n\n### Q2：后端基础\n- Node.js + Express / Koa\n- 数据库设计（MySQL + Redis）\n- RESTful API 规范\n\n### Q3：移动端开发\n- Flutter / React Native 选型对比\n- 跨端状态管理方案\n- 性能优化与原生桥接\n\n### Q4：AI 应用开发\n- LLM API 集成（OpenAI / Claude）\n- Prompt Engineering 技巧\n- RAG 检索增强生成实践\n\n> 每季度输出 **1 个完整项目**作为学习成果。', type: '个人计划' },
        { title: '📖 《深度工作》读书笔记', content: '![](data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCADgAZADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDjHJExYE5zkGriyrcLno38QqqHUXKKx+Q9afJCYZNwOMEn8K5mDRZVD5EynGVU9arRWx2sN6AycEk5+n61PFcLJCTINpcbSR0OKaN2/kfl0pbGkIX3IU0eWRyHnVWzzwTirkegQRKGmmeU56D5atWZy21uSe5q/sIxkcGjnkaJQTsxsipFFGqdAtAIdAW5UrtIPqP/AK1Mu22kJ02ioYXoauiZJNkkOkWD5EsAIz8uCRgVbXQbAQSG2g2SBDtbcTzRA3StS1PSqTFZFjRrC0jtYZRaRJKUBJ285pdQb/S1Hooq5bLtUAelZ96wN+/PQAVoiCxCNyEeoxXDalaNY3zwOwPcEdwa7eGWNR8zgfjXNeLfLe5hmjIOVKnFKa0LpvUyYyMjBFXoHGe1ZsRHFaNqBkVzM60bVgpmlWMZAJ610qjaoHoMVg6SyJNuc4AHFbqyI4yrA1rS2uYV3rYdSGlpK1MBqjHXrRSmkNACGmmlNNJpDENMY041FIwUZpDGMajZqhluVHQ1We5J6VLZSRaZxULygd6qNLI3SoysretTzIrlZPJOPWmpJk1A0DgZNRq5SQCi4WNRTTwagibIqYGqJH0tMBpc0APzRmm5pc0AOzS0ylFAE9tzcJ/vCug7Vz9p/wAfMf1roe1XAiRXm6Vnt/rPwrQm6VQb/WGiQ0KfumtKxHC/Ss4/drTshwPpRHcTH3x+VBVXYCKsaiGITaKqxEniqZJXlBVsCp7eN0wxHFKIW88Mw4q+AuyseUaPDb9DHeOOx5FOuLwzxogXGAAx9ak1IKwR1YEjg4qgKu1xmgqZt4suoY5bBOOp/wDrVPEjxt8wIqnIceV/1zH9a0rYkxg/eWs5aIrmsTRHaRwSc8VtxoJITng9cCsuMLGQT6ZWtS0mVkGeMHFCsOeqTRj38o+0OM9DiobeUFiAaiunVrmVsZy5/nUQnVDzgUw8zcgfpWvZsMiuat7nOOM/Q1s2U+SODQhs6eDG3NclrN2w1WdV6BsfpXTQTBY8kgfU1gXdsk11JKdo3En61cnoTFamctzIep4qvqciyWvJ5U5rVFpFjufoKhnskddvlEioujSzOdjfnrWnZvyKtx6LGx4gNX4dIMYGNqfU1DszWLaJLVgseW4zVlZlU5DkH2oS0WMfPIPwFSCOIfdXP1pJ2Jaux8eoMvGSw96tR30bffBWqgXjhVH1o8tnYfITg9hVKb6EumupqBgy7lOQaQ0yFSkQUjBpxrdGD3ENNNKaYTSARjWbqMpVCAavsaytQOQamRUSG0XzThjV0W8Y6is+wbDitY4NRFFyZCUQdAKacdhUjECoXlQd6ZIyTlTWTN8rg+9arEMDisu7GCallIvW7ZUVZU1n2j5UVdDgdSBVEkuaXNRhwehBpS4A5OKYD80uahE0ZOA4zT80gH5pwNRg04UAW7Hm6j+tdAelYGn/APH2lb56VpDYiW5Xm6VQ/wCWhq/N0qj/ABmlIaHH7talmOPwrMI+X8a1LUcVURMluMZGapoVExFP1FiJEwe1UhndnNTLck0m27c1UkuCrbc0u8lcZqu0RdiaGh3PG5WJXavOavR6JdGASSskRIyFbrT9Lsw18kkgysZ3Y9TWtLOZL8q54HJpN6aA2YV0ACnlglUGw/UVPp10sT7JVYo3XjpTZbeQ3c7qT5cjk7afDYXTN8khYdsKaltWsaJXNSZtrQqqlgEzkDrzUyyTtEwjQIxGATwBUUVheeSqyswUHhsYxWjDpDD/AFkuf1qL20NIxVrMoNaJtXOHfHzFRwTTfsMbdUH41upYxDgsW/SrCW0K9I1/EZpcxTic9Hp0WfliGfYVegsHXlYyP0rYUKOn6U8eymjmbCyRUitpAOSP51ILZAcsf0qxtY+gpfKz1Jp2kxXiiHy4l6Ln6mj5R91V/AZqysKemamRAOgApqm3uJ1EtimEmfhUb8akWzlPUqtXlFOrRUl1IdVlNbAZy8hPsBUy20S/w5+tTUlVyRXQhzk+o0Ii9FA/Cg0ppppiEpppSaaTQAhNRsacTUbGkA1zxWVenOa0pDwayro5JqJFoq2jYl/GtrOUH0rAgbExrcibMQNStypbEEiEnlqhZVHvViRRu5NREIPeqJGqcrxVC8HWr2fQVTu+pqGUiOyfjFO1CNiodScd6qQy+X0Gasfbzgh4simRJp6EELSqco547ZrQWeKSPdOcY4NR6fHb3E/yvsz2NXNQ0z/iXsqLgu4y3oPWgyV0JEsDDMYU/SpUPH0pE0gaeyoku8OuQ3anFGjO1xg0uZPQ1Q4GnqafDFG3O4H15q4luhXhM/SlzBcTTebtK3TWZaWwjuFdcgdwa1D0rensRIrTdKpD75q5P0qmv3jSluUiTHA+ta1sOtZY6r9a1rccGqiSypqZ/fL9KpKeavX67pwPaq3l7aHuIVecCrKKNtVlHOamEmKAPNJIRYpkkHd6VUsUe4vFBJO45b6Vuarpks8EQg+dt2COnFW9M0iOzizJ88rfeI6D2FYa2Lcfe8iFIIh9yJfqakUFLhQMDzBjA9R0rTWJF6IPyqK5TbLDPn5Y2ww9j3qeRmzn2GiBmXaVyCMHNLApMeHddyEq2T3FW+AMnoOtRxwh7Yq4/wBZlj+NVyITmxIvKkzskD467T0qURqO1YssF3p8vmqdyZ+8O/1rZtJluYFlTjPUehoja9iOdvckApQKeBSgVpYLjQtOC04LTgKdiWxFWpAKAKUVSQhaWkopiCkopCaAAmmk0E00mkAhNNJoJphNAxGNRsacxqJjUjGSn5TWXcnrWhM3ymsy4PWpZaKKtiety1bMNc+5xMD71tWL5TFT1H0JpcZyTVd5EAqS5GQDVRsY61RI4SgtiqF2XnkKrwg6n1qwCN4xSzACPipY7XMtlUZ3MQBT7ZraVgqu+fSmTQmUkBgKLcw2jcHdJ6+lK5EkkzfjtltQHaIkEdSM0kmpXEBAaMSQN1UdhVaDVZDEIpAWXse9SSyhYiUXJPUVNwsizeam8lmihQY0Pykj5sUsN6jbFcbworM88rEsR5AOea19HuoreRQ8Y8s8E4qXG7uKxakis5YPkLYbqcYIqOEyWpCxzFh2JOa2JGguLYpbBAT3AqvNYxwWG8D95nk1rYFuT2F480mx1U8da0CeKyNMH7/PtWq5rWGwS3K054qqnLNU07VWRvn60nuNbFlD86A+tbFuPlrCYOWBXtVqG/mjADDIpp2E0aM0DM+8YPFVZY2HVTUkWpRt94Fai1bUhbaa8sDAuflX2z3puSSuTsRKyB/L3DfjO3POKGU9qreGrAvA99clmknPyknnb6/jWu9oP4W/OlG7V2Bw2l3rzObefmRRkN/e/wDr1qAVg3MbwX32iNSOQw4/MVvryAazRcWAFKyK6MjDKsMGqOqQ3jIJLSVht6oDjNQWFzf5LTqfLUc+YMflQ3Z2HcuwOZkEBOWQlZD7D/HiroFVrJcSXD7cF5M/oKtgVSQNiFAylWAIPBB71V02HykmAzs807fpV0ClCgcAUW1uIAKUClApQKqwgFKKBSimAopaSimIKM0lFMAzSE0hpCaQCE00mgmmE0gBjTGNBNRk0hiMajY0rNUTGkURTNxWbOauztxWdO1QykUZmw4PvWtp79PpWFcyc1p6bJlVNJlI1Zl3rjOKrmFR1OanYioXYCmSRlUXoKil5Q095FHeq8sy4IzSY0UZshuKrBMHJ5Y9KsO6mQc8VLFADJuapJmrsl0+zY4nk+VexNTXU4CsqFXbvirVzpj3tqscc7RgdAKy08N6lbSh4pUk55zxkVXKrE2dhY/3iBedy8j6VorcW6gbpQCB90+tOtdOuvN3SxFSBgYNQS+Fb69uDI7xxgnuecUJArrcv2N00UsckLhiTyPWuhbUIrq2MZXa2O9ZuieE47KZZp7p5mHRQMKKS42rfSqnADYFNxaQ1qy9p3Ep+lX5G4qhp5+Yn2qzKWI4BrSOxMtyvO9VUc+ZkdKkmjlboKqrFNGxPXNSykaCNxUoORWeszL94Gp0nU96LhYlaWESiNjhz7Gq8llJM7LPMzQk52jGKlacIAdjvn+6M0GRGwJGwB/C3Gazkr7isWYp5YVCxnCAfKAeMVZXUXIww/EVhi7N3KYrKRown8e3g+wq9H5gQeYFZu5HFXGTCxS8hXUqw60/oOeMUK2Qa5zxRfv5y2UTFVxukx3z0FNuw3pqbqXcEkvlQSJLJ12q3T61OIQ4PmncSMew+lcRokjJq9uVOBvC/hXeihakp3K2nhjah3+85LH86tYqGy/49Isf3asCqS0GApRRS0xBS0ClpgFFFFMQGiikoAM0hNFITQAZphNBNMJpABNMJoJpjGkMGNRs1BNRs1IYjNUTNSs1V5XwKljRXvJwgx3rJnld+gqe9JZs1AjetZt2NErlGWN261dsZhGoDHGKlAQ9RUgt427Ck5XKUbD5NRUcA5qrJfu33UJqz9kQdFFHk7e1K4WM8zXEh4GKjMUzfeetIxKe2KTyfQ0XCxnrFt65NWI3Kkc1MYj6Unl+1F2FkdHZNmFPpVsFs8VQ09v9HQe1aMeMVVybE0YwetWouKroKsR+tOLE0X4OhPtXIyybruVvVz/OuqdxFaSOT0UmuKSTc5Pqc1c2RFamvbyFehxWhFcnjcARWNDJV2N6lSaLcUzZiktZBhvlPvUjWMTjKMKyA1SJK6HKOR9DVKp3IdPsWZtNP938qoy2BB4q9HqUqcOA4/KrKX1tLxINp9xVXixcskYLRSx9M1n6hDLdKVBw6EEAnAPH867E20MwzGwI9uawTF5tw4iGQAeVHDc449azqRFe+jIrNnS2gSZSsnQj35qHVDcSCJYdwTPzBTgmrBs2S3Zg4EocHaT0wR61k6zM8RCq5YMMhh0I6cVlJtR1G9jWtuY/TNcb4gRl1mfd3wR9MV2KcAAVR1fRhqTRSrJsdflYkZytbtXQSV0YPhqzafUklx8kPzE+/au2FVrKzhsrdYYFwB1J6k+pqyKqMbIlGHdalPaN5MSBdpI+Yds9qm07WGlcR3SqpPRhx+Yq/LbQzu8c8auCAwz27GqjaJCrbomYY6A8/rWfLJO6GzWFLUNrKssAI6r8rA9QRU1arUQUtJRTAKKKSmIWm5ozSE0ABNITSE0wmgYE0wmhmqMtUjAmmM1BaomakArNUTNQzVC7Uhg74FU5pM06WSqkj1LKRFcHIqnI2EyKnnbiqkrfu6llxEW6K/e5q1Dco3RsGsp2qEvg8GjluPmsdRHMfrUyuprlor+WI8NkehrQg1aJsCQFTUuDQ1JM2sIaaY17Gq8UyyDKsCPapOvQ1BVhSuO9IXXuKQqwpjZ7imIv2F3GH8rcAe1bMLA45rh7h9koOGGOhHar1pqsyAAShh71XQFG52yHNWYx3rl7bV5OM7fzrWtr9HA3ygE/wipU0ivZtljX7nydLdEyXfj6CuQjd1PIrr7q1kuLc7YyQ3UnrWS+m7OCuKpzuTyJFOC4HfitCGYHHNU3sip4FNCPH0yKXMLlNhZKeHrIS4deozU6XanvimI0N1BbAJPaqqzg96cZMqR7Uhhfautjbia3jyD/AB9cH0PpWNL4glvAMtnaCo2Hb1q04KsSpIJ9DVRrW1aQu9tEWzncBtP5itG7qxk4syW1C7mdULtGinq3U+vWtC4uXvUhiKpiIbVZf+Wn4+tRto9g828fakY56SBh+oqQeHrOWVZBeXiY7BF/xqJQT0uTys6OPn6VYUjpVZSR1/Kp0FbFD6dSe9KKsgjLAXUa4OSjdvpU1RJ807N2UbR/M/0qWhCKlvA8OoXD5/dSgMB6GrlJ3zRQlYBaM0maTNMQuaTNJmkJoAUmmk0hNMLUAOJqMtSFqjZqQxWao2akZqkt7Wa5PyDCd2PSkMhyWYKoJJ6AVPJp1ysHm7cnug6gVt2Nrb2o+Vdznq561e2o3pRYLnCu2KrySV12p6HFdqZID5c36N9a468trm3nMM0TK49aljRWkkqs71bFnK/3jgU8aeg+8Sakox5n4qIo0iY5Fb32OIfwClMCAY2ikyk7HLvbuKiaE1072kbdsVUmsOpWi7DRnPmIimlK1ZbVl6iqzw47U1IOUqxvJEcxsV+hq/b6tKmBMu4eo61VaLFMKEU2k9xK6OhttRgmwA4B9Gq8u1hnFcdirMF7cwH5JDj0PIrN0uxoqnc6pYbaRws2FU9Wx0rWt/DOmzgOJA4/2a5G31iNuLhCp9R0rTt7wZ8y2nx/unms3zLctWex1UXhnTI/+WRJ92NaNvYW1sP3UCL7gVz1pr9zH8s22Ue/BrZtdatZ8Bn8tvRv8aE0JqRoj2OKa8SyDDgGnKyuAQQQe4pcelWZlOXTI2+4cVRn0x1/hyPUVt8/Wjd6iiyHdnKS2eD0waqSW7DtXZSpBIP3gWs+5tLbBKSjPp1pOJSkcs2+PkEinQXLGVVYHk4zWrLZFs4Un8KovZOrhlB4NK7CyEkOCSeBUbc8GnTcMVNQ7s1ZI4KM53GrMIx71XTmrUI9TSuOxajOW3GrEf3c1WQ8VPv2L/StjImU54pk0hjTKjLE4Ue9LECq/N948miReVbsDTRMkEKGOMKW3HufU1JmmZozV2IH5pM03dSFqAHZpCaZuppamBJuppamFqYXoAeWphamF6jZ/SkA9nojSWeQRwoXY9hTIxulUMjMueQpwTXV2S26QgWyBB3Hf8aVx2KFloiJh7sh2/uDoPr61oPbqB8vAHQCpzkDim0AUnjdeg4pqOyGr+M1G8KsOlACRzZ4NJeWcF9DslHI+6w6rUTRshqWKQjrRYDlL2xls5jHKMj+Fh0IqsUrtbu2jvbcxyD3U+hrk7i3e3maKQYZTUNFJlQpTTHVnbRspWKuUmjpjIR2q8UppjpWC5nPGG+8Kqy2at04rYaH2qFoT2pWGmc/NaMvaqrwkdq6R4vUVWltUbtg0irnPNF7UzYRWvNZsvQZqpJCQcEU+YLFEilUsh3IxB9RU7R0wpTuKxat9Vni4kAkHv1rUttVt5SAzGNvRulc+VpMVLhFlKckd5Z3UsQDQTED2ORWpFrc6jEkav7rwfyrzW3up7ZswysvsDxWva+IGGBdRBv9pOD+VZuElsWpxe538F8bo4jmRW/ung1Y+zSt9+Y/hXH22oWt1xHKpP8AdPBrRh1G6t+I5SV/uvyKSn3G4djoVsox94lvxqZYYl6IBXNnXrhuG+X3WmNfSTDPnM341aaIcWdQZIk+86D6mszWb63isJXh2PKBxx096xGkf3qhqEshgIUnmm2JLUqLf+aT5hw46g1KsoJrEkmGcTxke9PidT/qp2H45pXK5ex0EbZxV2EjAzisCKWSMZaVT+GKsxXUjn5TmixPPZ2N5TzmpI+X3HoOlQJyeTUqt0A4rYzLKnP4VMPmjYd+1VkNTp1oAh3UbqnvbcRxLPH908EehqiZAOprRMysTbqaWqBpcdjSh8ii6CzJS9MLU0P6gfhQcN0NK47Ckk0047mlwR60dfQ/Wi47AVGMkUmwHkUoOBgr+VG4Z4P50rjsWreWNPl27D6+tXY5WQhkbB9RWTu9ack7R/dPHpXPNK90zWPmdLbXay4Vvlf9DVgjNc3DdxyHGdre9a1re4wkx47N6fWqhV6SJnT6ou4op3UUldBiIVBGDUDptPHSrNIy7higCKJu1Z+u2oeFbhR8ycN9KvY2mnXASS1eNyAGXFJjRyW2nCMnopP4VuW9pBFjbGZG/vMKurvxwgFTYq5yxQjqCPwpVgkf7sbH6Cur2lvvKv4jNNe2R1wCU/3OKdhXObGnTkZKhR7nFQS23lttJBPsc10f9mKDkuZfZzUTwyRnEdmv+9waVh3Oe+ySMMrGxH0qvJb4OCpBrqhBdv8AekWMeiik/suFjulLOfUmlYdzjngFLbaJPqLEQxggdXbgD8a6e60NHBMDbT6Gp7AmxshBMu1gScjvS5e479jm28G28Yzc3zZ9Ik/qajbw1pQH37s++5R/StXVbuccrE+31UZrAl1Jw3JYfU1hOvGLskbwoTkr3JJPC1g4/d3Nyh/2grf4Vm3fhW7jBa1kjuQP4R8rfkev51ei1OUnCsx/WtnTxeXRGbdgn99htA/OiFZSdrBOjKCu2edPG0bFXUqynBBGCKZiu58ReHr3UdYZ7OAFRGivI7BQ7Y5PPXtXL6lpN3pkwivITGxGVPUMPYjrWz0MlZmeCRzVy31S7gwBIXX+6/NVShpuKTSe41dbG/batFOyo6FHJwO4Jq8cg8cVzFiP9Ng/3xXQXjkICCRz2rGcUnoaxm7XZdS5ZRhsEe9Oea3kGGG0+9ZSzk8Mc02Rsjg0K5lKouxoNaQy9ADTP7A8z5orck+oFVbG7kt5tyNgj8a6CPxSUTbcRg8feXj9KewKakjJh0KaWXZIwj+prbs/DVtGAZbmV/ZeKw7zX1Nz5kIJFXtO1Wa7YYG0e5pq7JTinoWMMgORxT4zlsdh1NVopyoxntVoPHxuXaT3Fb2FcsIe9TIagTDD5GDAVIrY69aQGjbsksTQNg5HQ1h3EM1u3l3KYPYjoa1bLiZfepdSjF1FtiwZFOR/WmmDRhcdiaXj86vR6VMTlsCp00cY+Z6BGVmgdcVuppcC/eyanSzt06Rr+NAHPCN2+6pP0qRLK5fpGw+tdEFjXoAKbJPHGpZ2VQPU0AYq6VcnrtH41Dc2qW3Ekw3f3QMmptQ1wAGO0693/wAKxWuDks5yx96iUkWk2Wt9NMyjqaovcOfuqv4mmeZMf4Iz+NYs0SNESRP0Zc1bgumjwrksv6isTMp6wIfo1SpLJH1SRR/30KlplI7LT70cIzZQ9D6VpkVxNneYb5SPdf8APSur025E8AGcle/qK2o1Pssyqw+0i1S0uKY744Xk10nORTD5uKjEYJyefrUm1icmlCmkUAXFOpBS0CFozSU8DFMBAfrRu5paa3HNIBk52Ddgn6VX+0E8LGxqV5VbgnCj9aYZ4lHB4FTcqw3dcP0CpVe7VlQb23E96uRXMDdHGfeoNXz9jMseDsOT9KbjoJS1MsnBPOKazt65+vNQrLvOc1Oi7hWaNLgkrj7rEfTircLM2NxJ+pqFIBmrcabFJxwBVohs5jxBezT3JhhkkjWMkNg4yf8ACm6p5tx4Ut1uiWmWUFGbrjn+mK6ma1iuWVpYE+XoWGTWHrNrM1wPNIMYH7vHTH+NS09yk0cPJCynkVCye1dNLZZzkVRm07+6cH6VnqaXRk2i4vIj6NmtO9kzGPrVZreSCQOy8DuKZNNvQVL1Za2IWmYNwaVLls4NV2JZuKs28BY9KppJGUmiYTd6jlkLdTU0iLGKrlS/So3OdkLPzXRaHKqxgngD1rIs7TfJlhmtjylijwDit4Q6krQs4KvmrUTrIdpPJqR1iPUYpghg3ZVyCaqxtclSJ4+R0qVLnHEoyPWiHCjG7cKeYkfNOwXLlndWyE7icnjNWx5bsrxFQAexrE+ycn5uKkjtnRtyyH6UrDubxnROGYE+go84tysb4+lVbM7YWdwMjrVpJM4boKQyE3Lt9yJz+lITdP0VV+pq02OvaqNzd3K5FvZyOfVhgUAOkjZULzz7VHXtXOaldCaXbEx8sdyetT3g1O6P76KXA6KF4qi9pOPvROPqpqWNGbc3fkPgxuw9QKjGq2+fmYqfetBreQdVI/Conts/eUH6ipcblJ2IF1KA/dbP40/+0h/DGW/4GBUcmm27/egQ/wDAarto8B+6rJ/usaXKh8zLo1STtZsfpKtSpqwH+ts7hR6gBv5VjvpEi/6q5kH1Oahaz1KI5jm3UciDnZ1MNxaXZ/duN47Y2sPwNbWi3PkXIWRwEIOSeK85+1arAwLbiAf7tF1rupfa0kRisadEH3W+tJU3e6B1FbU9Ru9eUErax7h/ebj9Kp/23d5ziP8A75rkzr9v5KOMBnH3XO3FIuszNyqREewJ/kaG5jUYnZxa9KP9bCjf7pIq/BrFpLw5aI/7Q4/OuDi1kEgSRp/wF8focVfivYJP4ih9GGP/AK1CnNCcIs7xHSRdyMrD1BzS49K46GZ4yGikKn1U1owa1cJgShZR+RrRVl1IdJ9DoQMUZqpZ38V5kIGVl5INWq0Uk9jNprcKgkbzDtU/L3PrSyMXOxOnc1Wvp2toAUHzE4z6VLdykrEvkxryw/Emsi/1dIy0cCLjoWPeqN1dTyZ3SMfbNZcwYnODUt9iku5qQXMcvAl2v6Gkupp4RgyllYdulYMobtmkXUL6DhXDr6OM0czE4ouR34ik2vkDsa2bO9hkA+dfzrnl1of8vGmo/uhxVmLWtPB50yQH6A/1oTE0ddC8TYw6/nV9Y1CCuSg8SInFvp7L/wABAq9Dq99cHiIID75NWpIXKzdZCelVr2yM6IFYfLnr3p9mk2N8zHJ6A1JcNMF/dLn3p7itYwLmyaM4dcVRkt/atyRJCSZFaoJFtwOQ+fwpOJVzAkt6zbvTonBONp9RxW5dzwx55/OsO7v0JIU1m1YfMZp0+SM5BDgelWbXEYO7rTDeFjtWpNrMuTS5bkOQ2QCRuelIFRabKpUZFMQkg5oURXJFuVhYmopNTLyYz8o61UuyBwOtUT19qtMg9AkbjINVCzBs5qbzo8fMaieaHNUzVB9pZehqRdQZTjmoDNCO1C3EWfu0hmpb6iG4YGtCKZH6GsWC6g3AFQK1Y1VkDJVITNFJUWFlcZGc8UgvFBAKnFUQ5HBp3yuMZxRYLmrDdRN8u8fjUrOF7jH1rBkgkzlTmkLSqMNnFSM3Gu4E+86im/2hb/3jWGdhGSCDQAuflemBuC8tm6sPxFPDWj9oz9VFYOcHBzTlY9jQI3hb2x6Qxf8AfIo+yWx/5YRf98CsiO4kXo1XYb48BjQBZ+xWv/PvF/3wKQ2FmTzbRf8AfNSxzBx1FSdaAuUZ9Ks5oTH5CJn+JV5FYN34ULEmIxuPQjBrrKKLIdzzyfwrKpJa0J9wM1Ql8PbT/qZEPtkV6lSEZpcoXPKG0q5QYSd8ejjIqP7LexniNG90JU16w0MTcNEh+qioX02zfO62j/AYpco+Y8xivL23PKzKPdQwq9BrpyBKqH6HafyNdy+hWDH/AFRH0akGg6Z/Faq/+9zUuncpVDD0fVo/tcbKHBJwRjqK6533fKh+prPOhaUVwtlEnumVP5ir0MSQRrHHkKowMnNOMGtBSknqOACjApskaSKVdQwPY0+itLEGZPo8TkmNyvseaqNocmfldD+lbp4prSIvVhSsguYP9gSN95o/zpf+EZjYfPKB9FrYe8iXvmoHvx/CtHKguzMPhaL+GYfitOTw1Av35h+C1ba8lYdcfSozK7dWJo5UPmY6PStPh+8Sx+tWUktoP9TEB74qieeuQaBu7HNOwrl5r5j91cVC9zI3VsVCD9ar3MwVTzigQt1diNSWaud1DWgmVRst6CqesaoWkaKFs+prOsLKfULkRxKTk/M3pUNiHmW5vpOM49qhu4JIFywNd5YaCbaADaOlYHiyBre35UYZgM+lKw7aHO2QaS5RFBJJ6Cuuj0x/IBaMjjuKwfC0LS6vGV/gBOcZr1CHPlAOAR7CqQJaHm99bNC3I4qDYpXArttes7Wa2kddqMAenFeeSXBjBwc+lS3bQTRUuyBKyg5xVUnnFOkY8k9TUQ65qkiTpzISetIXNLHEXPNWY4I160rGxXUO/ABqzFau/U4pyOsUmMcVpRqsqbk4NNITZXtrLDfNWpCfKUAdKjtzhsMOankj4yKpIkfw65FQ7ihp0eVFEmGU0ATRThhjNK0mPcVmGRon9qkWZZB15ouFiWa5VP4Qarm7hbnbg1WvSVGQazvMJNS2Ukb8V9Ht2spIqeMwyj92+D6GsK33t9KuwuFOGFCYNGiwaMgOOvQil34xzmnptngCg8jpUbQsg59eoqhE8Vwyngmr0F7nhqylAHenqQOlAHQJKrjg1J1rCjuGTpmr0N5u4NAF+kpqSKwp25R3oELRUbTIOrCoXvYl70DLVJketUG1Bf4VJqF76RjgDFAGpuA70xp416sKyGmlbqxphyepJoEaj30a9OarvqBP3RiqW360BTnigCdrmR/4vyqLexPzE05YHY5Cmp0spG68UAVue3NGc8Yq+lgB1NTLaxr2oAzFjJ+6DUyW0jdqvEInQUxmYn5BigdiJbPA+ZqXyoV7ZNTLCzcu1SrEi9qAKcmFXiPArl/El95FuUjYB3OPpXW3jhIyewFcWLA6zqjTS5ECnCj+9UyH0MPTNMm1GbCghAfmavQdH0mCzhVY1wR1Pc1YsdOitowqIAB6CtBVAFCQthr/ACpxzXE+NY99oHU/dYEiu3fOOK5vxLbieyl4wdtEgRzXhG2LTvOSVA4Brt3vVgi+Zv1rktKAt7NQgPTn61latq007mFWwiNn64qbj2Rd17Vby7ZkjgdY+ctjkgcGuclhuNzqYmyhwwx0PPH6H8qm/tO7VdiyjbzxtHc5I+hqFtRuR5pDgeaSXAUcn1ppIzbuQtaXTCMrBIRKMpgfeqGWCWCZoZUKupwQe1WYtQuESJEEYEQIU7cnnr3q1Z28up3rTOFyxy21cAn6VT0Elc//2Q==)\n\n### 📌 核心观点\n\n> 深度工作能力日益稀缺，因此日益珍贵。\n\n在注意力经济时代，能够持续专注进行高认知难度工作的人，将成为赢家。\n\n### 🔑 关键策略\n\n1. **设定固定深度工作时段** — 每天至少 2 小时不受打扰\n2. **建立仪式感** — 固定地点、固定时间、固定流程\n3. **远离社交媒体** — 限制碎片化信息输入\n4. **拥抱无聊** — 训练大脑在无刺激时保持专注\n\n### 💡 个人行动\n- [ ] 每天上午 9-11 点为深度工作时间\n- [ ] 关闭所有通知推送\n- [x] 已删除 3 个不常用的社交 App', type: '阅读' },
        { title: '📖 《原子习惯》核心摘要', content: '### 🔄 习惯养成的四定律\n\n1. **提示** — 让好习惯显而易见\n2. **渴求** — 让好习惯有吸引力\n3. **反应** — 让好习惯简便易行\n4. **奖励** — 让好习惯令人愉悦\n\n### 🛠️ 实操方法\n\n- **习惯堆叠**：在已有习惯后追加新习惯\n  - 「刷完牙后，立刻做 10 个深蹲」\n- **两分钟法则**：新习惯缩到 2 分钟内可完成\n  - 「阅读 1 页」比「每天读 1 小时」更容易开始\n- **环境设计**：改变环境比改变意志力更有效\n  - 把手机放到另一个房间\n\n> 你不会达到目标的高度，你只会落到系统的水平。', type: '阅读' },
        { title: '💡 一个笔记 App 的交互灵感', content: '### 📱 手势交互\n\n- **左滑**：快速归档或删除\n- **右滑**：标记为重要/收藏\n- **长按**：触发批量选择模式\n- **双指缩放**：调整字体大小\n\n### 🔍 智能搜索\n\n- 输入时**实时高亮**关键词\n- 搜索结果自动**滚动到**匹配位置\n- 支持**标签组合**筛选\n\n### ✍️ 编辑体验\n\n- 支持 Markdown **快捷输入**\n- `#` 自动转为标题\n- `- [ ]` 自动转为待办事项\n- `1.` 自动转为有序列表\n\n> 好的工具应该**隐形**——让用户专注于思考，而非操作。', type: '灵感' },
        { title: '💡 语音输入转笔记的交互设计', content: '### 🎙️ 核心功能\n\n- **实时语音识别** + 自动标点\n- **语义分段**：自动识别话题切换\n- **多语言支持**：中英文无缝切换\n\n### 🗣️ 语音指令\n\n- 「**新建一条灵感**」→ 创建空白笔记\n- 「**标记为待办**」→ 添加待办标签\n- 「**设为重要**」→ 置顶显示\n\n### 📡 离线与同步\n\n- 离线模式下先**本地缓存**\n- 联网后**自动同步**到云端\n- 冲突时保留两个版本供用户选择\n\n### 🎯 适用场景\n\n- 开车时的灵感记录\n- 做饭时的待办添加\n- 走路时的读书笔记', type: '灵感' },
        { title: '💪 久坐族的简单运动方案', content: '![](data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCADgAZADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0WloooAKo6r/qU/3qu1S1T/UL/vUAZMP3zT7r/U/iKbB980+6/wBQfqKXQClS0lLUjLthHKwcxpuxjNWXVhxJCfxFLofSb8K1apIRhmO3bqmD7U02sR+7IR9a3GjRvvIp+oqJrSBv+WYH0OKLBcxTZv8Awup/SmNbyr/AT9K1p7KNIndGYFQTis4PJvIVmOO3Wk0MqlWX7ykfUUAkdDVr7RIOGH5igyxN9+JT9KQFbce/P1oyp6r+RqwUtm7MtJ9njb7kw/GgCDCnoSPqKTYexB/GpzayfwlW+hqNoZV6o35UDIyCOoNJT8lT3FG7PXB/CkBA0ZeQYUnHpTxbMHLKXH/Aak49CPoadGhLEhj+NAELeah6qf0ppnbGJEOPzqSUfvDURHpxQA8lJFBVscd6jHmjpJvX35qORSQflDfWkjiJIbJX2BoAtKFf7wAPsaGjKqMc80Lt2gEFvwpwBH3N4/GgBwh9WNKEHfNAMvcA/jTlzjnigQbF9KMAdqdijFMBKM0tFACUUtFACUYoooGIaSlpDQAlIaWkpAJRRRTASkpTSUANpKWikB1dLWTv1NOoLfhml+3XqffgB/AirJNWqWp/6gfWoRqjj79ufwNR3V8k8W0IynPegCnB981Jdf6g/UVHB981Jc/8e5+oo6B1KVFFKKkZraH0m/CtWsrRP+W34Vq1S2EwooopgRXP/HtJ/umsux/4/wAfU1qXH/HtJ/umsux/4/h9TSYGuVVvvKD9RUT2lu/3ol/KpqWmBTbTYD93cv0NVrmwEUZcSEgdiK1ar33/AB7N9R/OlYChp8Czb9xYYx0NWjZMPuTH8RUWk9ZfoK0qEgM97WYAk7HAqs8K4y8I+orXf7h+lU5PuH6UWAzvKiY/LuFOSIJ3zSp981LikMzZx++b61HUtx/r3+tRVIxpFKooNKtAEq9KkFMWnigQtLSCnUwCiilxQAlJS0UAJRS0UAJSUtJQAlFFFAxppKcaSgQlJS0lAxDSUppKAEpKWigDqqKKWrJGlVPVQfqKo6pEi225UCnI5AxWhVLVP+PX8RQBkwj5zUlz/qD9RTYfvtT7n/UH6il0Ao04UlLUlF3Txcnf9mYDGM571d8zUU6xq34VDonWb8K1qpEsz/ttyv37X8s0o1MD78Dir9IQD1ANAFCXUIHhdRvBIIGRVCGfyp/MUA4J4Na91FH9mlOxchSQcVRsIY5nlWRc4xihgSLqn96L8jTxqcWOUcGnnTrc9mH0NMOlxdncUahoSLqFu3VyPqKbdXEMluQkik5HGaiOln+GX8xUUmnSopbepAGaNQJdJ/5a/hWjWPYm4Uv5CqemQauefeL962B+hoQFt/uH6VUf7p+lI15JtIa2cVCblSCCjCgCBPvmpsVBGcuasChAZlx/r3+tRVJc/wDHw/1qKoGIactNNOWgZKtPFMWnigQ4UopBTqYBRS0lABRRRQAlFLSUAJQaWkNADaKKKAENJRRQAlBpaSgBDSUtJSASkpaSmM6qiiirJCqmp/8AHr+NXKp6n/x6n60AZcP3zT7of6OfqKZD99qkuf8AUH8KXQChS0UVJRqaJ96X6CtasnRfvTfQVq1S2ExaSiimIiuv+PWX/cP8qp6X/rZvwq5df8esv+4f5VU0z/Wy/hSA0aKSimAUyYZhf6VJUcv+qb6UAUdK4eX8K0az9M+/L+FaFJANf7jfSqFxNFCg81gu7gZq+/3D9K5jWj5l4sbPtBwozSk7IqCu9S+g+c1OKytGuPPWRW6q2fz/APr1rAUJ3VxSVnYyrr/j5f61FUt1/wAfMn1qGpADSrTTTloGTLTxUa1IKYh4pRSCnCmAUUUtACU+GGSeTZGuT/KmVs6WgW13DqxOaBFYaTJjmVQfoaP7Jf8A57L/AN8mr/mtuXKjazFQc89/8KgbVbVJ3hkZkdCQcr1A7j29/Y07AV/7Jf8A57L/AN8mkOkP/wA91/75NWG1exVdzTEDAOdh79O3ftV4YIBHQ0WAyP7Hf/nuv/fJo/sZ/wDnuv8A3ya2KKLAY39jP/z3X/vk0yTR5lXKSI59OlbhpituONrD6jFFkByrKysVYEEcEGkrS1tAtyjgcuvP4Vm1NhiUlLSUAJRS0lAzoYZ/MAOVOemD1qRZVMvlHh8ZAPceorl59SjiljisYlMgY/MPTuRW9BBMssTXDiTaMq2MMpxyPcUKVyS9VTU/+PU/Wreaqal/x6n61YGZD99qfc/8e7fhTYvvtT7n/j3b8KXQOpQpaSlqCjT0b70v0FatZWjdZfoK1atbCYUUUUxEV1/x7S/7h/lVTTf9bN+FW7r/AI9Zf9w/yqppv+sl/CkBoUUUlMBaZL/qm+lOpsv+qb6UAUtM+/L+FX6oab96X8Kv0kAj/cP0rnbeCHUZLySdd43bFPoPatjVZ/I0+VwecYFZegD/AIlzt/ec/wAql6uxa0VylpkQs9Tlts5BX5T6962xWHqT/Z9UhnHbBNbgIxkdKI9gn3Mm6/4+ZPrUOaffOEnmZui5JrljqdxJMZQ5UA8KOgFS3Ym9jpSactUrK8W7izwHH3lq4tAyZalWoUNSiqESCnCmCnCmAtLSUUALW1pv/Hmn1P8AOsWtrTf+PJPqf500IsCOMPuCKG9cUNFG2NyIcHIyoPNOo4pgR/Z4Ocwx85z8o79ako4o4oAWikooAWmLGinKqoPsKdRQBja5/rYf90/zrLrV1z/Wxf7p/nWVUsYlFLSGkAlJS0hoAW30eK3uFuEZnaNW2Ke/pUkGpXd4rRxHyzH37n2rQGA4A6baYqIknyKBuJJwOpp8nYm4+zu55IB5nDqdrZGOaddSO9uwY/5zQKbP/qH+n9aq1kBBEPnNOuf+PdvwpIx85pbn/j3b8KXQfUoUUUVBRpaQQGl/CtWsXT22l8egq/57etWtiW9S2CD0NGRjrVNJCCeaXecdaYElxIrW0oB/gNQaf9+X8KbKw8mTnqpqOE7Gb3oA1KKo+Zz1NKJD707CuXabL/qm+lVfMPcmgSAqRmlYLmc9xcQI5gGScZ46U7S7yUROkxdpFJbaw6D60LM0Y2FRsb7xPSmC4FvOflwFAPB65rK+o7B4gnd9Hidl2l25FYMnimHSLOK1htzPMc7huwATWlrl4t1ANgIUNjnvxXFLbGTXJpZOVX7n1pc2tzZRvFI6GbUDqcaStbvbug+ZWIIP0NdNYMXsYWbrsFcXbmUMY3YEHkcdq7Sw4sIP9wUQd2FRWSRi61uIulXqQf5VyMPOR6iux1Hm6l+tctPYTWs3mKuYicjHb60SMGhunztDfRsD1OCPUGupLqilnYKo6kmuasbR5L0HaditkntVjV5J55zAAViTB+vvQhrRF+fXIk+S1XzX6ZPCipNJvbu6nYSFWQcscYx6AVjRW4OIokZmPJ45NdHp1t9lg2nl2OWqkLc0AacDUQaobe+guHkSGQOYzhsVQy5mimBs0oNAD81t6b/x5J9T/OsLNbumf8eKfU/zpoC1RmlopgJmjNFFABmjNLSUAGaKWkoAxtc/1sP+6f51l1qa5/rYf90/zrLqWMSiikoAKSlpKQFyOX+/wyjBFVZr6MXioruGU7Tj7oPoaY1nO+sRziTMed2PQY6VoR2MaTSyhQTIQxBHQii0noSSociiX/UP9KlRcA5Apk4/dPx2/rWgEUY+c0XX/Hu34UqfeNJdf8ezfhU9BmdRSUA1BZcsurfhVvqMiqVoCSxU4IqXz9spB6lSfyocrEtak2cUBsrkZxTYyZlH90jJqby1x3q4yvqS0Quf3b/7p/lT1AB5pZEAifAP3T/KlK8dKfUBMilBFNIIPNNHJ61QiQkU5QCAaRY85BPSngYAFIaRnmF3ZeABxgk96hvFlVEPJ2jt61qBCYRj0FQo6thW+9kcEVk4lI57UYRbRpECSTl2+prDMHku0iyh2lYuB/d9q6fX7c7/ADF+6RXObATz2PWsmtbHRFpIlCbDE3DNIvb+HnpXaW67LaNfRQP0riYlMcyucsAeR6iu4jdZI1dDlWGQaumRVd7GHf8A/H5L9arHkVcvYJXuZnRCVB6/hWezMFJCkY/OqZkVry9NkquIt6k4POMVTMl7cKZ5yI4TghQBnHapbi5uUlZTbo6cH5jxUjyw3iPAHAZsDCnOKkRUsNZhtpSs8DruON+cgCumaZEiMhI2gZznjFcNqFrNp84ViGVslT2NdH4fme50sCdQQjlRnuBVIET3GoRXdjIlq6yFwUJVvuk1nWd2tlaF9ytJFGI2XGDuzxn86XV7ZbW4W8hiZi3DYPA/D0qjCzXl4VbCrI6sQFzuApMDpdKkka2DzEmRzls/09q0Vas+3wqgAAAdqthwoyTgDqaaGWAa3tL/AOPFPqf51zysCAQeDXQ6X/x4p9T/ADqkIt0UYoxVAFFLSYoAKKMUYoAKKMUUAY2u/wCuh/3T/OsqtTXf9dD/ALp/nWUSACT0FSwCiqb6jCihnDLk4IYYxViKaOaMPE4ZT3FK4D6SoLq4eGMmGFppOyg4/M1hPrOrRzbHs4weu3B4H1zQ3YZ2VrubzNobKNsPHpUpZweSRWSS3mn5m5PPNasULtEhA4x3NVF9CWiWIswPU0sqt5L5z0/rT4kKA5Kj8aLp18hgHUtjgU2wRXX75pt3/wAezfhVd7kQKZJT8o6kdqz77UjHCTDKtyjDOw/K4+nrUc2gybPajPNc6uoM8qQmTKjnf3PHNa+m7mtEkcklhxnsKhSu7FJ3NiwdU8xnOBgVnancFrtfsuCp6t0x2P6VZhaPDqz4YrwB1P4VltKhkHzDk+tU9VYXU6e3kjEKCIZXHGRUnm+i1Rkmns4o0S0aT92CTtJ59OKpDWNTfiPSm/79N/Wq50tB8jZtM5aNxj+E/wAqdyB8tVbGa7nt2a7ijhYnG04XipxJsPM0Kj/fzTvfUm1hWEh6Ln8KRY5c8p+lBuYh1u0/AE003lsOtwx+iU+YViwqNzkUbDjt+dVDfWw/jmb/AICBTTqFv2jmP1YClcdi6vEYHfFU5D+9A96jOpRj7sB/F6qPdFpN4XGO2c0m0OxZv4DLZuoIJHI4rlXTbnNdH/aEgGAkX/fNYuox7Jm2jg8ioaW5SbtYpxnOR6V0GgTu8MkTdE5X2rno1bd0rQgd4ojtYruPY0k1cbTsXLqeZ7poYs7icYzkfU1kvCfmRpHwGPQ471YguzFdOxBPGOe9RMxJJPc5qnqZpamXrKEWqiIHaOozms/T7WeeZDC20rzk8YrZu22tEcZDNtP40/TmVlZ1Ax0/WpHYvS28NzF5dwiuPepbaGK2hWKFdqL0FMU04vtGaoLDLy1S42uxJKA4XPBz61lW9nJYzB2aNwF2jgjFa5kZl4A5/wBqqVxDPK3yqmM/3hUtlKJcgkDGnX8yx2jAtjdxUEEcydYz+BFMvopZ1VfJZgKHIOVmhY3Ky2UTg5+UA/Wus0c7tOjPqT/OvO4lvLeMRRW7iPPcV33h5mbR4S4wctx+NVCVxSi0afFFFLWhInFHFFLQAlHFLRQAnFFLRQBia9/rof8AdP8AOspgSpAOCR19K1deP76H/dP86wb+Vo7VijFSeNw6ipbtqNK5lSWt3JO8QmBkjBId1+9k1ftx9lto43OXxzjue9c8usT2dxIZGa4LAAFzjGPpWlpszzhrmZw5k5UD+EelQmgcWiYXjRQGe4ZUDklUI6D1NZeqqt+Y2TUFjiI5Vgfm9x61JqED3aEvk5OQu7A2jnrWALm5u2EjxBlh2qABwo6AY+tMR38kmJ+FJGetbSXFqI1Bu1GB02msLNGaLlG213ZDrdSH/dSoJbuwIPzXLfQAVlE1GWouKxfF1AGxFFKSemWHNY13/Z80zM6YYdTuORVndzTSqN95QfqKTbY7GN/ZaySb7afKn7oP09fqMfjV2zvpIJBE4DKVyQp+6AO3tTLmA2pee2yAASVHbjnFZumnzL1ASwLNt246qeagWx1dmXty0wc+ZKPmOOcen0qXcX5ZFB+gpinPPbtTs1ZViXzpf+ej/wDfRppdj1Yn6mmZozRcB1Gabmk3UAPzSZpu6k3UAPzSZpm6kLUAPzTSabupC1ADs5OBUWqARhFP39oBq7vjsbYTPzM4yuf4R/jXOXV28spLHNKS0Kg0mSIcn61bY/KBWWJwvPTHWlj1ZHHMJIHQ7sZqYplTkmrItEAPuxzjFNLU5NRt9v8Ax4oT/tOxqGe+U/dtoV+gP+NXYyIrpZZYiEZByCMnpUFrcNZxeXIFbknKmrDSApkDg+9Z1w3J+X9azuzTlVjft5fNiR8Y3DNSTN+4k/3T/Kqdo4W3jHooqWeQfZ5P90/yrRGbJlP7tf8AdH8qpKMyzH/pof5CrCv8i/QVWibLy/8AXQ0xCTZEkWCR17+1ThnA4ZvzqGcjfHlwv3uoJ7U2eJ5oignjXPcEg0DRYEso6SP+ddz4aZm0SEsSTluT9a8z+wXI+5d/+RBXo/hCOSPw7bpK+9gz5Oc/xGnG1waZfNmfMZluZ1DHJAbj6ClitHjf/j6lZCpBVj3PepthM28PxjGKR497ZErL7A1ZI5UKnJdj9afmohCQoUSuMe9BiJA/euCO9AE1FQmIk5Erg98UCFgQfOc+1AE1FFFAHKeMro21xa4VjuUjg47iuakvzP5kLwyMg4Y7hj1rf8cDNxZfX/2YVz8CZkn/AOun9BUONylKxm3NjbyyhYonV8bjubjFTRRT28YxKFjQcgDPFXNn+nH/AK5f+zVP5dTyj5mzAvr77bIEiJUfdUHvVeNBbwuyyFjnnA469q09URIGMqIu/bjOKoQHzUePaSQQCAOMetJkI6/NJmm5pN1MocTUbNQWqMtQA/NKG5qLPFCsPUVJRQur6feyrsUKfTJrPjFytx5yTKr4wCF/Cp7o5nf/AHjUa9am5fKjW024uGmAmuDIp7FQK1t2elYNiwE6Y9a2N+OpFOLJkibdRuqAyqP4hTfOHbJ/CqJLG6k3e9V/MJ6IfxNGZD0UCmBYLe9JvqIJK3f8hThbyN1ZqLCHb6aZQOpFSLYOwyQcepqRdP8A90/Qg07MLlQzD1/KrFpD55MkhKQp95j39hUxtI4hvm+VR+ZrP1DUN6+XHhY14Cii1guQ6vfG4nO3hRwKyjzU8UMt3OI4UZ2PQAV0dn4XAQNdSAN/dXtRa4zjrjJAQd+v0ojTA6V3J8LWROdzZ+tSxeHbCI5Me/8A3mp2EcZb28sxxGhI9aZcwvDIVkIyPSvRPscAQIsCBR2AxXB658mpzoBgByAKLAMhtHubdWRsYyKZJo8rdZP0rofDVmtxpjOxIPmEDn2rVOkKekmPwzS5UO7OUj05lUDPQUslgxjZcnkYro5LAIcGUfipposXcHYyN+OKdkTqc99jcDgn86hFpIhbDNyc9a6ZtOnH/LMn6VC9lKp+aNvyosBzk1tOzIQ3TPWkaK4A7VvNBjqtMMA/uigDAKXA/gBr0PwiGHh633DB3Px/wI1zBtx/drr9ATZpEK+7fzpoRdMEZJJB596XyI8YwcfWsq/1h4p2itlX5Dgs3OT7VU/tu8/6Z/8AfFdCoTauZurFOxvfZovRv++jUiIqDC55Oetc7/bV5/0z/wC+KP7bvP8Apn/3zT+rzF7WJ0tFc3/bd5/0z/75pP7bvP8Apn/3xR9XmHtYnS0VzX9t3n/TP/vitPS9S+2bo5FCyKM8dCKmVGcVdlRqRbsYHjgkXVjgA8+vvWDatl58jH709/YV0HjWES3VmT/CpP61zkdvsZyP4myawZZMP+P1v+uQ/malkzs+Rtp9cZqp5TCZnDHJUDrUg8wdSSKT2GtzFu5pRdHzZAy8jpV3S7aOOHzV+9IM/h2qjqMEzzMUjJGavQGdIkXYOEAqIockuhqGSmlzUOyQ9XNKLcnrk0wHNKO7D86iMo9c/QVMtt/s08Wx9KLMLlYy8cKxpqs4/hP51eFqfSni19qOUOY5vUiYpt+Plb07Gqq3SZ711UlkCfmX9KRbCP8AuD8qOQamZOmAzS7uQo/WtlYM9qmgtVRhhQKuLAPSmoWE5XKS23tUyWtXUhqZYgKtRRNyklnnoCatJpzn+A/jVgSLF1kCfU4prarDH1nDewGadgKuoQNZ24k4C5wcdazbXULy9kaKzt2cr1KgYA+tWtc1RbnTXjiQ7gQcniqPhfUFs45oXCl5HDDJ9qzfxGqXukl1FqaDMttMfcDd/KqQa9BLC3nGO+w11i6hI4yqMPoBUi3k3eMn6nFURY4qS8mlIjyzN0Cjk1esvD17dkPdAwRe4+Y/hXUJOivv+zxqx6sMA/nUgvYu/H45osGoyxsrSwi2W8e31Y9T9TVrcp7iohdwn+I/lThLC3cflQFmPo/CmYjPQj8DTGA7SN+HNAE1cH4th8rWGYdJAG/Su0/fZ+Ukj3Fcr4thdryJnIz5f9TSbBK5teGUEWhQE4G4s361pNLGPQ1R0SJRo1qdpb931BrQAUdFx+FAEe8N92MmjbIegC1LketL9DQBEImz8z59sU4Ljoq/rT+aTn1oAaVB+8gNNMUJ+9CP++RUuPU0YoArm1tW6xAfgRWjYokdsqR/dBPeq2cDk4pFvooCctuB6gU0DRl6jYTxXLssbPG7EhlGevrVTyJv+eMn/fJroxq1pjJZx/wGj+1rT++//fJrqjimlaxzuimznVhnVgwikBHI+Q1Jm7/55P8A9+//AK1b39r2f99/++TSf2xZ/wB9/wDvk0PE33Qex8zBYXTKVML4PXEZqLyJv+eMn/fBrov7Zsv+ej/98Gj+2rL/AJ6P/wB8GmsVbZB7HzOe8ib/AJ4yf98mtjRLKWKRriZSmV2qD1PvVn+2rL+/J/3waim120RCYxJI3YYwPzqZ4hyVhxpJO5neKsNdW6jqEJP51g7Part3cPdXDTSn5m/Ie1QGuVmxXKc0FOOlSmkNIChLFluhpwXipnHNJn3FAzWWwkIz5TY+lP8AsRU4IFb6XET9Gwfen7I252qfwqyTnxairEVraf8ALUvmtdoYiPuAfQVA9mh6MfyoCxHFBY/wIhP+1zVlY41Hyoo+iiiOEIuOvuaDGPQ/gaQwdEcYdFb6iq72Fs/8BU/7JqckKP8AGm+eP7jfhQMq/wBmKDlJPwIo+xSL2z9DV1JN3QH8ak5pk2M8RFfvAinBav8A1pCiHqop3CxiHR7Lqsbof9iRh/WmDSEz8lzMv12t/MVtNHGP4sVGFGeOaLgY0+lTiI7bhGHo0X+BrPXTpk/5ZW5+hK/0NdU6EqflNVzEPSgLswBZ3I6W7f8AAJVP+FBjuo+qXi/8ALD9M1tNFjpxTP3ingmiw+YxhdyRnmcD/rpHj+YqZNTn/gNs/wBDWqJ3HDcikaO2m/1kET/7yA0h8xnjVrhfv2wI/wBk0o1xP44ZB+NWm0uwbpbqn+4Sv8jUMmj2x+5LcL/203fzBpD5hF1m1PUMPqualXVbQ/8ALUj8CKzpdGI+5c5/34wf5YqrJpVyv3Xhb8WX/GgOY6FNTgP3bgfnXPeIb+GW5JeVfkUKPmHPf+tVZLK8T/llu/3XB/niqF1ZO5zNayfUpn+VJq5SaRtaJr5tYxDlZYAc8HJT6V08OpRTqGjZGB9DzXmiWsML7l/dN68rU6OsRWR7vheRmXikk0GjPShdL3U04XER65/KuAg1dG4iu1YjsjVMNenB2JIXb0A3GmKyO682L+9j9Ka11AvWZfpurifP1a66KyL6yNt/Qc1LHpztzdXcjf7Mfyj8+tAtDq3v1H3BuqCS+lP3SF+lZNrBBagiBNu7qckk/nU++gRYaZn+8xP1NM3VFuo3e1ICTNITTM0mR60AOz9KQ02kNAAcUhApCaTJoAWkNJn3pMmgBCDTTmnE00mgBppppxpp6UARMBnrSYpx69qbQB0gzUqsw6MRTVyTwKeM+tamZKk8o6nP1qT7SP4gR9KrEfWmMKVh3Lonjb+On7gejVlMDTeR/FSsO5rkr/eH503zIx/F+VZitz8xOKuQ/Zz3596B3JxMvYUod26LT0CfwgU/igCPbIepxS+Vn7zU+loEM8tR2zSgAdABSmkFADqaVU9QKXNFAEbQofaontvQ/nVmkoAoPauOgz9KrSROnOCK16aw4oHYyEnIOGp7OCOtXpIo2+8i1VlS1T+LafY0h2KkjVETT5Gjz8hJHuKiJpCI3JqCUmpnPvUEnJoGCnK4Iz9aims7ab/WQRt9VFSrwOKdQBnDRdPD7vssefpVyOCOFdsUaoPRRipgfaloAZg0Zan0mKQDdzUbmp2PakxQABm9advNJj2o20ALvpd9NxRxQA7fSbqbSE4oAdupM0zcPSkyKAH5oz70zNJmgB5PvTSfc0hIppNIBxNNJpCTTcmgANNJxQzetNLUAdWAPen49BTRTs1sQH5UjcDmnZHvTXIxwKAK7sM1CW9qkkOD0qFiaADcaepPrUXNSJx2pAXIWYdDVpZW781SiIqyp4oGT+afSkMp9qYM+tLxQAvmMelPQsetRE46ULIwNAFnFHSovO9RQZvQUhkuRTS4HeoS5bvTD70AStOo6c1DJcNj5Rio2OKjIJFAFe4mkOcsapsxq1OMCqL5z1pMALmnbjioec1IBxSAazetRMwzUjgVE3XoKBjl5FOyaizS5NICXPvS5HrUYBpQKAHbhS7vam0tAC5pc02jNAC0UmaM0ALmkJpNwpC4oAdSH6Um8UhcUAHFJim7qTcaQxxxSYpMmkJNAhaBliFXqeBTMH1oHBB7igCRopRyUammOQFhsbKnB9qeLuZVwH4+gppupcvhgN5y3HU0AMMMpCkRMQ/3eOtRyK8blHXDDqKlF3KqqqhRs6HFRSyNLIzvjc3XAxQB/9k=)\n\n### 🪑 每小时微运动（2 分钟）\n\n- 颈部：缓慢环绕 **10 圈**\n- 肩部：前后拉伸各 **5 次**\n- 站立：深蹲 **5 次**\n- 手腕：旋转活动 **10 圈**\n\n### 🚶 午休散步（15 分钟）\n\n- 楼下走一圈，不刷手机\n- 观察周围环境，放松眼睛\n\n### 🏋️ 下班后核心训练（10 分钟）\n\n1. 平板支撑 30 秒 × 3 组\n2. 仰卧起坐 15 个 × 2 组\n3. 臀桥 10 个 × 2 组\n\n> **关键不是运动量多大，而是坚持多久。** 从每天 2 分钟开始。', type: '健康' },
        { title: '💪 睡眠质量优化清单', content: '### 🌙 睡前 1 小时\n\n- [ ] 关闭所有**蓝光设备**（手机、电脑）\n- [ ] 调暗室内灯光\n- [ ] 避免大量进食和饮酒\n\n### 🛏️ 卧室环境\n\n- 温度保持在 **18-22°C**\n- 使用**遮光窗帘**\n- 保持安静（或使用白噪音）\n\n### 📋 睡前仪式\n\n- [ ] 热水澡或泡脚 15 分钟\n- [ ] 阅读 10 分钟（纸质书）\n- [ ] 5 分钟冥想或深呼吸\n- [ ] 写下明天的 3 件重要事项\n\n### ⚠️ 避免\n\n- 下午 2 点后不喝咖啡\n- 不在床上看手机或工作\n\n> 睡眠是**最被低估的生产力工具**。投资睡眠 = 投资效率。', type: '健康' },
        { title: '🧠 认知偏差：确认偏误', content: '### 🧩 什么是确认偏误？\n\n> 人们倾向于寻找**支持自己观点**的证据，忽视反面信息。\n\n### 📊 典型表现\n\n- 只看赞同自己立场的新闻\n- 评估证据时双重标准\n- 记住支持观点的案例，忘记反对的\n\n### 🛡️ 应对方法\n\n1. **主动寻找反面证据** — 刻意搜索反对观点\n2. **设立「魔鬼代言人」** — 找人挑战你的想法\n3. **写下预判** — 在看到数据前先写下预期\n4. **多元化信息源** — 关注不同立场的媒体\n\n### 💡 延伸阅读\n\n- 《思考，快与慢》— 丹尼尔·卡尼曼\n- 《事实》— 汉斯·罗斯林', type: '认知' },
        { title: '🧠 决策疲劳与简化策略', content: '### 🧠 核心原理\n\n> 每天做决策的次数有限。重要决策应该放在**精力最充沛的上午**。\n\n### 🔄 建立默认选项\n\n通过减少日常小决策来**保护决策能量**：\n\n- **早餐**：固定 2-3 个选项轮换\n- **穿搭**：提前一晚准备好\n- **日程**：预设每日模板，填入具体任务\n\n### 📋 决策分级\n\n- **A级**（重要）：上午处理，充分思考\n- **B级**（常规）：下午处理，快速决定\n- **C级**（琐碎）：批量处理或委托\n\n### ✅ 本周实践\n\n- [ ] 固定每日早餐菜单\n- [ ] 提前准备一周穿搭\n- [ ] 将 3 个 B 级决策委托出去', type: '认知' },
        { title: '🧠 信息筛选的核心原则', content: '### 🎯 三大筛选标准\n\n1. **相关性** — 与我的目标是否相关？\n2. **可行动性** — 读完后我能做什么？\n3. **时效性** — 这个信息现在有用吗？\n\n### 📥 输入管理\n\n- [ ] 每天花 **5 分钟**审视信息输入源\n- [ ] 取消关注低价值账号\n- [ ] 关闭不必要的 App 推送通知\n- [ ] 设定固定浏览时间（而非随时刷）\n\n### 📤 输出导向\n\n- 信息只有经过**加工处理**才有价值\n- 读到好内容 → 用自己的话**复述**一遍\n- 用 Gator 记录**行动要点**，而非原文摘抄\n\n> **不是所有信息都值得消耗注意力。** 你的注意力是你最宝贵的资产。', type: '认知' },
        { title: '📝 富文本排版范例', content: '## 📐 Gator 排版能力一览\n\n### 一、有序列表（层级递进 1 → a → i）\n\n1. 产品设计\n   a. 用户研究\n      i. 深度访谈与问卷\n      ii. 用户画像与旅程地图\n      iii. 可用性测试报告\n   b. 竞品分析\n      i. 功能对比矩阵\n      ii. 交互模式拆解\n   c. 信息架构\n      i. 卡片分类法\n      ii. 树状测试验证\n2. 视觉设计\n   a. 色彩体系\n      i. 品牌主色定义\n      ii. 语义色与中性色\n   b. 组件规范\n      i. 按钮与表单\n      ii. 卡片与弹窗\n      iii. 导航与标签\n   c. 响应式适配\n      i. 断点策略\n      ii. 触控热区优化\n3. 工程交付\n   a. 前端开发\n      i. 组件化拆分\n      ii. 状态管理方案\n   b. 后端联调\n      i. API 接口对接\n      ii. 数据格式校验\n   c. 上线发布\n      i. 灰度验证\n      ii. 性能监控埋点\n\n### 二、无序列表（符号递进 ● → ○ → ■）\n\n- 学习资源\n  - 前端基础\n    - HTML5 语义化\n    - CSS3 动画与布局\n    - JavaScript ES6+\n  - 框架与工具\n    - React / Vue / Svelte\n    - TypeScript 类型系统\n    - Vite / Webpack 构建\n  - 进阶方向\n    - 性能优化策略\n    - 微前端架构\n    - 跨端方案对比\n- 效率工具\n  - 开发辅助\n    - VS Code 插件精选\n    - Git 工作流规范\n    - 终端快捷命令\n  - 设计协作\n    - Figma 组件库管理\n    - 设计 Token 体系\n    - 自动切图与标注\n  - 项目管理\n    - 需求优先级排序\n    - 迭代节奏把控\n    - 复盘与知识沉淀', type: '效率' },
    ];

    const demos = demoContents.map((d, i) => {
        const offsetDays = Math.floor((i / demoContents.length) * totalDays);
        const offsetHours = Math.floor(Math.random() * 24);
        const createdAt = new Date(startDate + offsetDays * day + offsetHours * 3600000).toISOString();
        return {
            id: 'item_' + (Date.now() + i),
            title: d.title,
            content: d.content,
            type: d.type,
            createdAt,
            updatedAt: createdAt,
            pinned: false
        };
    });

    items = [...demos, ...items];
    saveItems(); renderFeed(); renderTabBar(); renderTagManageList(); showFabCheckmark(); showToast('示例笔记簿与灵感已添加');
}

function showToast(msg) {
    const t = document.getElementById('toast');
    const theme = THEMES[currentTheme] || THEMES.blue;
    t.textContent = msg; t.style.background = theme.primary;
    t.classList.remove('opacity-0'); t.classList.add('opacity-100');
    setTimeout(() => { t.classList.remove('opacity-100'); t.classList.add('opacity-0'); }, 2000);
}

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        closeEditOverlay();
        closeFullscreenEditor();
        closeInputModal(); closeBgColorModal(); closeDeleteModal(); closeDeleteNotebookModal();
        closeCreateNotebookModal(); closeRenameNotebookModal(); closeNotebookMenu(); closeDetailModal();
        closeTagManage(); closeEmojiPicker(); closeGearMenu(); closeInspirationManage();
        closeRecycleBin(); closeBatchDeleteModal(); closeTagGearMenu(); closeClearAllModal(); closeClearRecycleBinModal(); closeRestoreAllModal(); closeDeleteTagModal();
        if (batchDeleteMode) exitBatchDeleteMode();
    }
});
